#include <cstdlib>
#include <iostream>

int main(){
    //allocate space for a ineger value (based on konown size)
    int *ptr = (int*)malloc(4);
    int *arr = (int*)malloc(5*sizeof(int));//20 bytes
    char* charr = (char*)arr;
    int *numbers = new int[3]; //new int, total 3 of them

    //decide what you want to store and calculate size you want
    
}