#include <iostream>

// function pointer is used to pass logic to the parameter

void method(int n) {std::cout<<23*n;}
void method1(int n) {std::cout<<43*n;}

void Operation(int* arr, int size, void (*ptr)(int )){

}

int main(){
    int arr[] = {1,2,3};
    // void (*ptr)(int ) = &method;
    // void (*ptr2)(int) = &method1;
    Operation(arr,3,&method);
    Operation(arr,3,&method1);

}