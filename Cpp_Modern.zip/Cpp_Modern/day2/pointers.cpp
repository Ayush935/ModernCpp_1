#include <iostream>

/* 
            &                           no-symbol
Size     Address   Identifier Name      Content
4        0x100h        n1                 10
8        0x88h         ptr              0x100h
8        0x991h        sptr             0x88h
*/


int main(){
 
 //* is a derefernce operator
 //while accessing a pointer 1 * means 1 jump is allowed;
 
}