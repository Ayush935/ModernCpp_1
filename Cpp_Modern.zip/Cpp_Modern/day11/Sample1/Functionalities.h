#ifndef FUNCTIONALITIES_H
#define FUNCTIONALITIES_H

#include <list>
#include "Project.h"
#include "Employee.h"
#include <iostream>

using ProjectContainer = std::list<Project>;
using EmployeeContainer = std::list<Employee>;
using RefContainer = std::list<ProjectRef>;

void CreateObjects(ProjectContainer &projects, EmployeeContainer& employees);

/*
  Find the budgest of the projects based on employee id given as a parameter
*/
float FindBudgetProjectByEmployeeId(const EmployeeContainer& employees,int employeeId);

/*
  Return the reference wrapper of the first N instances of projects based on N in second parameter
*/
RefContainer FirstNInstancesProject(unsigned int N,const EmployeeContainer& employees);

/*
  find if all employees have a salary above 50000
*/
bool IsContainerAll50kAboveSalaryEmployees(float salary,const EmployeeContainer& employees);

/*
  find the count of employess working on the projects with budget over 600000
*/
std::size_t FindAbove600000PpojectEmployeeCount(const EmployeeContainer& employees);

EmployeeContainer FilterEmployeeByPredicate(const EmployeeContainer& employees, std::function<bool(const Employee&)>pred);

/*
  CalculateTax for each employee based on a "tax formula logic" passed as an argument
*/
void ComputeTaxBasedOnFormula(const EmployeeContainer& employees,std::function<float(const Employee&)> fn);

void DeleteObject();


#endif // FUNCTIONALITIES_H


/*
   unsigned long :
   //8bytes
*/