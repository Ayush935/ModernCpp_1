#include "Functionalities.h"

void CreateObjects(ProjectContainer &projects, EmployeeContainer &employees)
{
    projects.push_back(Project(101,234443.5f));
    projects.push_back(Project(102,235543.5f));
    projects.push_back(Project(103,777743.5f));

    auto itr = projects.begin();
    if(itr != projects.end()){
        employees.push_back(Employee(101,"Ayush",12232.4f,*itr++));
    }
    if(itr != projects.end()){
        employees.push_back(Employee(102,"Bob",13432.4f,*itr++));
    }
    if(itr != projects.end()){
        employees.push_back(Employee(101,"Bobby",134532.4f,*itr++));
    }
}

float FindBudgetProjectByEmployeeId(const EmployeeContainer &employees, int employeeId)
{
    if(employees.empty()){
        throw ; ///
    }
    
    //for each emp in employees
    for(const Employee& emp : employees){
        if(emp.id()==employeeId){
              return emp.ref().get().budget();
        }
    }
}

RefContainer FirstNInstancesProject(unsigned int N, const EmployeeContainer &employees)
{
    if(employees.empty()){
        throw ; ///
    }

    if(N>employees.size() || N<=0){
        throw ; ///
    }

    RefContainer result;
    for(const Employee& emp : employees){
        result.push_back(emp.ref());
    }

    return result;
}

bool IsContainerAll50kAboveSalaryEmployees(float salary, const EmployeeContainer &employees)
{
    if(employees.empty()){
        throw ; ///
    }

    for(const Employee& emp : employees){
        if(emp.salary()<salary){
            return false;
        }
    }

    return true;

}

std::size_t FindAbove600000PpojectEmployeeCount(const EmployeeContainer &employees)
{
    if(employees.empty()){
        throw ; ///
    }

    std::size_t counter{0};
    for(const Employee& emp : employees){
        if(emp.ref().get().budget()>600000){
            counter++;
        }
    }

    return counter;
}

EmployeeContainer FilterEmployeeByPredicate(const EmployeeContainer &employees, std::function<bool(const Employee&)> pred)
{
    if(employees.empty()){
        throw ; ///
    }

    EmployeeContainer result;

    /*
    for std::function<bool(Employees&)>
     for(Employees & emp : employees){
        if(pred(emp)){

        }
     }
    */

   for(const Employee& emp : employees){
    if(pred(emp)){
        result.push_back(emp);
    }
   }

   if(result.empty()){
    throw ;////
   }

   return result;
}

void ComputeTaxBasedOnFormula(const EmployeeContainer &employees, std::function<float(const Employee &)> fn)
{
    if(employees.empty()){
        throw ; ///
    }

    for(const Employee& emp: employees){
        std::cout<<"The tax on employee with ID: "<<emp.id()<<"is : "<<fn(emp)<<"\n";
    }
}
