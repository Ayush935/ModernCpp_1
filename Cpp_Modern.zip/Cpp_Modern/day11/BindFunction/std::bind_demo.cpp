
#include <iostream>
#include <functional>
#include <cstring>

class Dummy
{
private:
    int _factor;
public:
    Dummy(int factor): _factor{factor} {}
    void Magic(int n1){
        std::cout<< _factor*n1;
    }

    ~Dummy() {}
};
// int addition(int n1,int n2){
    
// }

// registered_owner name, car_model, cas_engine_fuel
int formula (int x,int y,int z){
    return ((x+y)-z);
}

void Adaptor( int n1, int n2, std::function<int(int,int)>fn){
    std::cout<<fn(n1,n2);
};

int main(){
   // addition(10);  //n2 is 20, addition(10,20)
   auto fn =std::bind(&formula,100, std::placeholders::_1,std::placeholders::_2);
   std::cout<<formula(10,20,30)<<"\n";
   fn(20,30); //formula(x=100,y=20,z=30)
   fn(40,30); //formula(x=100,y=40,z=30)
   fn(20,30,40); //formula x=100,y=20,z=30

   //objective: hardcode fn from Adaptor to addition function

   auto binded_adaptor = std::bind(
    &Adaptor,
    std::placeholders::_1,
    std::placeholders::_2,
    [](int n1,int n2){
        return n1+n2;
    }
   );
   
   binded_adaptor(10,20); //partial function
   std::cout<<std::endl;
   //example : swapping the parameter sequence
   auto ASLI_STRCPY=std::bind(&strcpy, std::placeholders::_2,std::placeholders::_1);

   //ASLI_STRCPY(source,destination)


   Dummy d1(4);
   auto new_magic = std::bind(&Dummy::Magic,&d1, 100);    //d1[0x100H]->Dummy::Magic()
   new_magic();    //d1->Magic(100)
   std::cout<<std::endl;


   auto f1 = [](int number){std::cout<<number*number;};
   
   //dont use & operator when passing lamda as orignal function
   auto binded_f1 = std::bind(f1, 100);
   binded_f1(); //prints 10000
   
}

/*
  orignal strcpy(destination, source);
                    ^
                    |
                    |
                    |
  i want (source, destination);
*/