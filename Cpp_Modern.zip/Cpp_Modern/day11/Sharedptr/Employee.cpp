#include "Employee.h"
std::ostream &operator<<(std::ostream &os, const Employee &rhs) {
    os << "_id: " << rhs._id
       << " _name: " << rhs._name
       << " _salary: " << rhs._salary
       << " _ref: " << rhs._ref.get();
    return os;
}


Employee::Employee(int id, std::string name, float salary, ProjectRef ref)
   : _id{id}, _name{name}, _salary{salary},_ref{ref}
{
}