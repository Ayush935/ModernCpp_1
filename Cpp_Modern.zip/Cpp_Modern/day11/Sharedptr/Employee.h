#ifndef EMPLOYEE_H
#define EMPLOYEE_H

#include <iostream>
#include <functional>
#include "Project.h"
using ProjectRef = std::reference_wrapper<Project>;

class Employee
{
private:
    int _id;
    std::string _name;
    float _salary;
    ProjectRef _ref;

public:
    Employee(/* args */) = delete;
    Employee(const Employee &) = delete;
    Employee(Employee &&) = default;
    Employee &operator=(const Employee &) = delete;
    Employee &operator=(Employee &&) = delete;
    ~Employee() = default;

    Employee(int id,
             std::string name,
             float salary,
             ProjectRef ref);

    int id() const { return _id; }

    std::string name() const { return _name; }
    void setName(const std::string &name) { _name = name; }

    float salary() const { return _salary; }
    void setSalary(float salary) { _salary = salary; }

    ProjectRef ref() const { return _ref; }
    void setRef(const ProjectRef &ref) { _ref = ref; }

    friend std::ostream &operator<<(std::ostream &os, const Employee &rhs);
};

#endif // EMPLOYEE_H
