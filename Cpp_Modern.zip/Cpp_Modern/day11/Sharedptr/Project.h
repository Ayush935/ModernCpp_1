#ifndef PROJECT_H
#define PROJECT_H
#include <ostream>

class Project
{
private:
    int _id;
    float _budget;
public:
    Project() = delete;
    Project(const Project &)= delete;
    Project(Project &&) = default;
    Project& operator=(const Project&) = delete;
    Project& operator=(Project&&) = delete;
    ~Project() = default;
    
    Project(int id,float budget);
    int id() const { return _id; }

    float budget() const { return _budget; }

    friend std::ostream &operator<<(std::ostream &os, const Project &rhs);

   
};

#endif // PROJECT_H
