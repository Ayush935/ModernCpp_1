#include "Project.h"

Project::Project(int id,float budget)
  : _id{id},_budget{budget}
{    
}

std::ostream &operator<<(std::ostream &os, const Project &rhs) {
    os << "_id: " << rhs._id
       << " _budget: " << rhs._budget;
    return os;
}


