// take N values from the user as input
// take a container of 5 functions
// each function takes one integer as input, returns void

//create an adaptor that accepts array of 5 values and array of 5
// functions. map function at i position to data at i position

#include <iostream>
#include <array>
#include <functional>
using Fntype = std::function<void(int)>;
using Container = std::array<Fntype,5>;

void Adaptor(const std::array<int,5>arr,Container& fns){
   for(int i=0;i<5;i++){
    fns[i](arr[i]);
   }
}



int main(){
   std::array<int,5> data {10,20,40,50};

   Container fns{
      [](int number){std::cout<<number*number<<"\n";},
      [](int number){std::cout<<number*number*number<<"\n";},
      [](int number){std::cout<<number*10<<"\n";},
      [](int number){std::cout<<number%5*10<<"\n";},
      [](int number){std::cout<<number*100<<"\n";},
   };


   Adaptor(data,fns);


   
}