#include <iostream>
#include <memory>

class Data
{
private:
    int *m_values;
    std::size_t m_size;

public:
    Data(int *values, std::size_t size) : m_size{size}
    {
        int *m_values = (int *)malloc(4 * size);

        for (int i = 0; i < size; i++)
        {
            m_values[i] = values[i];
        }
    }
    ~Data()
    {
        delete[] m_values;
    }
};

int main()
{
    int arr[] = {1, 2, 3, 4, 5};
    try
    {
        std::shared_ptr<Data> sptr = std::make_shared<Data>(arr, 6);
        // exception
    }
    catch (const std::exception &e)
    {
        std::cerr << e.what() << '\n';
    }
}