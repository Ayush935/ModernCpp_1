#include <iostream>
#include <vector>

class Data
{
private:
    int _id;
    std::vector<int> _readings;
    int * _extra_values;
    int _N;
public:
    Data(int id,std::vector<int> readings,int *base,int n) 
    : _id{id}, _readings{readings},_N{n}{
        int *_extra_values = (int*) malloc(4*n);

        for(int i=0;i<n;i++){
            _extra_values[i] = base[i];
        }
    }
    ~Data() {
        delete [] _extra_values;
    }
};

int main(){
    try
    {   
        int arr[3] = {100,200,300};
        Data* ptr = new Data(101,std::vector<int>{10,20},arr,3);
        std::cout<<"Hello";
        //do some operation
        delete ptr;
    }
    catch(const std::exception& e)
    {
        std::cerr << e.what() << '\n';
    }
    
}