#include <iostream>

class Data
{
private:
    int *m_values;
    std::size_t m_size;
public:
    Data(/* args */) {}
    ~Data() {}
};

/*
  1) destructor is always triggered before object is derived
  step a) I will make one object of class data
      Data * ptr = new Data(......)

       [10  | 20  |  30]
        ^
        |
        |
        [0X100H   |   3]

  step b) This object's pointer will be saved will be saved in the wrapper
  inside m_ptr

  [        [0X111H]]
  step c) when wrapper object goes out of scope,
  destructor of wrapper will be called 
                  delete data object!

  step d) since delete was called on a class type, destructor of that particular class will also be called
*/
template <typename T>

class Wrapper
{
private:
    T *m_ptr;
public:
    Wrapper(/* args */) {}
    ~Wrapper() {
        delete m_ptr;  
    }
};

