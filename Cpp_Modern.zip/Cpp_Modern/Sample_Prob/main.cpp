#include <iostream>
#include "Functions.h"

int main(){
    Container data;
    CreateObjects(data);
    int n;
    std::cout<<"Enter value of n"<<std::endl;
    bool check = false;
    while (!check)
    {
         try{
        std::cin>>n;
        if(!(n>0 && n<=3)){
            throw std::invalid_argument("THere are only 3 objects int the container");
        }
        check = true;
        }
        catch(std::exception &e){
            std::cout<<e.what()<<std::endl;
        }
    }
   
    std::cout<<"Find Vehicles for "<< n <<" insttances "<<std::endl;
    FindVehicles(data,n);
    int type;
    std::cout<<"Enter Tourist Vehicle type 0 1 2"<<std::endl;
    std::cin>>type;
    AverageBalance(data,type);
    std::cout<<"Maximum is as follows "<<std::endl;
    FindMaxPerHourBookinCharge(data);
    int c;
    std::cout<<"enter the number to be printed "<<std::endl;
    check = false;
    while (!check)
    {
         try{
        std::cin>>c;
        if(!(c>0 && c<=3)){
            throw std::invalid_argument("THere are only 3 objects please take value less than 3 or equal to 3");
        }
        check = true;
        }
        catch(std::exception &e){
            std::cout<<e.what()<<std::endl;
        }
    }
    Print(data,c);
}