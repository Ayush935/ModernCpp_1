#ifndef PERMIT_H
#define PERMIT_H

#include <iostream>
#include "PermitType.h"

class Permit
{
private:
    std::string _serialNumber;
    PermitType _ptype;
    int _permit_duration_left;

public:
    Permit()= default;
    Permit(const Permit&)=delete;
    Permit &operator=(const Permit&)=delete;
    Permit(Permit &&)=delete;
    Permit &operator=(Permit &&)=delete;
    ~Permit()=default;
    Permit(std::string snumber,PermitType pType,int durationLeft);
    std::string serialNumber() const { return _serialNumber; }

    PermitType ptype() const { return _ptype; }
    void setPtype(const PermitType &ptype) { _ptype = ptype; }

    int permitDurationLeft() const { return _permit_duration_left; }
    void setPermitDurationLeft(int permit_duration_left) { _permit_duration_left = permit_duration_left; }

    friend std::ostream &operator<<(std::ostream &os, const Permit &rhs);
};

#endif // PERMIT_H
