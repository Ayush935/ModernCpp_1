#include "Permit.h"

std::ostream &operator<<(std::ostream &os, const Permit &rhs) {
    os << "_serialNumber: " << rhs._serialNumber
       << " _ptype: " << static_cast<int>(rhs._ptype)
       << " _permit_duration_left: " << rhs._permit_duration_left;
    return os;
}

Permit::Permit(std::string snumber, PermitType pType, int durationLeft)
    :_serialNumber{snumber}, _ptype{pType},_permit_duration_left{durationLeft}
{
}