#include "Functions.h"
#include "Permit.h"


void CreateObjects(Container &data)
{
    data.push_back(new TouristVehicle("MX0044",TouristVehicleType::CAB,5,4.7f,new Permit("5678",PermitType::LEASE,5)));
    data.push_back(new TouristVehicle("MX0044",TouristVehicleType::CAB,5,4.7f,new Permit("5678",PermitType::LEASE,5)));
    data.push_back(new TouristVehicle("MX0044",TouristVehicleType::CAB,5,4.7f,new Permit("5678",PermitType::LEASE,5)));
   
};

void FindVehicles(Container &data, int n)
{
    for(TouristVehicle *ptr: data){
        if(ptr->seatCount()>=4 && static_cast<int>(ptr->permit()->ptype())==1){
            std::cout<<*ptr<<std::endl;
        }
    }
}

void AverageBalance(Container &data, int type)
{   
    float sum =0;
    for(TouristVehicle *ptr: data){
        if(static_cast<int>(ptr->type())==type){
            sum = sum + ptr->perHourBookingCharge();
        }
    }

    std::cout<<"Average is "<<static_cast<float>(sum/3)<<std::endl;
}

void FindMaxPerHourBookinCharge(Container &data)
{
    float max =0;
    for(TouristVehicle *ptr:data){
        if(ptr->perHourBookingCharge()>max){
            max=ptr->perHourBookingCharge();
        }
    }
    for(TouristVehicle *ptr:data){
        if(ptr->perHourBookingCharge()==max){
            std::cout<<"Serial NUmber is for max booking charge "<<ptr->permit()->serialNumber()<<std::endl;
            break;
        }
    }
}

void Print(Container &data, int n)
{ 
    for(int i=0;i<n;i++){
        std::cout<<*data[i]<<std::endl;
    }
}
