#ifndef TOURISTVEHICLE_H
#define TOURISTVEHICLE_H

#include <iostream>
#include "TouristVehicleType.h"
#include "Permit.h"

class TouristVehicle
{
private:
    std::string _number{"MX000"};
    TouristVehicleType _type{TouristVehicleType::CAB};
    int _seatCount{0};
    float _per_hour_booking_charge{0.0f};
    Permit* _permit{nullptr};
public:
    TouristVehicle()= default;
    TouristVehicle(const TouristVehicle&)=delete;
    TouristVehicle &operator=(const TouristVehicle&)=delete;
    TouristVehicle(TouristVehicle &&)=delete;
    TouristVehicle &operator=(TouristVehicle &&)=delete;
    TouristVehicle(std::string number,TouristVehicleType type,int count,float charge,Permit* permit);
    ~TouristVehicle()=default;

    std::string number() const { return _number; }

    TouristVehicleType type() const { return _type; }

    void setType(const TouristVehicleType &type) { _type = type; }

    int seatCount() const { return _seatCount; }

    void setSeatCount(int seatCount) { _seatCount = seatCount; }

    float perHourBookingCharge() const { return _per_hour_booking_charge; }
    void setPerHourBookingCharge(float per_hour_booking_charge) { _per_hour_booking_charge = per_hour_booking_charge; }

    Permit* permit() const { return _permit; }


    friend std::ostream &operator<<(std::ostream &os, const TouristVehicle &rhs);

    friend std::ostream &operator<<(std::ostream &os, const TouristVehicle &rhs);
};



#endif // TOURISTVEHICLE_H
