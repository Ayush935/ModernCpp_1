#include "TouristVehicle.h"

std::ostream &operator<<(std::ostream &os, const TouristVehicle &rhs) {
    os << "_number: " << rhs._number
       << " _type: " << static_cast<int>(rhs._type)
       << " _seatCount: " << rhs._seatCount
       << " _per_hour_booking_charge: " << rhs._per_hour_booking_charge
       << " _permit: " << *(rhs._permit);
    return os;
}

TouristVehicle::TouristVehicle(std::string number, TouristVehicleType type, int count, float charge, Permit *permit)
    : _number{number}, _type{type}, _seatCount{count},_per_hour_booking_charge{charge}
{
    _permit = permit;
}