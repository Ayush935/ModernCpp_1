#ifndef FUNCTIONS_H
#define FUNCTIONS_H

#include <iostream>
#include <vector>
#include "TouristVehicle.h"
#include "TouristVehicleType.h"

using Container = std::vector<TouristVehicle*>;

void CreateObjects(Container &data);

void FindVehicles(Container &data,int n);

void AverageBalance(Container &data, int type);

void FindMaxPerHourBookinCharge(Container &data);

void Print(Container &data,int n);


#endif // FUNCTIONS_H
