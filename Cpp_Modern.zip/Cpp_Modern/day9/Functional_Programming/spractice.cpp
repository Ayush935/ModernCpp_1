#include <iostream>
#include <functional>
#include <vector>

// Funtion pointer
/*
void Square(int number){
   std::cout<<number*number<<std::endl;
};

void Cube(int number){
   std::cout<<number*number*number<<std::endl;
};

void Adaptor(int number,void (*ptr)(int)){
   (*ptr)(number);
};

int main(){
    void (*ptr)(int) = &Square;
    void (*ptr2)(int) = &Cube;
    Adaptor(10, &Square);
     Adaptor(10, &Cube);
}
*/

// Lamda Function and 

/*
void Square(int number){
   std::cout<<number*number<<std::endl;
};

void Cube(int number){
   std::cout<<number*number*number<<std::endl;
};

void Adaptor(int number,std::function<void(int)>fns){
   (fns)(number);
};


int main(){

   Adaptor(10, &Square);
   Adaptor(10, 
           [](int number)                             
           {std::cout<<number*number<<std::endl;});//Lamda Function
}
*/


// Function Wrappera
/*
void Square(int number){
   std::cout<<number*number<<std::endl;
};

void Cube(int number){
   std::cout<<number*number*number<<std::endl;
};

short INput(){
    short choice{-1};
    std::cout<<"Enter the number 0 for Square and 1 for Cube"<<std::endl;
    std::cin>>choice;
    return choice;
}

void Adaptor(int number, std::function<void(int)>fns){
    (fns)(number);
}

int main(){
    std::vector<std::function<void(int)>> fns{
       Square,
       Cube
    };
    
    short choice = INput();

    if(choice == -1){
        Adaptor(
            10,
            fns[0]
        );
    }
    else{
        Adaptor(
            10,
            fns[choice]
        );
    }
}

*/


//Function Wrapper along with lamda function and Adaptor
/*

void Adaptor(const std::vector<int>&data,std::function<int(int)>fns){
     for(int  ptr: data){
         std::cout<<(fns)(ptr)<<std::endl;
     }
};


int main(){
   Adaptor(
      {1,2,3,4,5},
      [](int number)
      {return number*number;}
   );
}
*/

bool Divide_7(int number){
    return number%7 == 0;
}

bool Divide_7_11(int number){
    return number%7 == 0 && number%11==0;
}

bool Prime_num(int number){
   if(number==0 || number ==1){
      return false;
   }

   if(number<0){
      std::runtime_error("Negative value");
   }

   for(int i=2;i<number;i++){
      if(number%i==0){
         return false;
      }
   }
   return true;
}

void Adaptor(const std::vector<int>&data,std::function<bool(int)>fns){
   if(data.empty()){
      throw std::runtime_error("data is empty");
   }
   for(int  ptr: data){
      if((fns)(ptr)){
          std::cout<<ptr<<std::endl;
      }
   }
}

short Input(){
   short choice{-1};
   std::cout<<"Enter the value 0 for Divide by 7, 1 for Divisible by 7 and 11, 2 for Prime numbers"<<std::endl;
   std::cin>>choice;
   return choice;
}

int main(){
   std::vector<std::function<bool(int)>> fns{
      Divide_7,
      Divide_7_11,
      Prime_num
   };
   
   short choice = Input();
   
   if(choice==-1){
      Adaptor(
      std::vector<int>{1,2,3,4,5,6,7,11},
      [](int number)
      {return number%2 !=0;}
      );
   }
   else{
      Adaptor(
      std::vector<int>{1,2,3,4,5,6,7,11},
      fns[choice]
   );
   }
   


}