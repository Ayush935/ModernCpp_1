/*
  1) A function which is a one time-usable logic

  2) Normal top-level global functions are stored in code segment.
     They have global access level. I want to create local-scoped functions
*/

#include <iostream>
#include <functional>

void Square(int number)
{
    std::cout << number * number;
}

void Adaptor(int number, std::function<void(int)> fn)
{
    fn(number);
}

/*
  void Square(int number){
}

int main(){
    int Square = 10;    not possible
}


*/

/*
  In lamdas return type writing is not mandatory
  [](int number)  {
    std::cout<<number*number;
    }
*/

int main()
{
    // Square(100);

    Adaptor(10, &Square);

    Adaptor(
        10,
        [](int number) -> void
        {
            std::cout << number * number;
        }
    );                                                        //one time use lambdas

    /*
      10,
        [](int number) -> void
        {
            std::cout << number * number;
        }
    */

   std::vector<int> data{1,2,3,4,5};

   int ans = std::count_if(
      data.begin(),
      data.end(),

      [](int number) { return number % 2 == 0;}
   );
}