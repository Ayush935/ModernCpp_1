#include <iostream>
#include <vector>
#include <functional>  //modern cpp thing

void Square(const std::vector<int>& data){
   if(data.empty()){
    throw std::runtime_error("data is empty!");
   }
   
   /*
     for each integer called "val" in data,
     calculate square of val
   */
   for(int val: data){
    std::cout<<val*val<<"\n";
   }
}

void Cube(const std::vector<int>& data){
   if(data.empty()){
    throw std::runtime_error("data is empty!");
   }
   
   /*
     for each integer called "val" in data,
     calculate cube of val
   */
   for(int val: data){
    std::cout<<val*val*val<<"\n";
   }
}

/*
  Adaptor is a function which takes 2 parameters;
a) constant lvalue refernce to a std::vector of integers
b) pointer to a function which has the following signature
   - accept one const lvalue reference to a vector of integers
   - returns void
 Adaptor also retuurns void
*/
/*
void Adaptor(const std::vector<int>& data,  void (*logic) (const std::vector<int>& )){
    if(data.empty()){
    throw std::runtime_error("data is empty!");
   }

  (*logic)(data);
}

*/

/*
  Adaptor is a function which takes 2 parameters;
a) constant lvalue refernce to a std::vector of integers
b) A function wrapper which wrap a function of following signatures
   - accept one const lvalue reference to a vector of integers
   - returns void
 Adaptor also returns void
*/
void Adaptor(const std::vector<int>& data,std::function< void (const std::vector<int>&)> fn){
    if(data.empty()){
    throw std::runtime_error("data is empty!");
   }

  (fn)(data);
}



int main(){
    Square(std::vector<int> {1,2,3,4,5});
    Square(std::vector<int> {1,21,32,34,5});
    
    /*
    void (*ptr) (const std::vector<int>& ) = &Square;
    void (*ptr1)(const std::vector<int>& ) = &Cube;
    */
    
    
    //user
    Adaptor(std::vector<int> {1,2,3}, &Square);
    Adaptor(std::vector<int> {1,2,3}, &Cube);
}


/*
 BMW : Workshop engineers
             ---> diagnostics

               |   Function(carUnit, logic_for_diagnosis)
*/