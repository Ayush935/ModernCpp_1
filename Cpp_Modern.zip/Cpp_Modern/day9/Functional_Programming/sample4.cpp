#include <iostream>
#include <functional>

//adapter
void Adaptor(const std::vector<int>& data, std::function<bool (int)> fn){
    for(int val : data){
        if( fn(val)){
            std::cout<<val<<"\n";
        }
    }
}                 // filters 

//built in filters 
bool Mod7(int number){
    return number % 7 == 0;
}

bool DivBy7_11(int number){
    return number % 7 == 0 && number % 11 == 0;
}

bool IsPrime(int number){
    if(number == 0 || number == 1){
        return false;
    }

    if(number < 0){
        throw std::runtime_error("Negative number");
    }

    for(int counter= 2;counter<number;counter++){
        if(number % counter == 0){
            return false;
        }
    }

    return true;
}

// function to ask integers from users
short TakeInput(){
    short choice{-1};
    std::cout<< "Enter 0 for 7 & 11 check, 1 for Mod 7, 2 for Prime";
    std::cin>>choice;
}

int main(){

    std::vector<std::function<bool(int)>> fns{     //function wrapper
        DivBy7_11,  //0
        Mod7,       //1
        IsPrime     //2
    };
    
    short choice = TakeInput();

    if(choice == -1){
       Adaptor(
        std::vector<int> {1,2,3,4,5},
        [](int number){return number%2 != 0;}
       );
    }
    else{
       Adaptor(
        std::vector<int> {1,2,3,4,5},
        fns[choice]
       );
    }
    

    

}





/*
  Class X and Class Y are connected by a solid line with unfilled triangular arrowhead to class Y. 
  Class Y is written in italics what is the class Y 
*/