#include <iostream>

/*
  i want to design a Adaptor that accepts
  a) A vector of integers
  b) A logic that works on a single item at a time. 
     This logic should "filter" the input data and only display values which satisfy the requirements of the logic
     E.g : from a vector of 1,2,3,4,5  , logic of "even numbers" should only display
       2
       4 
*/

#include <functional>

void Adaptor(const std::vector<int>& data, std::function<bool (int)> fn){
    for(int val : data){
        if( fn(val)){
            std::cout<<val<<"\n";
        }
    }
}

// filters  
int main(){
    Adaptor(
        std::vector<int> {1,2,3,4,5},
        [](int number){return number%2 == 0;}
    );

    Adaptor(
        std::vector<int> {1,2,3,4,5},
        [](int number){return number%2 != 0;}
    );

}