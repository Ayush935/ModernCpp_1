/*
 LIFO : LAST inserted item must always be the first one to get out

 modify to access to only one position

 Stack : fixed size or dynamically resizable
 - internally for storing data, what would be your data container?

 shallow copy s2-----> [10,20,30] <------s1
               ^
*/

#include <iostream>

template <typename T>
class Stack
{
private:
    T* m_data{nullptr};  //array is used as backend for my stack;
    int m_top{-1};
    int m_size{0};

public:
    
    Stack()= default;
    //Stack(const Stack&) = default;   //shallow copy
    Stack(const Stack<T>&);  //deep copy  
    Stack<T>& operator=(const Stack<T>&);
    Stack(Stack<T> &&)= default;
    Stack<T>& operator=(Stack<T> &&) = default;
    ~Stack();
    Stack(T* elements, int size);
    void Push(T val);
    void Pop();
    T peek();
    std::size_t Size();
    /*
      take 2 stacks. Add element of stack 2 (rhs)
      into stack 1(this)
    */
    void operator+(const Stack<T>& rhs);
};

template <typename T>
inline Stack<T>::Stack(const Stack<T> &rhs)
{
    this->m_top = rhs.m_top;
    this->m_size = rhs.m_size;

    // ask for space for a total of "_size" number of elements
    //of type T
    this->m_data = new T[rhs.m_size];
    for(int i=0;i<rhs.m_size;i++){
        this->m_data[i] = rhs.m_data[i];
    }
}

template <typename T>
inline Stack<T> &Stack<T>::operator=(const Stack<T> &rhs)
{
    // TODO: insert return statement here
    this->m_top = rhs.m_top;
    this->m_size = rhs.m_size;

    // ask for space for a total of "_size" number of elements
    //of type T
    m_data = new T[m_size];
    for(int i=0;i<m_size;i++){
        this->m_data[i] = rhs.m_data[i];
    }

    return *this;
}



template <typename T>
inline Stack<T>::~Stack()
{
    if(m_data){
        delete [] m_data;
    }
}

template <typename T>
inline Stack<T>::Stack(T *elements, int size)
{   
    if(size <= 0){
        throw std::runtime_error("SIze is invalid");
    }
    // ask for memory from OS for total of size number of elements
    this->m_data = new T[size];
    
    //now take data from user and insert into stack
    // m_data = new T[elements.m_size];
    for(int i=0;i<size;i++){
        ++m_top;
        this->m_data[this->m_top] = elements[i];
    }

    this->m_size = size;
}

template <typename T>
inline void Stack<T>::Push(T val)
{   
    this->m_top++;
    this->m_data[this->m_top] = val;
    this->m_size +=1;
}

template <typename T>
inline void Stack<T>::Pop()
{
    if(this->m_size==0){
        throw std::runtime_error("size is zero");
    }
    // --m_top;
    // --m_size;
    this->m_top--;
    this->m_size--;
}

template <typename T>
inline T Stack<T>::peek()
{
    if(m_size == 0){
        throw std::runtime_error("stack is empty");
    }

    return m_data[m_top];
}

template <typename T>
inline std::size_t Stack<T>::Size()
{
    return m_size;
}
