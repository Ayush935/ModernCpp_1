#include "stack.hpp"

int main(){
    int arr[5];
    try{
       Stack <int>stack1(arr,5);
       stack1.Push(10);
       stack1.Push(10);
       stack1.Push(10);
       stack1.Push(10);
       stack1.Push(10);
       stack1.Push(10);

       std::cout<<stack1.peek()<<"\t"<<stack1.Size();
       stack1.Pop();
       std::cout<<"After pop"<<"\n";
       std::cout<<stack1.peek()<<stack1.Size();
    }
    catch(std::runtime_error& ex){
    std::cerr<<ex.what()<<std::endl;
    } 

    return 0;
}