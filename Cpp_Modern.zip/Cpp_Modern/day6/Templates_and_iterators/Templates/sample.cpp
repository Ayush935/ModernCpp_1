#include <iostream>

/*
  DIsplay is a function that accepsts one reference of some data type T and use << operstor with data as rhs operand
*/

template <typename T>       // capital T is typename , substitute capital T during pre processing steps in compiler,
                            // T replace with arguments, compiler does this 
void Display (T &arg) {
    std::cout<<arg<<"\n";
}

template <typename T>
void Add(T n1, T n2){
    std::cout<<n1+n2<<"\n";
}

template <typename T,typename A>
void Addition(T n1, A n2){
    std::cout<<n1+n2<<"\n";
}
// template are not the final version , after rplacement 
// GENERIC PROGRAMMING : Writing logic which works "generally" with all type OR writing type agnostic logic!
/*
void Display (int &arg) {
    std::cout<<arg<<"\n";
}

void Display(std::string &arg){
    std::cout<<arg<<"\n";
}

void Display(float &arg){
    std::cout<<arg<<"\n";
}

*/

int main(){
    int n1 = 10;
    Display<int>(n1);
    std::string _name  = "Ayush";
    Display<std::string>(_name);
    float f1{0.0f};
    Display<float>(f1);
    Add<int>(10,20);
    Add<float>(10.7f,9.56f);
    Addition<int,float>(10,5.4f);
}