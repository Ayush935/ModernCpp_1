// [10      20     30    40    50]
// 0x100H 0x104H 0x108H
// nth position -  base address + i*size of 1 element
/*
   0000 0000
   0000 0000
   0000 0000
   0000 1010
*/

// stl is set of illusions of all data structures 


/*
  operations:
  a) first item
  b) The last item
  c) access random positioned item
  d) access something based on a label
  e) add an element
  f) remove an element* (AT LEAST MAKE PEOPLE BELIEVE THAT)
  g) 
*/


/*
   array 
      - size : fixed
      - storage pattern : continous
      - random access : YES!
      - inserting element : NO
      - update : YES
      - how many elements are accessible : ALL
      - internal implementation : static/variable
      - iteration allowed? YES OR NO!
      - removing element  : NO
      - 
*/

/*
Arrays/vector
4th elemnt : base address + 4 * (size of each address)  
             = 100 + 4*4 = 116

singly linked list
how to access element at Nth position in a list:
   - start from element 1;
   - go to next element , repeat this process N-1 times

Map:
   To access an element N, you need label/key of N

   - hashing mechanism : std:unordered map
   - self balancing tree mechanism - std::MAP
*/

/*
ITERATORS: they are abstraction over pointers to elements in a container
Encapsulate the internal representation of pointers to elements,
Abstract the mechanism of going from one element to next
*/

#include <iostream>
#include <array>

template <typename T>
using Array = std::array<T,5>;

template <typename T> 
void Insert(Array<T>& data,int position,const int val){
   data[ position ] = val;
}

template <typename T>
void Display(const Array<T>& data){
   for(auto itr = data.begin(); itr != data.end();++itr){
      std::cout<<*itr<<"\n";
   }
   std::cout<<"\n";
   //reverse
   //auto
   for(Array<T>::iterator itr = data.begin(); itr != data.end();++itr){
       std::cout<<*itr<<"\n";
   }
}

template <typename T>
int FindElementAtIndexN(const Array<T>&data, unsigned N){
   return data[N];
}

/*
  class Array<int,5>::iterator{
   operator++(){
      base address plus 1
   }
  }
*/

int main(){

}