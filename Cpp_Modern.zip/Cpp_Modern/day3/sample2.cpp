#include <iostream>

class Parent
{
private:
    std::string _surname;
public:
    //function exists in parent and child both, but it is not marked virtual(without upcasting)
    void non_virtual_fn_in_parent_child(){std::cout<<"parent output fromfunction";}

    //function only exists in parent, not overriden, not marked  (upcasting and normal case both)
    void Test(){std::cout << "helo  oooo";}
    void ParentOnlyFunctionTest(){std::cout<<"helloooooooo";}
    virtual void Display()  {std::cout << "Parent Class display fn called ";}
    Parent(std::string surname): _surname(surname) {}
    ~Parent() {std::cout<<"Parent destructor called\n";}

    std::string surname() const { return _surname; }

    void setSurname(const std::string &surname) { _surname = surname; }
    
    
};

class Child: public Parent
{
private:
    std::string _name;
public:


    Child(std::string surname,std::string name) : Parent(surname) {_name = name;} 
    ~Child() {std::cout << "Child destructor called";}
    void Display() override {std::cout << "CHild class Display fn called\n";}

    std::string name() const { return _name; }
    void setName(const std::string &name) { _name = name; }

};

/*
  In case of upcasting,
  for non-virtual functions, compiler does not care about object RHS 
  for virtual functions, compiler will surely consider object type also
  by finding in the 
*/

int main(){
    Parent* p1 = new Parent("XYZ");
    p1->Display();  //pointer Parent : object is Parent
    //p1->ParentOnlyFunctionTest();   //Test is a parent only function. Pointer is of type parent
    p1 = new Child("xyz","abc");   //upcasting !
     
    //dynamic cast is used if you want a functionality that exists only in child
    //utilizing the parent pointer but by converting into child type!

    // std::cout<<"name of child is: "<<dynamic_cast<Child*>(p1)->name();
   
    Child* cptr = dynamic_cast<Child*>(p1);
    if(cptr == nullptr){
        std::cerr<<"conversion failed\n";
    }
    else{
        std::cout<<"name of child is: "<<cptr->name();
    }

    Parent p("xyz");

    try{
        Child& ch = dynamic_cast<Child&>(p);
        ch.name(); // risky practices!!!
    }
    catch(std::bad_cast& ex){
        std::cerr << "Casting was way too risky. It failed\n";
    }

}

   /*
    // Car* arr[3] = {c1{},c2{},c3{}};
    //Display can be overriden in every class 
    for(Car* c:arr) {c->Display();}

    Objective : Create object of different child classes and store/process them collectively
                While doing this if a functionality is different in these classes, execute the correct version of the functionality
                based on type!

    Concept : Method/Function Overriding

    What is the base for this idea? : Polymorphism

    Syntatically , how does compiler known function will be changed in child class? : virtual keyword

    Will the compiler block parent class object creation or not

    */