#include <iostream>

int main(){
    int n1=10;
    float f1= 10.21f;
    /*
    integer n3 is assigned the result of f1 foat value converted by cast to integer type
    */
    int n3 = (int) f1; //c-style cast
    //c++ static cast : performs acton at compile time.
    //if conversion fails, we get compile time error
    //Not Designed For POLYMORPHISM RELATED SITUATION

    int n4 = static_cast<int>(f1);

}