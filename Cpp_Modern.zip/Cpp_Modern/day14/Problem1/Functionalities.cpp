#include "Functionalities.h"

FnType1 FindVowelsOfEachWord = [](StringContainer &data)
{
    if (data.empty())
    {
        throw ContainerEmptyDataException("String data is empty");
    }

    for (std::string str : data)
    {
        std::cout << "Vowels in the word " << str << " are ";
        for (int i = 0; i < str.size(); i++)
        {
            if (str[i] == 'a' || str[i] == 'e' || str[i] == 'i' || str[i] == 'o' || str[i] == 'u' || str[i] == 'A' || str[i] == 'E' || str[i] == 'I' || str[i] == 'O' || str[i] == 'U')
            {
                std::cout << str[i] << " ";
            }
        }
        std::cout << std::endl;
    }
};

FnType1 PrintLast3CharactersOfWords = [](StringContainer &data)
{
    if (data.empty())
    {
        throw ContainerEmptyDataException("String data is empty");
    }

    for (std::string str : data)
    {
        std::cout << "Last Three Characters in word " << str << " are ";
        if (str.size() >= 3)
        {
            for (int i = str.size() - 3; i < str.size(); i++)
            {
                std::cout << str[i] << " ";
            }
        }
        else
        {
            for (int i = 0; i < str.size(); i++)
            {
                std::cout << str[i] << " ";
            }
        }

        std::cout << std::endl;
    }
};

void Adaptor(StringContainer &StringData, Container &FunctionData)
{

    if (StringData.empty())
    {
        throw;
    }
    if (FunctionData.empty())
    {
        throw;
    }

    for (int i = 0; i < FunctionData.size(); i++)
    {
        FunctionData[i](StringData);
    }
}

FnType BindedFunction = std::bind(&Adaptor,std::placeholders::_1,std::placeholders::_2);