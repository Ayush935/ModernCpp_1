#include "Functionalities.h"

int main(){

    StringContainer stringData{"Ayush","Bob","Bobby"};
    Container functionData{
        FindVowelsOfEachWord,
        PrintLast3CharactersOfWords
    };

    Adaptor(stringData,functionData);

    BindedFunction(stringData,functionData);
}