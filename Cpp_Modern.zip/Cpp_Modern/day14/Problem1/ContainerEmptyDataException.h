#ifndef CONTAINEREMPTYDATAEXCEPTION_H
#define CONTAINEREMPTYDATAEXCEPTION_H

#include <iostream>
#include <stdexcept>

class ContainerEmptyDataException: std::exception
{
private:
    std::string _msg;
public:
    ContainerEmptyDataException(/* args */) = delete;
    ContainerEmptyDataException(const ContainerEmptyDataException &) = delete;
    ContainerEmptyDataException(ContainerEmptyDataException &&) = delete;
    ContainerEmptyDataException &operator=(const ContainerEmptyDataException &) = delete;
    ContainerEmptyDataException &operator=(ContainerEmptyDataException &&) = delete;
    ~ContainerEmptyDataException() = default;
    ContainerEmptyDataException(std::string msg) : _msg{msg} {}

    std::string What() const { return _msg; }
};

#endif // CONTAINEREMPTYDATAEXCEPTION_H
