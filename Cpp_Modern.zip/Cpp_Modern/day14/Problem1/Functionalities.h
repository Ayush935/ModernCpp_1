#include <vector>
#include <iostream>
#include <functional>
#include "ContainerEmptyDataException.h"

using StringContainer = std::vector<std::string>;

using FnType1 = std::function<void(StringContainer&)>;
using Container = std::vector<FnType1>;

extern FnType1 FindVowelsOfEachWord;
extern FnType1 PrintLast3CharactersOfWords;

void Adaptor(StringContainer&,Container&);

using FnType = std::function<void(StringContainer&,Container&)>;

extern FnType BindedFunction;