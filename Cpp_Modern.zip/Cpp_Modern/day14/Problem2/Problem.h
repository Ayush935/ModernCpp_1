#ifndef PROBLEM_H
#define PROBLEM_H

#include <vector>
#include <iostream>
#include <functional>

using StringContainer = std::vector<std::string>;
using FnType1 = std::function<void(const StringContainer&)>;
using FunctionContainer = std::vector<FnType1>;

class Problem
{
private:
    StringContainer _strings ;
public:
    Problem(/* args */) = delete;
    Problem(const Problem &) = delete;
    Problem(Problem &&) = delete;
    Problem &operator=(const Problem &) = delete;
    Problem &operator=(Problem &&) = delete;
    ~Problem() = default;
    
    Problem(StringContainer& strings): _strings{strings}{}
    static void FindVowelsInStringContainer(const StringContainer& strings);
    static void PrintLast3CharactersOfEachWordInString(const StringContainer& strings);
    static void Adaptor(const StringContainer& strings,const FunctionContainer& functions);

    StringContainer strings() const { return _strings; }

    friend std::ostream &operator<<(std::ostream &os, const Problem &rhs);

};

#endif // PROBLEM_H
