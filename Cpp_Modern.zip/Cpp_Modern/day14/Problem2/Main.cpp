#include "Problem.h"

int main()
{
    StringContainer string1{"Ayush", "Bob", "Bobby"};
    Problem p{string1};
    FunctionContainer functions{
        &Problem::FindVowelsInStringContainer,
        &Problem::PrintLast3CharactersOfEachWordInString,
    };

    p.Adaptor(p.strings(),functions);
}