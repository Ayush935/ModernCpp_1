#include "Problem.h"
#include "ContainerEmptyDataException.h"

void Problem::FindVowelsInStringContainer(const StringContainer &strings)
{
    if (strings.empty())
    {
        throw ContainerEmptyDataException("String data is empty");
    }

    for (std::string str : strings)
    {
        std::cout << "Vowels in the word " << str << " are ";
        for (int i = 0; i < str.size(); i++)
        {
            if (str[i] == 'a' || str[i] == 'e' || str[i] == 'i' || str[i] == 'o' || str[i] == 'u' || str[i] == 'A' || str[i] == 'E' || str[i] == 'I' || str[i] == 'O' || str[i] == 'U')
            {
                std::cout << str[i] << " ";
            }
        }
        std::cout << std::endl;
    }
}

void Problem::PrintLast3CharactersOfEachWordInString(const StringContainer &strings)
{
    if (strings.empty())
    {
        throw ContainerEmptyDataException("String data is empty");
    }

    for (std::string str : strings)
    {
        std::cout << "Last Three Characters in word " << str << " are ";
        if (str.size() >= 3)
        {
            for (int i = str.size() - 3; i < str.size(); i++)
            {
                std::cout << str[i] << " ";
            }
        }
        else
        {
            for (int i = 0; i < str.size(); i++)
            {
                std::cout << str[i] << " ";
            }
        }

        std::cout << std::endl;
    }
}

void Problem::Adaptor(const StringContainer &strings, const FunctionContainer &functions)
{
    if (strings.empty())
    {
        throw ContainerEmptyDataException("strings data is empty");
    }
    if (functions.empty())
    {
        throw ContainerEmptyDataException("functions data is empty");
    }

    for (int i = 0; i < functions.size(); i++)
    {
        functions[i](strings);
    }
}
