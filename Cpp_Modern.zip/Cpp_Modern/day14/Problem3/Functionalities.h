#include <iostream>
#include <functional>
#include <vector>

using FnType = std::function<bool(int)>;
using IntegersContainer = std::vector<int>;

extern FnType IdentifyNumberIsOdd;
extern FnType IdentifyNumberIsEvenAndDivisibleBy4;
extern FnType ApplyFiltersOnInputData;

//using Container = std::vector<FnType>;

void Adaptor(FnType pred,IntegersContainer &data );