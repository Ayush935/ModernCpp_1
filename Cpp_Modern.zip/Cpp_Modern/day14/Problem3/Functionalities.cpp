#include "Functionalities.h"

FnType IdentifyNumberIsOdd = [](int num)
{
    if (num % 2 != 0)
    {
        return true;
    }

    return false;
};

FnType IdentifyNumberIsEvenAndDivisibleBy4 = [](int num)
{
    if (num % 4 == 0)
    {
        return true;
    }
    return false;
};

FnType ApplyFiltersOnInputData = [](int num)
{
    if (num < 0)
    {
        return true;
    }

    return false;
};

void Adaptor(FnType pred, IntegersContainer &data)
{
    if(data.empty()){
        throw;
    }
    bool check = false;
    for(int val :data){
        if(pred(val)){
            check = true;
            std::cout<<val<<std::endl;
        }
    }

    if(!check){
        throw std::runtime_error("No such Cases exists");
    } 
}
