#include "Functionalities.h"

int main(){
    IntegersContainer data{1,2,3,4,5,6,7,8};
    
    try
    {  
        std::cout<<"Odd number"<<std::endl;
        Adaptor(IdentifyNumberIsOdd,data);
        std::cout<<"Divisible by 4"<<std::endl;
        Adaptor(IdentifyNumberIsEvenAndDivisibleBy4,data);
        std::cout<<"Filters on Input Data"<<std::endl;
        Adaptor(ApplyFiltersOnInputData,data);
    }
    catch(const std::exception& e)
    {
        std::cerr << e.what() << '\n';
    }
    
}