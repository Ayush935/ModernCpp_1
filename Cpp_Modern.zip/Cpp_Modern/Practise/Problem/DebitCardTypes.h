#ifndef DEBITCARDTYPE_H
#define DEBITCARDTYPE_H

enum class DebitCardTypes{
    VISA,
    MASTERCARD,
    RUPAY
};

#endif // DEBITCARDTYPE_H
