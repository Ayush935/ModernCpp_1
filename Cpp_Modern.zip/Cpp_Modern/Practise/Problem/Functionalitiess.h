#ifndef FUNCTIONALITIES_H
#define FUNCTIONALITIES_H

#include <vector>
#include "BankAccounts.h"

using Container = std::vector<BankAccounts*>;

void CreateObjects(Container &data);

float AverageAccountBalances(Container &data);

#endif // FUNCTIONALITIES_H
