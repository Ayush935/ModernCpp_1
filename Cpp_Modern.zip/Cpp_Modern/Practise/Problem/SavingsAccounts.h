#ifndef SAVINGSACCOUNTS_H
#define SAVINGSACCOUNTS_H

#include <iostream>
#include "BankAccounts.h"
#include "DebitCards.h"

class SavingsAccounts: public BankAccounts
{
private:
    float _savingsMinBalance;
public:
    SavingsAccounts() = default;
    SavingsAccounts(const SavingsAccounts&) = delete;
    SavingsAccounts(SavingsAccounts &&) = delete;
    SavingsAccounts& operator= (SavingsAccounts &&) = delete;
    SavingsAccounts& operator= (const SavingsAccounts &)  = delete;
    ~SavingsAccounts() = default;

    SavingsAccounts(std::string name,float amount,float minBalance);
    SavingsAccounts(std::string name,float amount,DebitCards *card, float minBalance);

    float savingsMinBalance() const { return _savingsMinBalance; }


    void CalculateInterest() override;

    friend std::ostream &operator<<(std::ostream &os, const SavingsAccounts &rhs);
};

#endif // SAVINGSACCOUNTS_H
