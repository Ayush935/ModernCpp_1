#ifndef BANKACCOUNT_H
#define BANKACCOUNT_H

#include <iostream>
#include "DebitCards.h"

class BankAccounts
{
private:
    static long _counter;
    long _accountNumber {1234567};
    std::string _accountHolderName {""};
    float _balance {0.0f};
    DebitCards *_accountCard{nullptr};
public:
    BankAccounts() = default;
    BankAccounts(std::string name,float amount);
    BankAccounts(std::string name,float amount,DebitCards *card);
    BankAccounts(const BankAccounts&) = delete;
    BankAccounts(BankAccounts &&) = delete;
    BankAccounts& operator= (BankAccounts &&) = delete;
    BankAccounts& operator= (const BankAccounts &)  = delete;
    ~BankAccounts() = default;

    std::string accountHolderName() const { return _accountHolderName; }
    void setAccountHolderName(const std::string &accountHolderName) { _accountHolderName = accountHolderName; }

    float balance() const { return _balance; }

    long long accountNumber() const { return _accountNumber; }

    friend std::ostream &operator<<(std::ostream &os, const BankAccounts &rhs);

    virtual void CalculateInterest()=0;
};

#endif // BANKACCOUNT_H
