#include "DebitCards.h"

DebitCards::DebitCards(short cvv, long cardNumber, std::string cardExpiry, DebitCardTypes cardType)
    : _cvv(cvv), _cardNumber(cardNumber), _cardExpiry(cardExpiry),_cardType(cardType)
{
}

std::ostream &operator<<(std::ostream &os, const DebitCards &rhs) {
    os << "_cvv: " << rhs._cvv
       << " _cardNumber: " << rhs._cardNumber
       << " _cardExpiry: " << rhs._cardExpiry
       << " _cardType: " << static_cast<int>(rhs._cardType);
    return os;
}
