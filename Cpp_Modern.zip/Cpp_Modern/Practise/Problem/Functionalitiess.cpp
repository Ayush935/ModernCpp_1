#include "Functionalitiess.h"
#include "SavingsAccounts.h"


void CreateObjects(Container &data)
{
     data.push_back(
        new SavingsAccounts(
            "Ayush",
             50000.0f,
              new DebitCards(
                123,
                124567,
                "09/34",
                DebitCardTypes::RUPAY
            ),
            10000
        )
    );
    
}

float AverageAccountBalances(Container &data)
{   
    float total = 0.0f;
    for(BankAccounts *ptr : data){
        total = total + ptr->balance();
    }

    return total/data.size();
}