#include <iostream>
#include "Functionalitiess.h"
#include "SavingsAccounts.h"

int main()
{
    Container data;
    CreateObjects(data);
    AverageAccountBalances(data);

    SavingsAccounts *s1 {  new SavingsAccounts(
            "Ayush",
             50000.0f,
              new DebitCards(
                123,
                124567,
                "09/34",
                DebitCardTypes::RUPAY
            ),
            10000
        )};

    std::cout<<*s1<<std::endl;

}