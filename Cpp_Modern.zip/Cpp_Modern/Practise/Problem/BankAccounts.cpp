#include "BankAccounts.h"

long BankAccounts:: _counter = 1000;

BankAccounts::BankAccounts(std::string name, float amount)
   : _accountHolderName{name},_balance{amount},_accountNumber{_counter++}
{
}

BankAccounts::BankAccounts(std::string name, float amount, DebitCards *card)
   : BankAccounts(name,amount)
{
    _accountCard = card;
}

std::ostream &operator<<(std::ostream &os, const BankAccounts &rhs) {
    os << "_accountNumber: " << rhs._accountNumber
       << " _accountHolderName: " << rhs._accountHolderName
       << " _balance: " << rhs._balance;
       if(rhs._accountCard!=nullptr)
         os << " _card: " << *rhs._accountCard;
    return os;
}
