#ifndef DEBITCARD_H
#define DEBITCARD_H

#include <iostream>
#include "DebitCardTypes.h"

class DebitCards
{
private:
    short _cvv;
    long _cardNumber;
    std::string _cardExpiry;
    DebitCardTypes _cardType;

public:
    DebitCards() = default;
    DebitCards(const DebitCards&) = delete;
    DebitCards(DebitCards &&) = delete;
    DebitCards& operator= (DebitCards &&) = delete;
    DebitCards& operator= (const DebitCards &)  = delete;
    ~DebitCards() = default;

    DebitCards(short cvv, long cardNumber,std::string cardExpiry, DebitCardTypes cardType);

    short cvv() const { return _cvv; }

    long cardNumber() const { return _cardNumber; }

    std::string cardExpiry() const { return _cardExpiry; }

    DebitCardTypes cardType() const { return _cardType; }

    friend std::ostream &operator<<(std::ostream &os, const DebitCards &rhs);
};

#endif // DEBITCARD_H
