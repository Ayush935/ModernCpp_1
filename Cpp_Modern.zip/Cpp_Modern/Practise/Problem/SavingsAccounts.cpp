#include "SavingsAccounts.h"

SavingsAccounts::SavingsAccounts(std::string name, float amount, float minBalance)
   : BankAccounts(name,amount), _savingsMinBalance(minBalance)
{
}

SavingsAccounts::SavingsAccounts(std::string name, float amount, DebitCards *card, float minBalance)
   : BankAccounts(name,amount,card), _savingsMinBalance(minBalance)
{
}

std::ostream &operator<<(std::ostream &os, const SavingsAccounts &rhs) {
    os << static_cast<const BankAccounts &>(rhs)
       << " _savingsMinBalance: " << rhs._savingsMinBalance;
    return os;
}

void SavingsAccounts::CalculateInterest()
{
    std::cout<<"Interest is "<<0.04*balance();
}
