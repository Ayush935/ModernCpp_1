#ifndef DEBITCARD_H
#define DEBITCARD_H

#include <iostream>
#include "DebitCardType.h"

class DebitCard
{
private:
    short _cardcvv;
    long long _cardNumber;
    std::string _cardExpiry;
    DebitCardType _cardType;

public:
    DebitCard() = delete;                  // constructor is disabled
    DebitCard(const DebitCard &) = delete; // disable copy constructor
    DebitCard &operator=(const DebitCard &) = delete;
    ~DebitCard() = default;                        // enabling destructor
    DebitCard(DebitCard &&) = delete;            // move constructor is disabled
    DebitCard &operator=(DebitCard &&) = delete; // move assignment - cut paste logic moving obj1 to obj2
    DebitCard(short cvv, long long number, std::string expiry, DebitCardType type);

    short cardcvv() const { return _cardcvv; }

    long long cardNumber() const { return _cardNumber; }

    std::string cardExpiry() const { return _cardExpiry; }

    friend std::ostream &operator<<(std::ostream &os, const DebitCard &rhs);

};

#endif // DEBITCARD_H
