#ifndef BANKACCOUNT_H
#define BANKACCOUNT_H

#include <iostream>
#include "DebitCard.h"

class BankAccount
{
private:
    static long _counter;
    long _accountNumber;
    std::string _accountHolder {""};
    float _accountBalance {0.0f};
    DebitCard* _accountDebitCard {nullptr};

public:
    BankAccount() = default;                   // we are not writing the body, compiler needs to write meaning enabling default constructer
                                               // if i have to disable type  BankAccount() = delete;
    BankAccount(const BankAccount &) = delete; // disable copy constructor
    BankAccount &operator=(const BankAccount &) = delete;
    ~BankAccount() = default;                        // enabling destructor
    BankAccount(BankAccount &&) = delete;            // move constructor is disabled
    BankAccount &operator=(BankAccount &&) = delete; // move assignment - cut paste logic moving obj1 to obj2
    BankAccount(std::string name, float balance);
    BankAccount(std::string name, float balance, DebitCard* card);

    long accountNumber() const { return _accountNumber; }

    std::string accountHolder() const { return _accountHolder; }
    void setAccountHolder(const std::string &accountHolder) { _accountHolder = accountHolder; }

    float accountBalance() const { return _accountBalance; }

    friend std::ostream &operator<<(std::ostream &os, const BankAccount &rhs);

    virtual void CalculateInterest() = 0;

    friend std::ostream &operator<<(std::ostream &os, const BankAccount &rhs);

    friend std::ostream &operator<<(std::ostream &os, const BankAccount &rhs);
};

#endif // BANKACCOUNT_H

/*
scenario 1:
      BankAccount b1;          // constructor

      BankAccount b2 (b1);  //b2 is initialized first

Scenario 2:                    // assignment
      BankAccount b1,b2;
      BankAccount b3(1100.f, "Ayush");
      b2=b3;


Scenario 3:
    /*

    virtual ------

    why?
    i will not make any object
    types are are savings and current

    if i have to store the savings and current in any container then, we have to have general name;
    generalisation i.e BankAccount 

    arr[5] = {acc1,acc2,acc3,acc4,acc5};
    
    while telling compiler to calculateInterest
    compiler compiles arr[0] calculateInterest and the BankAccount is virtual then it checks its child class
    calculateinterst in savings and current   --------> this is virtual

    computer architecture
    computer network
    operating system
    dbms

*/


