#include "Functionalities.h"
#include "SavingsAccount.h"
#include "Functionalitiess.h"


void CreateObjects(Container &data)
{
    // DebitCard* d1 = new DebitCard(123, 1223223, "09/27", DebitCardType::VISA);
    // SavingsAccount* b1 = new SavingsAccount("Ayush",70000.0f,d1,5000.0f);

    data.push_back(
        new SavingsAccount(
            "Ayush",
            70000.0f,
            new DebitCard(
                123,
                1223223,
                "09/27",
                DebitCardType::VISA),
            5000.0f)
    );

    data.push_back(
        new SavingsAccount(
            "Rahul",
            700000.0f,
            new DebitCard(
                133,
                1343223,
                "11/27",
                DebitCardType::VISA),
            15000.0f)
    );
}


float AverageAccountBalance(Container &data)
{
    float total = 0.0f;
    // for(Container::iterator itr = data.begin();itr!=data.end();itr++){
    //    total = total + (*itr)->accountBalance();
    // }
    
    //modern Cpp alternative
    
    for(BankAccount* ptr : data){
        total = total + ptr->accountBalance();
    }

    return total/data.size();
}


