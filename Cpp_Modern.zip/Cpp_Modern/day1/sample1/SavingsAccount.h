#ifndef SAVINGSACCOUNT_H
#define SAVINGSACCOUNT_H

#include <iostream>
#include "DebitCard.h"
#include "BankAccount.h"

class SavingsAccount  : public BankAccount
{
private:
    float _savingsAccountMinimumBalance{5000.0f};

public:
    SavingsAccount() = default;                      // we are not writing the body, compiler needs to write meaning enabling default constructer
                                                     // if i have to disable type  SavingsAccount() = delete;
    SavingsAccount(const SavingsAccount &) = delete; // disable copy constructor
    SavingsAccount &operator=(const SavingsAccount &) = delete;
    ~SavingsAccount() = default;                     // enabling destructor
    SavingsAccount(SavingsAccount &&) = delete;      // move constructor is disabled
    BankAccount &operator=(BankAccount &&) = delete; // move assignment cut-paste logic
    SavingsAccount(std::string name, float balance, DebitCard *card, float minBalance);
    SavingsAccount(std::string name, float balance, float minBalance);

    float savingsAccountMinimumBalance() const { return _savingsAccountMinimumBalance; }

    friend std::ostream &operator<<(std::ostream &os, const SavingsAccount &rhs);

    void CalculateInterest() override;
    
};

#endif // SAVINGSACCOUNT_H
