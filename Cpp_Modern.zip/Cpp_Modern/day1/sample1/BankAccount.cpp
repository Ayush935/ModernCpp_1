#include "BankAccount.h"

long BankAccount::_counter = 900000L;

std::ostream &operator<<(std::ostream &os, const BankAccount &rhs) {
    os << "_accountNumber: " << rhs._accountNumber
       << " _accountHolder: " << rhs._accountHolder
       << " _accountBalance: " << rhs._accountBalance;
    return os;
}

BankAccount::BankAccount(std::string name, float balance)
    : _accountBalance{balance}, _accountHolder{name}, _accountNumber{_counter++}
{
}

BankAccount::BankAccount(std::string name, float balance, DebitCard *card)
    : BankAccount(name, balance)
{
    _accountDebitCard = card;
}




