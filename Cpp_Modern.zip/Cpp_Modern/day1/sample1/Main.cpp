#include "Functionalities.h"

int main(){
    Container data;
    CreateObjects(data);
    AverageAccountBalance(data);

}