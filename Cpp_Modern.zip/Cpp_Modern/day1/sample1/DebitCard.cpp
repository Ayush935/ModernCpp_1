#include "DebitCard.h"

std::ostream &operator<<(std::ostream &os, const DebitCard &rhs) {
    os << "_cardcvv: " << rhs._cardcvv
       << " _cardNumber: " << rhs._cardNumber
       << " _cardExpiry: " << rhs._cardExpiry
       << " _cardType: " << static_cast<int>(rhs._cardType);
    return os;
}

DebitCard::DebitCard(short cvv, long long number, std::string expiry, DebitCardType type)
    : _cardcvv{cvv}, _cardNumber{number}, _cardExpiry{expiry}, _cardType{type}
{
}
