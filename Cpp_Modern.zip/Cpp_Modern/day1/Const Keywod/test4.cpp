#include <iostream>
#include <stdexcept>
#include <gtest/gtest.h>
#include <climits>

class FuelRatio {
public:
    static std::pair<int, int> calculateFuelRatio(int gasolineFlowRate1, int totalFlowRate1, 
                                                   int gasolineFlowRate2, int totalFlowRate2) {
        if (totalFlowRate1 == 0 || totalFlowRate2 == 0) {
            throw std::invalid_argument("Total flow rate cannot be zero");
        }

        long long numerator = static_cast<long long>(gasolineFlowRate1) + static_cast<long long>(gasolineFlowRate2);
        long long denominator = static_cast<long long>(totalFlowRate1) + static_cast<long long>(totalFlowRate2);

        // Check for overflow
        if (numerator > INT_MAX || denominator > INT_MAX || numerator > denominator) {
            throw std::overflow_error("Resulting fuel ratio is unrealistic");
        }

        return {static_cast<int>(numerator), static_cast<int>(denominator)};
    }
};

// Test cases
TEST(FuelRatioTest, ValidInput) {
    auto result = FuelRatio::calculateFuelRatio(1, 2, 1, 2);
    EXPECT_EQ(result.first, 2);
    EXPECT_EQ(result.second, 4);
}

TEST(FuelRatioTest, InvalidInputZeroTotalFlowRate) {
    EXPECT_THROW(FuelRatio::calculateFuelRatio(1, 0, 1, 2), std::invalid_argument);
    EXPECT_THROW(FuelRatio::calculateFuelRatio(1, 2, 1, 0), std::invalid_argument);
}

TEST(FuelRatioTest, EdgeCaseZeroGasolineFlow) {
    auto result = FuelRatio::calculateFuelRatio(0, 1, 1, 2);
    EXPECT_EQ(result.first, 1);
    EXPECT_EQ(result.second, 3);
}

TEST(FuelRatioDeathTest, DeathTestZeroTotalFlowRate) {
    EXPECT_THROW(FuelRatio::calculateFuelRatio(1, 0, 1, 2), std::invalid_argument);
    EXPECT_THROW(FuelRatio::calculateFuelRatio(1, 2, 1, 0), std::invalid_argument);
}

TEST(FuelRatioDeathTest, DeathTestOverflow) {
    EXPECT_THROW(FuelRatio::calculateFuelRatio(INT_MAX, INT_MAX - 1, INT_MAX - 1, INT_MAX - 1), std::overflow_error);
}

int main(int argc, char **argv) {
    ::testing::InitGoogleTest(&argc, argv);
    return RUN_ALL_TESTS();
}