// Online C++ compiler to run C++ program online
// #include <iostream>
// #include <gtest/gtest.h>

// TEST(exampleTest1, test1)
// {
//     ASSERT_EQ(1,1);
// }

// int main(int argc, char **argv)
// {
//     testing::InitGoogleTest(&argc, argv);
//     return RUN_ALL_TESTS();
// }

#include <iostream>
#include <stdexcept>
#include <gtest/gtest.h>
#include <climits>

class Fraction
{
public:
    Fraction(int numerator, int denominator)
    {
        if (denominator == 0)
        {
            throw std::invalid_argument("Denominator cannot be zero");
        }
        num = numerator;
        den = denominator;
        reduce();
    }

    Fraction add(const Fraction &other) const
    {
        long long newNum = static_cast<long long>(num) * other.den + static_cast<long long>(den) * other.num;
        long long newDen = static_cast<long long>(den) * other.den;

        // Check for overflow
        if (newNum > INT_MAX || newNum < INT_MIN || newDen > INT_MAX || newDen < INT_MIN)
        {
            throw std::overflow_error("Resulting fraction overflows");
        }

        return Fraction(static_cast<int>(newNum), static_cast<int>(newDen));
    }

    void print() const
    {
        std::cout << num << "/" << den << std::endl;
    }

private:
    int num; // numerator
    int den; // denominator

    void reduce()
    {
        int gcd = findGCD(num, den);
        num /= gcd;
        den /= gcd;
    }

    int findGCD(int a, int b) const
    {
        return b == 0 ? a : findGCD(b, a % b);
    }
};

// Test cases
TEST(FractionTest, ValidInput)
{
    Fraction f1(1, 2);
    Fraction f2(1, 2);
    Fraction result = f1.add(f2);
    EXPECT_NO_THROW(result.print());
}

TEST(FractionTest, InvalidInput)
{
    EXPECT_THROW(Fraction(1, 0), std::invalid_argument);
}

TEST(FractionTest, EdgeCaseAddingZero)
{
    Fraction f1(0, 1);
    Fraction f2(1, 2);
    Fraction result = f1.add(f2);
    EXPECT_NO_THROW(result.print());
}

TEST(FractionTest, DeathTestDenominatorZero)
{
    EXPECT_THROW(Fraction(1, 0), std::invalid_argument);
}

TEST(FractionTest, DeathTestOverflow)
{
    EXPECT_THROW(Fraction(INT_MAX, 1).add(Fraction(1, 1)), std::overflow_error);
}

int main(int argc, char **argv)
{
    ::testing::InitGoogleTest(&argc, argv);
    return RUN_ALL_TESTS();
}