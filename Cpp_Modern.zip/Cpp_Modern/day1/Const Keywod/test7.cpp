#include <iostream>
#include <vector>
#include <stdexcept>
#include <gtest/gtest.h>

bool isTransmissionSequenceValid(const std::vector<double>& gearRatios) {
    if (gearRatios.empty()) {
        throw std::invalid_argument("Input vector cannot be empty");
    }

    for (size_t i = 1; i < gearRatios.size(); ++i) {
        if (gearRatios[i] <= gearRatios[i - 1]) {
            return false; // Not in ascending order
        }
    }
    return true; // All ratios are in ascending order
}

// Test cases
TEST(TransmissionSequenceTest, ValidInput) {
    std::vector<double> validRatios = {3.5, 4.2, 5.1, 6.3, 7.5};
    EXPECT_TRUE(isTransmissionSequenceValid(validRatios));
}

TEST(TransmissionSequenceTest, InvalidInputDescendingOrder) {
    std::vector<double> invalidRatios = {7.5, 6.3, 5.1, 4.2, 3.5};
    EXPECT_FALSE(isTransmissionSequenceValid(invalidRatios));
}

TEST(TransmissionSequenceTest, EdgeCaseEmptyVector) {
    std::vector<double> emptyRatios;
    EXPECT_THROW(isTransmissionSequenceValid(emptyRatios), std::invalid_argument);
}

TEST(TransmissionSequenceTest, EdgeCaseSingleElementVector) {
    std::vector<double> singleRatio = {4.0};
    EXPECT_TRUE(isTransmissionSequenceValid(singleRatio)); // A single element is trivially sorted
}

int main(int argc, char **argv) {
    ::testing::InitGoogleTest(&argc, argv);
    return RUN_ALL_TESTS();
}