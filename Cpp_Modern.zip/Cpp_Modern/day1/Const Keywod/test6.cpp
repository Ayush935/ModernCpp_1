#include <iostream>
#include <vector>
#include <cmath>
#include <stdexcept>
#include <gtest/gtest.h>

double calculateDistance(const std::pair<int, int>& point1, const std::pair<int, int>& point2) {
    return sqrt(pow(point2.first - point1.first, 2) + pow(point2.second - point1.second, 2));
}

double calculateRouteDistance(const std::vector<std::pair<int, int>>& routeCoordinates) {
    if (routeCoordinates.empty()) {
        throw std::invalid_argument("Input vector cannot be empty");
    }

    double totalDistance = 0.0;

    for (size_t i = 1; i < routeCoordinates.size(); ++i) {
        totalDistance += calculateDistance(routeCoordinates[i - 1], routeCoordinates[i]);
    }

    return totalDistance;
}

// Test cases
TEST(RouteDistanceTest, ValidInput) {
    std::vector<std::pair<int, int>> route = {{0, 0}, {3, 4}};
    EXPECT_DOUBLE_EQ(calculateRouteDistance(route), 5.0); // Distance between (0,0) and (3,4)
}

TEST(RouteDistanceTest, InvalidInputNegativeCoordinates) {
    std::vector<std::pair<int, int>> route = {{0, 0}, {-3, 4}};
    EXPECT_DOUBLE_EQ(calculateRouteDistance(route), sqrt((-3 - 0) * (-3 - 0) + (4 - 0) * (4 - 0))); // Valid distance calculation
}

TEST(RouteDistanceTest, EdgeCaseEmptyVector) {
    std::vector<std::pair<int, int>> emptyRoute;
    EXPECT_THROW(calculateRouteDistance(emptyRoute), std::invalid_argument);
}

TEST(RouteDistanceTest, EdgeCaseSingleElementVector) {
    std::vector<std::pair<int, int>> singlePoint = {{42, 42}};
    EXPECT_DOUBLE_EQ(calculateRouteDistance(singlePoint), 0.0); // Distance is zero for a single point
}

int main(int argc, char **argv) {
    ::testing::InitGoogleTest(&argc, argv);
    return RUN_ALL_TESTS();
}