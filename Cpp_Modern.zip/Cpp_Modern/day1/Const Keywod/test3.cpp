#include <iostream>
#include <string>
#include <vector>
#include <gtest/gtest.h>

std::vector<std::string> splitString(const std::string& input, const std::string& delimiter) {
    if (delimiter.empty()) {
        throw std::invalid_argument("Delimiter cannot be empty");
    }

    std::vector<std::string> tokens;
    size_t start = 0;
    size_t end = input.find(delimiter);

    while (end != std::string::npos) {
        tokens.push_back(input.substr(start, end - start));
        start = end + delimiter.length();
        end = input.find(delimiter, start);
    }
    
    tokens.push_back(input.substr(start)); // Add the last token
    return tokens;
}

// Test cases
TEST(SplitStringTest, ValidInput) {
    std::string input = "hello world";
    std::string delimiter = " ";
    std::vector<std::string> result = splitString(input, delimiter);
    EXPECT_EQ(result.size(), 2);
    EXPECT_EQ(result[0], "hello");
    EXPECT_EQ(result[1], "world");
}

TEST(SplitStringTest, InvalidInputEmptyDelimiter) {
    EXPECT_THROW(splitString("hello world", ""), std::invalid_argument);
}

TEST(SplitStringTest, EdgeCaseEmptyString) {
    std::string input = "";
    std::string delimiter = ",";
    std::vector<std::string> result = splitString(input, delimiter);
    EXPECT_EQ(result.size(), 1);
    EXPECT_EQ(result[0], "");
}

TEST(SplitStringDeathTest, DeathTestEmptyDelimiter) {
    EXPECT_THROW(splitString("some string", ""), std::invalid_argument);
}

int main(int argc, char **argv) {
    ::testing::InitGoogleTest(&argc, argv);
    return RUN_ALL_TESTS();
}