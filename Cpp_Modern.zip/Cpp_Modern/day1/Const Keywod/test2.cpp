#include <iostream>
#include <vector>
#include <gtest/gtest.h>

class Stack {
public:
    Stack() {}

    void push(int value) {
        elements.push_back(value);
    }

    int pop() {
        if (elements.empty()) {
            throw std::runtime_error("Cannot pop from an empty stack");
        }
        int top = elements.back();
        elements.pop_back();
        return top;
    }

    bool empty() const {
        return elements.empty();
    }

    size_t size() const {
        return elements.size();
    }

private:
    std::vector<int> elements;
};

TEST(StackTest, EmptyStack) {
    Stack stack;
    EXPECT_TRUE(stack.empty());
    EXPECT_EQ(stack.size(), 0);
}

TEST(StackTest, PushAndPop) {
    Stack stack;
    stack.push(1);
    stack.push(2);
    stack.push(3);
    EXPECT_EQ(stack.size(), 3);
    EXPECT_EQ(stack.pop(), 3);
    EXPECT_EQ(stack.size(), 2);
    EXPECT_EQ(stack.pop(), 2);
    EXPECT_EQ(stack.size(), 1);
    EXPECT_EQ(stack.pop(), 1);
    EXPECT_TRUE(stack.empty());
    EXPECT_EQ(stack.size(), 0);
}

TEST(StackDeathTest, PopFromEmptyStack) {
    Stack stack;
    EXPECT_THROW(stack.pop(), std::runtime_error);
}

int main(int argc, char **argv) {
    ::testing::InitGoogleTest(&argc, argv);
    return RUN_ALL_TESTS();
}