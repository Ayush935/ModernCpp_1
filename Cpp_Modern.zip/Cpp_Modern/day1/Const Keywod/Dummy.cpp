#include <iostream>

class Dummy
{
private:
    int _value1;
    float _value2;
public:
    Dummy(int acc1,int acc2): _value1{acc1}, _value2{acc2} {}
    ~Dummy() = default;

    float getValue2() const { return _value2; }
    void setValue2(float value2_) { _value2 = value2_; }

    int getValue1() const { return _value1; }
    void setValue1(int value1_) { _value1 = value1_; }
};

int main()
{   
    //scenario 1 : const with non-pointer primitive variable
    const int n1 = 10;  //n1 is a constant int
    int const n2 = 20;  //n2 is a constant int

    //scenario 2:  pointer with primitive
    int n3 = 99;
    int n4 = 188;
    // 2a
    const int * ptr = &n3;
    //*ptr = 77;   this will give error
    ptr = &n4;  // this is okay

    //2b
    int * const ptr2 = &n3; // ptr2 is a const pointer to an integer
    *ptr2 = 100; //this is okay

    //ptr2 = &n4;  // Not Okay

    //2c
    const int * const ptr3 = &n3;  // ptr 3 is a const pointer to a const integer
    //*ptr3 = 18; // Not okay
    //ptr3 = &n4; // Not okay

    // Scenario 3
    const Dummy d1(102,123.34f);
    //d1.setValue1();  setting cant be done

    
    

}