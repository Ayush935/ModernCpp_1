#include <iostream>
#include <vector>
#include <gtest/gtest.h>

bool isSorted(const std::vector<int>& input) {
    if (input.empty()) {
        throw std::invalid_argument("Input vector cannot be empty");
    }

    for (size_t i = 1; i < input.size(); ++i) {
        if (input[i] < input[i - 1]) {
            return false;
        }
    }
    return true;
}

// Test cases
TEST(IsSortedTest, ValidInput) {
    std::vector<int> sortedVec = {1, 2, 3, 4, 5};
    EXPECT_TRUE(isSorted(sortedVec));
}

TEST(IsSortedTest, InvalidInput) {
    std::vector<int> unsortedVec = {5, 4, 3, 2, 1};
    EXPECT_FALSE(isSorted(unsortedVec));
}

TEST(IsSortedTest, EdgeCaseEmptyVector) {
    std::vector<int> emptyVec;
    EXPECT_THROW(isSorted(emptyVec), std::invalid_argument);
}

TEST(IsSortedTest, EdgeCaseSingleElement) {
    std::vector<int> singleElementVec = {42};
    EXPECT_TRUE(isSorted(singleElementVec));
}

int main(int argc, char **argv) {
    ::testing::InitGoogleTest(&argc, argv);
    return RUN_ALL_TESTS();
}