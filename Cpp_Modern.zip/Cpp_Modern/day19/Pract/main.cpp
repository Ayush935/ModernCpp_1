// Online C++ compiler to run C++ program online
#include <iostream>
#include <thread>
#include <future>
void square(int n){
    std::cout<<n*n<<std::endl;
}

void cube(int n){
    std::cout<<n*n*n<<std::endl;
}
int main() {
    // Write C++ code here
    std::future<void>p = std::async(square,5);
    //std::thread t2(cube,5);
    p.wait();
    // t1.join();
    // t2.join();

    return 0;
}