#include <unordered_map>
#include <iostream>
#include "Employee.h"
#include <memory>
using StackObjects = std::unordered_map<std::string, Employee>;
using RawPointersObjects = std::unordered_map<std::string, Employee *>;
using EmpSptr = std::shared_ptr<Employee>;
using SmartPointers = std::unordered_map<std::string, EmpSptr>;

void CreateObjects(StackObjects &data)
{
  /*
    step 1 : choose key and value
    step 2 : Make a pair of key and value
    step 3 :
  */

  data.emplace(
      std::make_pair<std::string, Employee>(
          "emp101",
          Employee(
              "emp101", "Ayush", 12434.56f, 23, "Pune")));

  data.emplace(
      std::make_pair<std::string, Employee>(
          "emp102",
          Employee(
              "emp102", "Bob", 124434.56f, 33, "Pune")));
  // for template functions templates argument can be deduced since cpp 14 , template functions for template classes can be deduce since cpp 20
  // pair only supports move semantics
  data.emplace(
      std::make_pair<>(
          "emp103",
          Employee(
              "emp103", "Bobby", 1244434.56f, 43, "Mumbai")));
}

// void CreateObjects(RawPointersObjects &data)
// {
//   data.emplace(
//       std::make_pair<std::string, Employee *>(
//           "emp101",
//           new Employee(
//               "emp101", "Ayush", 12434.56f, 23, "Pune")));

//   data.emplace(
//       std::make_pair<std::string, Employee *>(
//           "emp102",
//           new Employee(
//               "emp102", "Bob", 124434.56f, 33, "Pune")));
// }

template <typename T>
void Display(T& data){
    for(auto& [k,v] : data){
        std::cout<<"Key : "<< k <<"Value : "<< v <<"\n";
    }
}
/*
  Sequential containers
  Containers Adaptors
  Associative container
  UNordered Associative container
*/

int main()
{
  StackObjects data;
  CreateObjects(data);
  Display<StackObjects>(data);
}

/*
  do i want fixed size container 
  --- yes  [array]
  --- no -------------------Do u want to store data continuously
                               -------  yes  [Vector]
                               -------  No   ----------     Do u want traverse data sequentially
                                                            where n data is available only after n-1 th data
                                                            -------- [Yes] List
                                                            |
                                                            |
                                                            ------- Do u want to store data with key and value association
                                                                    |
                                                                    |
                                                                    ------>  No
                                                                            |
                                                                            |
                                                                            |
                                                                            ---------> Do you want to access data to a LIFO or FIFO 
                                                                                       ------ yes  [stack or queue]
                                                                                            |
                                                                                            |
                                                                                            |
                                                                                            do u want to store data with key and value association
                                                                                            |
                                                                                            |
                                                                                            --------> No
                                                                                                    |
                                                                                                    |
                                                                                                    do u wwant to
     
*/