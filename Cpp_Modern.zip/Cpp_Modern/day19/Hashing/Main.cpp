// #include <iostream>
// #include <unordered_map>
// #include "Employee.h"
// #include <memory>

// using StackObjects = std::unordered_map<std::string, Employee>;

// void CreateObjects(StackObjects &data)
// {
//     data.emplace("emp101", Employee("emp101", "Ayush", 12434.56f, 23, "Pune"));
//     data.emplace("emp102", Employee("emp102", "Bob", 124434.56f, 33, "Pune"));
//     data.emplace("emp103", Employee("emp103", "Bobby", 1244434.56f, 43, "Mumbai"));
// }

// void Display(const StackObjects& data)
// {
//     for(const auto& [key, value] : data)
//     {
//         std::cout << "Key: " << key << " Value: " << value << "\n";
//     }
// }

// int main()
// {
//     StackObjects data;
//     CreateObjects(data);
//     Display(data);

//     return 0;
// }