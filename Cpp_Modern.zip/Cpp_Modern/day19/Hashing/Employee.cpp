#include "Employee.h"

Employee::Employee(std::string _id, std::string _employee_name, float _salary, unsigned int _age, std::string _locatiob)
    : m_id{_id},m_employee_name{_employee_name},m_salary{_salary},m_age{_age},m_locatiob{_locatiob}
{
}
std::ostream &operator<<(std::ostream &os, const Employee &rhs) {
    os << "m_id: " << rhs.m_id
       << " m_employee_name: " << rhs.m_employee_name
       << " m_salary: " << rhs.m_salary
       << " m_age: " << rhs.m_age
       << " m_locatiob: " << rhs.m_locatiob;
    return os;
}
