#include <iostream>
#include "TouristVehicleType.h"
#include <thread>
#include "Functionalities.h"
#include <future>
#include "IdNotFoundException.h"

int main(){
    

    Container data;
    CreateObjects(data);
    try
    {
            unsigned int Ninstances = 1;
    std::future<ListContainer> result = std::async(&FirstNMatchingInstance,std::ref(data),std::ref(Ninstances));

    ListContainer resultList = result.get();

    for(TouristVehiclePtr ptr: resultList){
        std::cout<<*ptr<<std::endl;
    }

    std::promise<TouristVehicleType> pr ;
    std::future<TouristVehicleType> ft = pr.get_future();
    std::future<float> avereageBooking =std::async(&AverageBookingChargeForGivenType,std::ref(data),std::ref(ft));

    unsigned int n;
    std::cout<<"Enter 0 for CAB, 1 for BUS, 2 for BIKE"<<std::endl;
    TouristVehicleType t1 {TouristVehicleType::BUS};
    std::cin>>n;
    switch(n){
    case 0:
        t1 = TouristVehicleType::CAB;
        break;
    case 1:
        t1 = TouristVehicleType::BUS;
        break;
    case 2:
        t1 = TouristVehicleType::BIKE;
        break;
    default:
        t1 = TouristVehicleType::BUS;
    }

    pr.set_value(t1);
    float avereageBooking1 = avereageBooking.get();
    std::cout<<"Average Booking Charges for given type is "<<avereageBooking1<<std::endl;

    std::future<std::string> VehicleId = std::async(&FindMaxChargeId,std::ref(data));

    std::string VehicleID = VehicleId.get();

    std::cout<<"Vehicle Id who has mMax Charges "<<VehicleID<<std::endl;
    }
    // catch( std::future_error& e)
    // {
    //     if(e.code()==std::future_errc::no_state){
    //         std::cerr << "Invalid future result value"<<std::endl;
    //     }
    //     else if(e.code()==std::future_errc::future_already_retrieved){
    //         std::cerr << " Let handle this differently"<<std::endl;
    //     }
    // }
    catch(IdNotFoundException &ex){
        std::cout<< ex.msg()<<"\n";
    }
    



}

//