#include "Functionalities.h"
#include "IdNotFoundException.h"
void CreateObjects(Container &data)
{
    data.emplace(
        std::make_pair<std::string,TouristVehiclePtr>(
            "t01",
            std::make_shared<TouristVehicle>(
                 "t01",
                 TouristVehicleType::BIKE,
                 112,
                 123.67f,
                 std::make_shared<Permit>(
                    "Mh123",
                    PermitType::LEASE,
                    1232
                 )
            )
        )
    );

    data.emplace(
        std::make_pair<std::string,TouristVehiclePtr>(
            "t02",
            std::make_shared<TouristVehicle>(
                 "t02",
                 TouristVehicleType::CAB,
                 112,
                 123.67f,
                 std::make_shared<Permit>(
                    "Mh123",
                    PermitType::LEASE,
                    1232
                 )
            )
        )
    );

    data.emplace(
        std::make_pair<std::string,TouristVehiclePtr>(
            "t03",
            std::make_shared<TouristVehicle>(
                 "t03",
                 TouristVehicleType::BUS,
                 112,
                 123.67f,
                 std::make_shared<Permit>(
                    "Mh123",
                    PermitType::OWNED,
                    1232
                 )
            )
        )
    );
}

//Return N instances
ListContainer FirstNMatchingInstance(const Container &data,const unsigned int& N)
{
    if(data.empty()){
        throw std::runtime_error("");
    }

    if(N<0 || N> data.size()){
        throw std::runtime_error("N is invalid");
    }

    ListContainer result;
    std::size_t count {0};
    for(auto& [k,v] : data){
         if(v && v->permit()->permitType()==PermitType::LEASE  && 
            v->seatCount()>=4){
                result.push_back(v);
                count++;
                if(count==N){
                    break;
                }
            }
    }

    if(result.empty()){
        throw std::runtime_error("None of the objects satisfy the condition");
    }

    if(result.size() < N){
        throw std::runtime_error("I didn't find N instances may be less than that");
    }

    return result;
}

float AverageBookingChargeForGivenType(const Container &data, std::future<TouristVehicleType>& type)
{
    if(data.empty()){
        throw std::runtime_error("Average cannot be calculated");
    }

    float total {0.0f};
    unsigned int count = 0;
    TouristVehicleType touristType = type.get();
    for(const std::pair<std::string, TouristVehiclePtr>& p : data){
        if(p.second && p.second->type()==touristType){
            total += p.second->perHourBookingCharge();
            count++;
        }
    }

    if(count == 0){
        throw IdNotFoundException("sorry, no instance of give type exists!",std::future_errc::no_state);
    }

    return total/static_cast<int>(count);
}

std::string FindMaxChargeId(const Container &data)
{
    if(data.empty()){
        throw std::runtime_error("Average cannot be calculated");
    }

    std::string id = data.begin()->second->permit()->serialNumber();
    float max = data.begin()->second->perHourBookingCharge(); //initialize with first item as theoretical max

    // for(const std::pair<std::string,TouristVehiclePtr> & ptr: data){
    //     if(ptr.second && ptr.second->perHourBookingCharge()>max){
    //         max=ptr.second->perHourBookingCharge();
    //         id = ptr.second->permit()->serialNumber();
    //     }
    // }

    for(auto& [k,v] : data){
        if(v && v->perHourBookingCharge()>max){
            max = v->perHourBookingCharge();
            id = v->perHourBookingCharge();
            id = v->permit()->serialNumber();
        }
    }

    return id;
}

/*
  s1 : [     ]

  s2 : [0x00H  |  0x00H  |  0x00H    ]
*/
// void DeleteObjects(Container &data)
// {
//     if(data.empty()){
//         throw std::runtime_error("Nothing in the container");
//     }

//     for(TouristVehicle* ptr : data){
//         if (ptr){
//             if(ptr->permit()){
//               delete ptr->permit();
//             }
//         delete ptr;
//         }
        
//     }
// }


/*
   strategic in releasing resource
      - memory
      - file descriptor
      - network conflict
      - etc

    smart pointers can help with this
*/