#ifndef IDNOTFOUNDEXCEPTION_H
#define IDNOTFOUNDEXCEPTION_H
/*
  u need to create custom exception -> base/parent class has future error
  if future variable does not contain the data u expected -->  no state
  we r trying to take future input ,someone promised but we did'nt get that --> broken promise
  pr.setvalue --> repeated -> future already retrieved

*/
#include <future>
#include <cstring>
class IdNotFoundException: public std::future_error
{
private:
    /* data */
    char *_msg;
public:
    IdNotFoundException(/* args */) = delete;
    IdNotFoundException(const IdNotFoundException&) = delete;
    IdNotFoundException(IdNotFoundException&&) = default;
    IdNotFoundException& operator=(const IdNotFoundException&)= delete;
    IdNotFoundException& operator=(IdNotFoundException&&)=delete;
    ~IdNotFoundException() = default;
    IdNotFoundException(const char* msg, std::future_errc ec)
       :  std::future_error(ec) {
             _msg = new char[strlen(msg) + 1];
             strcpy(_msg,msg);
       }

    char *msg() const { return _msg; }
};

#endif // IDNOTFOUNDEXCEPTION_H

/*
   future error  ------------ no state
                              alread 
                              broken
                              future
*/