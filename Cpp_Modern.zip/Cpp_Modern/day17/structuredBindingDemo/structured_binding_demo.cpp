#include <iostream>
#include <array>

int main(){
    std::array<int,2> data{101,17};
    /*
     copy data[0] in employee_id
     copy data[1] in team_size 
    */

   auto [employee_id, team_size] = data;
   std::pair<int,std::string> info {101, "Ayush"};
   auto& [id_ref,name_ref] = info;
}