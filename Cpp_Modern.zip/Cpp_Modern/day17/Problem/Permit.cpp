#include "Permit.h"
std::ostream &operator<<(std::ostream &os, const Permit &rhs) {
    os << "m_permit_number: " << rhs._m_permit_number
       << " m_permit_expiry_year: " << rhs._m_permit_expiry_year;
    return os;
}

Permit::Permit(std::string m_permit_number, unsigned int m_permit_expiry_year)
    : _m_permit_number{m_permit_number},_m_permit_expiry_year{m_permit_expiry_year}
{
    if(_m_permit_expiry_year<2024 || _m_permit_expiry_year> 2099){
        throw;
    }
}