

#ifndef PRIVATEVEHICLE_H
#define PRIVATEVEHICLE_H

#include <iostream>
#include "VehicleEngineType.h"

class PrivateVehicle
{
private:
    std::string _m_registered_number;
    float _m_vehicle_price;
    VehicleEngineType _m_vehicle_engine_type;

public:
    PrivateVehicle(/* args */) = delete;
    PrivateVehicle(const PrivateVehicle &) = default;
    PrivateVehicle(PrivateVehicle &&) = default;
    PrivateVehicle &operator=(const PrivateVehicle &) = delete;
    PrivateVehicle &operator=(PrivateVehicle &&) = delete;
    ~PrivateVehicle() = default;

    PrivateVehicle(std::string m_registered_number,
                   float m_vehicle_price,
                   VehicleEngineType m_vehicle_engine_type);

    float GstCostForVehicle();

    std::string mRegisteredNumber() const { return _m_registered_number; }

    float mVehiclePrice() const { return _m_vehicle_price; }

    VehicleEngineType mVehicleEngineType() const { return _m_vehicle_engine_type; }

    friend std::ostream &operator<<(std::ostream &os, const PrivateVehicle &rhs);
};

#endif // PRIVATEVEHICLE_H
