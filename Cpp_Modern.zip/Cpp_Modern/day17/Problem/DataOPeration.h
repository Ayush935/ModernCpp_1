#ifndef DATAOPERATION_H
#define DATAOPERATION_H

#include <list>
#include "TouristVehicle.h"
#include "PrivateVehicle.h"
#include <variant>
#include <memory>
#include <optional>
using TouristPtr = std::shared_ptr<TouristVehicle>;
using PrivatePtr = std::shared_ptr<PrivateVehicle>;
using DataContainer = std::list<std::variant<TouristPtr,PrivatePtr>>;
using PermitContainer = std::list<Permit>;

class DataOPeration
{
private:
    /* data */
    DataContainer _m_data_container;
    PermitContainer _m_permit_Data;
    DataOPeration(/* args */) = default;
    DataOPeration(const DataOPeration &) = delete;
    DataOPeration(DataOPeration &&) = default;
    DataOPeration &operator=(const DataOPeration &) = delete;
    DataOPeration &operator=(DataOPeration &&) = delete;
    static DataOPeration* _only_object;
public:
    static DataOPeration* MakeObjectDataOperation();
    static void DeleteObject();
    void CreateObjectTouristVehiclePrivateVehicle();
    float AverageTouristVehiclePrice();
    bool IsVehicleAllPriceAbove5Lac();
    std::optional<std::list<std::shared_ptr<PrivateVehicle>>> PrivateVehicleList1();
    // std::list<PrivatePtr> PrivateVehicleList();
    ~DataOPeration() = default;
};

#endif // DATAOPERATION_H
