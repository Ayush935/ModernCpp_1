#include "DataOPeration.h"

DataOPeration*DataOPeration::_only_object{nullptr};



DataOPeration *DataOPeration::MakeObjectDataOperation()
{
    if(_only_object){
        return _only_object;
    }
    else{
        _only_object = new DataOPeration();
        return _only_object;
    }
}

void DataOPeration::DeleteObject()
{
    delete _only_object;
}

void DataOPeration::CreateObjectTouristVehiclePrivateVehicle()
{
    _m_permit_Data.emplace_back(Permit("SD123",2029));
    _m_permit_Data.emplace_back(Permit("SD124",2079));
    _m_permit_Data.emplace_back(Permit("SD125",2049));
    auto itr = _m_permit_Data.begin();
    if(itr!=_m_permit_Data.end())
    _m_data_container.emplace_back(std::make_shared<TouristVehicle>("MH123",123.34f,TouristVehicleType::BUS,*itr++));
    if(itr!=_m_permit_Data.end())
    _m_data_container.emplace_back(std::make_shared<TouristVehicle>("MH124",143.34f,TouristVehicleType::CAR,*itr++));
    if(itr!=_m_permit_Data.end())
    _m_data_container.emplace_back(std::make_shared<TouristVehicle>("MH125",423.34f,TouristVehicleType::OTHER,*itr++));

    _m_data_container.emplace_back(std::make_shared<PrivateVehicle>("MH126",322.34,VehicleEngineType::DIESEL));
    _m_data_container.emplace_back(std::make_shared<PrivateVehicle>("MH127",352.34,VehicleEngineType::HYBRID));
   // data.emplace_back(std::make_shared<PrivateVehicle>("MH128",362.34,VehicleEngineType::DIESEL));

}

float DataOPeration::AverageTouristVehiclePrice()
{
    if(_m_data_container.empty()){
        throw;
    }

    float sum = 0.0f;
    std::size_t counter{0};
    for(std::variant<TouristPtr,PrivatePtr>& ptr: _m_data_container){
        if(std::holds_alternative<TouristPtr>(ptr)){
             sum+= std::get<0>(ptr)->mVehiclePrice();
             counter++;
        }
        
    }
    
    return sum/static_cast<float>(counter);

}

bool DataOPeration::IsVehicleAllPriceAbove5Lac()
{
    if(_m_data_container.empty()){
        throw;
    }

    bool flag{true};
    float current_vehicle_price {0.0f};

    for(std::variant<TouristPtr,PrivatePtr>& ptr: _m_data_container){
        std::visit(
            [&](auto&& val) {current_vehicle_price = val->mVehiclePrice();},ptr
        );

        if(current_vehicle_price<500000.0f){
        return false;
    }

    }

    
    return true;
}

std::optional<std::list<std::shared_ptr<PrivateVehicle>>> DataOPeration::PrivateVehicleList1() 
{
    if(_m_data_container.empty()){
        throw;
    }
    
    std::list<PrivatePtr> result;
    for(const auto &ptr : _m_data_container){
        if(std::holds_alternative<PrivatePtr>(ptr)){
            PrivatePtr pV = std::get<1>(ptr);
            result.emplace_back(pV);
        }
        // if(auto res = std::get_if<std::shared_ptr<PrivateVehicle>>(&ptr)){
        //     result.push_back(*res);
        // }
    }
    
    if(result.empty()){
        return std::nullopt;
    }
    return result;
}

// std::list<PrivatePtr> DataOPeration::PrivateVehicleList(DataContainer &data)
// {
//     return std::list<PrivatePtr>();
// }
