#include "PrivateVehicle.h"
std::ostream &operator<<(std::ostream &os, const PrivateVehicle &rhs) {
    std::string val = "";
    if(rhs._m_vehicle_engine_type == VehicleEngineType::DIESEL){
        val = "DIESEL";
    }
    else if(rhs._m_vehicle_engine_type == VehicleEngineType::HYBRID){
        val = "HYBRID";
    }
    if(rhs._m_vehicle_engine_type == VehicleEngineType::PETROL){
        val = "PETROL";
    }
    os << "_m_registered_number: " << rhs._m_registered_number
       << " _m_vehicle_price: " << rhs._m_vehicle_price
       << " _m_vehicle_engine_type: " << val;
    return os;
}

PrivateVehicle::PrivateVehicle(std::string m_registered_number, float m_vehicle_price, VehicleEngineType m_vehicle_engine_type)
    : _m_registered_number{m_registered_number},_m_vehicle_price{m_vehicle_price},_m_vehicle_engine_type{m_vehicle_engine_type}
{
}

float PrivateVehicle::GstCostForVehicle()
{
    return 0.05*_m_vehicle_price;
}
