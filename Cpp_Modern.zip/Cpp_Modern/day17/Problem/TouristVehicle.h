/*
  create a class TouristVehicle with the following attributes
    - _register_number of type string
    - _vehicle_price of type float
    - _vehicle_type which is either CAB, BUS, or OTHER
    - _permit which a refrence wrapper to an instance of type _permit
    - A member function that can calculate permit renewal cost based on the following criteria
        - for CAB and BUS type of vehicle, cost is 15% of _vehicle_price
        - for OTHER type of vehicles, cost is 10% of _vehicle_price
    -operator << to display the parameter
    -getters and setters for relavant data members
*/

#ifndef TOURISTVEHICLE_H
#define TOURISTVEHICLE_H

#include <iostream>
#include "TouristVehicleType.h"
#include "Permit.h"
#include "functional"
using PermitRef = std::reference_wrapper<Permit>;

class TouristVehicle
{
private:
    std::string _m_register_number;
    float _m_tourist_vehicle_price;
    TouristVehicleType _m_tourist_vehicle_type;
    PermitRef _m_permit_ref;

public:
    TouristVehicle(/* args */) = delete;
    TouristVehicle(const TouristVehicle &) = default;
    TouristVehicle(TouristVehicle &&) = default;
    TouristVehicle &operator=(const TouristVehicle &) = delete;
    TouristVehicle &operator=(TouristVehicle &&) = delete;
    ~TouristVehicle() = default;

    TouristVehicle(std::string m_register_number,
                   float m_tourist_vehicle_price,
                   TouristVehicleType m_tourist_vehicle_type,
                   PermitRef m_permit_ref);

    std::string mRegisterNumber() const { return _m_register_number; }

    float mVehiclePrice() const { return _m_tourist_vehicle_price; }

    TouristVehicleType mTouristVehicleType() const { return _m_tourist_vehicle_type; }

    PermitRef mPermitRef() const { return _m_permit_ref; }

    float CalculatePermitRenewableCost();

    friend std::ostream &operator<<(std::ostream &os, const TouristVehicle &rhs);
};

#endif // TOURISTVEHICLE_H
