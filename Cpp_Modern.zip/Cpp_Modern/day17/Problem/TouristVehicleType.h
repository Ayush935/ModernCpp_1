#ifndef TOURISTVEHICLETYPE_H
#define TOURISTVEHICLETYPE_H

enum class TouristVehicleType
{
    CAR,
    BUS,
    OTHER
};

#endif // TOURISTVEHICLETYPE_H
