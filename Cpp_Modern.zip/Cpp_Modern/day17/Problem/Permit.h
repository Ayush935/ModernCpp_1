#ifndef PERMIT_H
#define PERMIT_H

#include <iostream>

class Permit
{
private:
    std::string _m_permit_number;
    unsigned int _m_permit_expiry_year;

public:
    Permit(/* args */) = default;
    Permit(const Permit &) = delete;
    Permit(Permit &&) = default;
    Permit &operator=(const Permit &) = delete;
    Permit &operator=(Permit &&) = delete;
    ~Permit() = default;

    Permit(std::string m_permit_number,
           unsigned int m_permit_expiry_year);
    std::string permitNumber() const { return _m_permit_number; }

    unsigned int permitExpiryYear() const { return _m_permit_expiry_year; }

    friend std::ostream &operator<<(std::ostream &os, const Permit &rhs);
};

#endif // PERMIT_H
