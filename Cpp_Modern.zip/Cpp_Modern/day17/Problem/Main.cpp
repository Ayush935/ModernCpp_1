#include "DataOPeration.h"
#include <future>

int main(){
    DataOPeration *p = DataOPeration::MakeObjectDataOperation();

    p->CreateObjectTouristVehiclePrivateVehicle();

    std::future<std::optional<std::list<PrivatePtr>> > result = std::async(&DataOPeration::PrivateVehicleList1,p);
    // std::future<std::list<std::shared_ptr<PrivateVehicle>>> result = std::async(&DataOPeration::PrivateVehicleList1,p);
    std::optional<std::list<PrivatePtr>> PrivateResult = result.get();
    
    if(PrivateResult.has_value()){
         std::list<PrivatePtr> ResultPrivateVehicle = PrivateResult.value();
         for(PrivatePtr ptr: ResultPrivateVehicle){
             std::cout<<*ptr<<"\n";
         }
    }


    
    



}