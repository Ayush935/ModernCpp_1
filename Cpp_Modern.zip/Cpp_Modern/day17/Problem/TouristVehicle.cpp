#include "TouristVehicle.h"
std::ostream &operator<<(std::ostream &os, const TouristVehicle &rhs) {
    std::string val = "";
    if(rhs._m_tourist_vehicle_type == TouristVehicleType::BUS){
        val = "BUS";
    }
    else if(rhs._m_tourist_vehicle_type == TouristVehicleType::CAR){
        val = "CAR";
    }
    else if(rhs._m_tourist_vehicle_type == TouristVehicleType::OTHER){
        val = "OTHER";
    }
    os << "_m_register_number: " << rhs._m_register_number
       << " _m_tourist_vehicle_price: " << rhs._m_tourist_vehicle_price
       << " _m_tourist_vehicle_type: " << val
       << " _m_permit_ref: " << rhs._m_permit_ref;
    return os;
}

TouristVehicle::TouristVehicle(std::string m_register_number, float m_tourist_vehicle_price, TouristVehicleType m_tourist_vehicle_type, PermitRef m_permit_ref)
    : _m_register_number{m_register_number},_m_tourist_vehicle_price{m_tourist_vehicle_price},_m_tourist_vehicle_type{m_tourist_vehicle_type},_m_permit_ref{m_permit_ref}
{
}

float TouristVehicle::CalculatePermitRenewableCost()
{
    if(_m_tourist_vehicle_type == TouristVehicleType::BUS || _m_tourist_vehicle_type==TouristVehicleType::CAR){
            return 0.15*_m_tourist_vehicle_price;
    }

    return 0.1*_m_tourist_vehicle_price;
}
