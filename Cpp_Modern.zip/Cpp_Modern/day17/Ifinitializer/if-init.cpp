#include <iostream>
#include <array>

std::array<int, 5> MakeValue(){
     return std::array<int,5>{1,2,3,4,5};
}

bool IsEven(int num){
    return num%2==0;
}


int main(){
    //bool ans = IsEven(13);

    if(bool ans = IsEven(13);ans){
        std::cout<<"hello\n";
    }
    else{
        std::cout<<"Number is not even";
    }

    if(std::array<int,5> result = MakeValue(); result[0]>-1){
        std::cout<<result.back();
    }
    else{
        std::cout<<"array has negative value" <<result.front()<<"\n";
    }
    for(int i=0;i<10;i++){
        std::cout<<i*i<<"\t";
    }

}


