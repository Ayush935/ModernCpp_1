#include "Factorial.h"
#include <iostream>

Factorial* Factorial:: _instance{nullptr};

Factorial *Factorial::GetInstance()
{ 
    if(_instance){
        return nullptr;
    }
    else{
        _instance = new Factorial();
        return _instance;
    }
    
}

void Factorial::factorial(std::future<int> &ft)
{
    int *answer = (int *)malloc(4); // statement can executr even before input!

    /////////
    /*
      since pre-requisite task is done, malloc is finished, now I really
      need the input without which i can't proceed!
    */

    int final_result(1);
    int n = ft.get(); // WAIT TILL INPUT ARRIVES

    for (int i = 2; i <= n; i++)
    {
        final_result *= i;
    }

    *answer = final_result; //

    std::cout << "Factorial calculation is done. Anwer is  " << *answer;
}

void Factorial::operator()()
{
       
    // std::promise<int> pr;

    _ft = _pr.get_future();

    std::future<void> result = std::async(&Factorial::factorial,this, std::ref(_ft));

    // factorial;
    // int value {0};
    // std::cin >> value;
    
    int value {0};
    std::cin>>value;
    //value has to be sent to number dummy variable
    _pr.set_value(value);
    //we can wait for factorial to finish (wait!)

    result.wait();
}
