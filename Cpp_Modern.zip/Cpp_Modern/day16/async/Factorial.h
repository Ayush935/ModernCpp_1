#ifndef FACTORIAL_H
#define FACTORIAL_H

#include <future>

class Factorial
{
private:
    int* _result{nullptr};
    std::future<int> _ft;
    std::promise<int> _pr;
    int value{-1};
    static Factorial* _instance;


    Factorial(/* args */) = default;
    Factorial(const Factorial&) = delete;
    Factorial(Factorial&&) = delete;
    Factorial& operator=(const Factorial&) = delete;
    Factorial& operator=(Factorial&&) = delete; 
    ~Factorial() = default;
    
public:
    static Factorial* GetInstance();
    void factorial(std::future<int>& _ft);
    void operator()();
};

#endif // FACTORIAL_H
