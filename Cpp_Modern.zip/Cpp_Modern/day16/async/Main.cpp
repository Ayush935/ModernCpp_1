#include "Factorial.h"

int main(){
   
   Factorial *p = Factorial::GetInstance();
   (*p)();
  
};