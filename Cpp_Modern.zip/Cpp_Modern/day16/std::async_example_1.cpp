#include <future>
#include <iostream>

/*
  Objective : Main thread will take an input from user.
  The input number's factorial will be calculated in the factorial function which performs
  the following actions

  a) Allocate memory for 
*/

void factorial(std::future<int>& number){
   int *answer = (int*)malloc(4);   //statement can executr even before input!

   /////////
   /*
     since pre-requisite task is done, malloc is finished, now I really 
     need the input without which i can't proceed!
   */


  int final_result (1);
  int n = number.get();  //WAIT TILL INPUT ARRIVES

  for(int i=2;i<=n;i++){
    final_result *=i;
  }

  *answer = final_result; //

  std::cout<< "Factorial calculation is done. Anwer is  "<<*answer;

}

/*
  ----------------------------------       [sending data/writing data]
[reading/ recieving data]
  ft                             pr
    ----------------------------

*/
//future and promise model
// 1 -> provide the promise to compiler to provide value int 
// 2-> u lanch thread asynchronoulsy by passing to future variable through reference
// 3-> while factorial pfunc performs malloc allocation main threads accpets user input and sets that into promise input 


int main(){

    // step 1 : i want to make a promise to provide an integer
     
    std::promise<int> pr;

    std::future<int> ft = pr.get_future();

    std::future<void> result = std::async(&factorial,std::ref(ft));

    factorial;
    // int value {0};
    // std::cin >> value;
    
    int value {0};
    std::cin>>value;
    //value has to be sent to number dummy variable
    pr.set_value(value);
    //we can wait for factorial to finish (wait!)

    result.wait();
}

/*
  Main ----------------------> factorial
   pr                             ft
*/