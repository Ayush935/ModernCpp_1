#ifndef EMPLOYEE_H
#define EMPLOYEE_H

#include <iostream>
#include <functional>
#include "Project.h"

class Employee
{
private:
    std::string _name;
    int _id;
    float _salary;
    std::reference_wrapper<Project>_ref;
public:
    Employee() = default;
    Employee(const Employee&) = delete;
    Employee operator=(const Employee&) = delete;
    Employee(Employee &&) = default;
    Employee operator=(Employee &&) = delete;
    ~Employee() = default;

    Employee(std::string name,int id,float salary,std::reference_wrapper<Project>ref);

    std::string name() const { return _name; }
    void setName(const std::string &name) { _name = name; }

    int id() const { return _id; }

    float salary() const { return _salary; }
    void setSalary(float salary) { _salary = salary; }

    std::reference_wrapper<Project>ref() const { return _ref; }
    void setRef(const std::reference_wrapper<Project>&ref) { _ref = ref; }

    friend std::ostream &operator<<(std::ostream &os, const Employee &rhs);
};

#endif // EMPLOYEE_H
