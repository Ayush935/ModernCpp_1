#include "Project.h"

std::ostream &operator<<(std::ostream &os, const Project &rhs) {
    os << "_project_name: " << rhs._project_name
       << " _budget: " << rhs._budget;
    return os;
}

Project::Project(std::string project_name, float budget)
    : _project_name{project_name}, _budget{budget}
{
}