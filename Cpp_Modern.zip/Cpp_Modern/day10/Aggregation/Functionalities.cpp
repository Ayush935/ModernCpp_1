#include "Functionalities.h"


void CreateObject(ProjectContainer &projects, EmployeeContainer &employees)
{
    projects.push_back( Project("HD System",1000203.34f));
    projects.push_back( Project("LS System",10023203.34f));
    projects.push_back( Project("HS System",10002103.34f));
    projects.push_back( Project("Px system",1000203.34f));

    employees.push_back(Employee("Ayush",1234,23934544.45f,projects[0]));
    employees.push_back(Employee("Bob",1264,22334544.45f,projects[1]));
    employees.push_back(Employee("Bobby",1434,23932544.45f,projects[2]));
    employees.push_back(Employee("John",1234,234334544.45f,projects[3]));
}

void PrintObjectEmployee(EmployeeContainer &employees)
{
    if(employees.empty()){
        throw std::runtime_error("employee data is empty");
    }

    for(Employee &ptr: employees ){
        std::cout<<ptr<<std::endl;
    }
}
