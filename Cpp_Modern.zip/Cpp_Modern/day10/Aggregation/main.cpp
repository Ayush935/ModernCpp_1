#include "Functionalities.h"

int main(){
    ProjectContainer projects;
    EmployeeContainer employees;
    CreateObject(projects,employees);
    
    try
    {
        PrintObjectEmployee(employees);
    }
    catch(const std::exception& e)
    {
        std::cerr << e.what() << '\n';
    }
    
    
}