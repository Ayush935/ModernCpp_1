#include "Employee.h"

std::ostream &operator<<(std::ostream &os, const Employee &rhs) {
    os << "_name: " << rhs._name
       << " _id: " << rhs._id
       << " _salary: " << rhs._salary
       << " _ref: " << rhs._ref.get();
    return os;
}

Employee::Employee(std::string name, int id, float salary, std::reference_wrapper<Project> ref)
    : _name{name}, _id{id}, _salary{salary},_ref{ref}
{
}