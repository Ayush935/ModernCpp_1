#include "Project.h"
#include "Employee.h"
#include <vector>

using ProjectContainer = std::vector<Project>;
using EmployeeContainer = std::vector<Employee>;

void CreateObject(ProjectContainer &projects,EmployeeContainer &employees );

void PrintObjectEmployee(EmployeeContainer &employees);

