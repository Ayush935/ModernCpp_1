#ifndef PROJECT_H
#define PROJECT_H

#include <iostream>

class Project
{
private:
    std::string _project_name;
    float _budget;
public:
    Project() = default;
    Project(const Project&) = delete;
    Project operator=(const Project&) = delete;
    Project(Project &&) = default;
    Project operator=(Project &&) = delete;
    ~Project() = default;

    Project(std::string project_name,float budget);

    std::string projectName() const { return _project_name; }
    void setProjectName(const std::string &project_name) { _project_name = project_name; }

    float budget() const { return _budget; }
    void setBudget(float budget) { _budget = budget; }

    friend std::ostream &operator<<(std::ostream &os, const Project &rhs);
};

#endif // PROJECT_H
