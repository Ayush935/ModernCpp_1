#include <functional>
#include <iostream>
using RefType = std::reference_wrapper<int>;

/*
  Recap
     refernce : an alias or an alternative TO SOMETHING THAT ALREADY EXISTS!
*/

int main(){
    //why people don't use regular refernce from CPP in modern CPP
    //similar to why people don't use pointers in modern cpp

    //problem 1 : refernce don't exist in memory PHYSICALLY, They have no memory footprint

    //int& arr[1];
    
    /*

    int n1=10;
    int& ref = n1; //lvalue refernce
    std::vector<int &>data{ref};

    Above thing is not possible
    */

    /*
    Reference wrapper is alternative for lvalue reference
    */

    int n1 = 10;
    RefType ref{n1};

    RefType arr[1] {ref};
    std::vector<RefType> data{ref};
    
}