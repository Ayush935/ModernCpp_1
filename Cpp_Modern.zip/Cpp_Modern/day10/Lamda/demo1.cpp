#include <iostream>
#include <functional>

class Magic
{
private:
    /* data */
public:
    // std::vector (stud vector)
    //  /etc : etsy
    //  operator function call [operator paren paren]
    int operator()(int number)
    {
        return number * number;
    }
};

int main()
{
    Magic m1;
    std::cout << m1(10);
    std::cout << Magic{}(10);
    
    /*
    Signature matches for functional wrapper
    lamda is not a function though, we exploited loophole 
    */

    std::function<int(int number)>fn = [](int number){return number * number;};    //loophole
    auto f1 = [](int number)
    { return number * number; };
    /*
      class Lamda#1e23423{
        private:

        public:
           int operator()(int number){
              return number*number;
            }
      }
    */
};

