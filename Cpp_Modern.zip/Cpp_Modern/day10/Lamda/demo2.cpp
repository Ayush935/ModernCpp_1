#include <iostream>
#include <functional>

/*
   void DataAdaptor(int n1, std::string &name, float salary, char &grade, std::function<void(std::string &, char &)> fn)
{
    // inside this function, logic should change name and grade
    fn(name, grade);
}
*/

void DataAdaptor(int n1, std::string &name, float salary, char &grade, std::function<void()> fn)
{
    // inside this function, logic should change name and grade
    fn();
}

int main()
{
    // declaration and initialization of a char type variable grade with
    // initial 'A
    char grade{'A'};

    // declaration and initialization of a char type variable grade with
    // initial "hero"
    std::string name{"hero"};

    // declaration and intialisation of a variable f1 whose type is to be deduced by compiler based on initial lamda literal
    // for a function that accepts 2 parameters - string rederence and grade reference with function returning void
    
    /*
      auto f1 = [](std::string &name, char &grade)
    {name = "super hero"; grade = 'O'; };
    */

    auto f1 = [&]()
    {name = "super hero"; grade = 'O'; };
    
    
    //invoke dataadaptor function by passing 
    //a) int by rvalue, name as lvalue reference to string, salary by rvalue of type float ,grade
    // as char reference and lamda object by value
    DataAdaptor(10, name, 10000.0f, grade, f1); // logic for modifying name and grade
    
    /*
     DataAdaptor(10, name, 10000.0f, grade, [](std::string &name, char &grade)
                {name = "super hero"; grade = 'O'  ; });
    */
    

    DataAdaptor(10, name, 10000.0f, grade, [&]()
                {name = "super hero"; grade = 'O'  ; });
}