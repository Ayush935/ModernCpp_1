#include <iostream>
#include <functional>

void outer(){
    int n1 = 10;
    int n2 = 20;

    //option 1:
    auto f1 = [](int n1, int n2){
        std::cout<<n1+n2<<"\n";
    };

    f1(n1,n2); //works

    //f2 captures all variables from the scope of its enclosing function 'outer
    //which means n1 and n2 are both accessible inside f2 (by reference)

    auto f2 = [&](){
        std::cout<<n1+n2<<"\n";
    };
    
    //option 3: capture enclosing variables by value, mutable keyword
    //allows data ro be modified inside n1 and n2 but change will not reflect outside of f3
    f2();  //works too!

    auto f3 = [=]()mutable{
        std::cout<<n1+n2<<"\n"; //capture by value
    };
    
    f3();

    //capture specific variables by their name using "Reference" sementics
    auto f4 = [&n1](){
        std::cout<<n1+n2<<"\n";  //n1 capture by reference, n2 is not accessible
    };
    f4();

    //n1 is captured by refernce and f1 is captured by value(f1 copied into f5)
    auto f5 = [&n1, f1](){
        f1(n1,10); //n1 captured by refernce and n2 is not accessible
    };
    f5();


}