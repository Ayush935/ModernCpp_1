#include <iostream>

class Demo
{
private:
    int _id;
    std::string _name;
public:
    explicit Demo(int id): _id {id} {}
    explicit Demo(int id, std::string name = "xyz"): _id {id}, _name {name} {}
    ~Demo() = default;
};

void Magic(Demo obj){

}

int main(){
   // Magic(10); //implicit type conversion from int to Demo
   // Magic(std::string {"fffff"});
   
}

