#ifndef INVALIDNVALUEEXCEPTION_H
#define INVALIDNVALUEEXCEPTION_H

#include <stdexcept>
#include <cstring>

class InvalidNValueException  : std::exception
{
private:
    char* _msg;
public:
    InvalidNValueException(const char* msg)  {
        //we made space on the heap for msg + 1 characters (\0)
        _msg = new char[strlen(msg)+1];
        strcpy(_msg,msg);
    }
    InvalidNValueException() {delete _msg; };
    InvalidNValueException(const InvalidNValueException&) = delete;
    InvalidNValueException& operator=(const InvalidNValueException&)=delete;
    InvalidNValueException& operator=(InvalidNValueException&&)=default;
    InvalidNValueException(InvalidNValueException &&)=delete;
    ~InvalidNValueException() = default;
    std::string what() {return _msg; }// getter for _msg!
};

#endif // INVALIDNVALUEEXCEPTION_H
