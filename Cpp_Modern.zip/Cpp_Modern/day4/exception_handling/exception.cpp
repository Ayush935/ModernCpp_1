/*
   Objective : A function that finds the first N values from the input container
*/

/*
   Scenario 1 : Input is valid, N is also valid (N< size and not negative)
  
   Fn(data, 3)
   Scenario 2 : Input is Invalid, N is Valid

   Fn(data, 3); data is empty
   Scenario 3 : dat input is valid, but N is either too large or less than or equal to 0
   fn(data,-1)

*/

/*
   process: 3 channels : 1 output, 2:err ,0 : input
*/
#include <vector>
#include <iostream>
#include "ContainerEmptyException.h"
#include "InvalidNValueException.h"

void Magic(const std::vector<int>& data, const int N){
    if(data.empty()){
        throw ContainerEmptyException("Data is not available");
    }
    else if(N <= 0 || N > data.size()){
        throw InvalidNValueException("N is invalid");
    }
}

int main(){
    std::vector<int>data {10,20,30,40};
    try{
        Magic(std::vector<int>{},3);
    }catch(ContainerEmptyException& ex){
        std::cerr << ex.what() << "\n";
    }catch(InvalidNValueException& ex){
        std::cerr << ex.what() << "\n";
    }
    
}

/*
  exception object goes to catch block 
  [ContainerEmptyException]
*/

/*
  CPP way of handling "bad thing happened" :

  std::logical error
  std::runtime_error
  std::bad_cast_error
  std::bad_alloc
*/

/*
   Exceptions : a situation which cannot be prevented, happens due to circumstances beyond a devloper's control
   but can be resolved based on "an action plan"

   Errors : Something happens due to devloper's fault, can be prevented through good programming, can always be
   avoided

   try{
    File f1 = new File("eshda");
    f1.open();
   }catch(FileNoFoundError)

   We call function.........
   function throws exception .......
   [make an obj], capture user's msg inside the obj;
   create a mechanism to extracr the msg deone!
*/



