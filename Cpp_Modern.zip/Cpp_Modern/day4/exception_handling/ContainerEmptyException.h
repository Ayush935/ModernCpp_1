#ifndef CONTAINEREMPTYEXCEPTION_H
#define CONTAINEREMPTYEXCEPTION_H

#include <stdexcept>

class ContainerEmptyException : std::exception
{
private:
    std::string _msg;

public:
    ContainerEmptyException(std::string msg) : _msg(msg) {}
    ContainerEmptyException() = default;                                          // disabled default constructor
    ContainerEmptyException(const ContainerEmptyException &) = delete;            // disabled copy constructor
    ContainerEmptyException &operator=(const ContainerEmptyException &) = delete; // disabled copy assignment
    ContainerEmptyException &operator=(ContainerEmptyException &&) = default;     // enabled move assignment
    ContainerEmptyException(ContainerEmptyException &&) = delete;                 // disabled move constructor
    ~ContainerEmptyException() = default;                                         // disabled default destructor
    std::string what() { return _msg; }                                           // getter for _msg!
};

#endif // CONTAINEREMPTYEXCEPTION_H


