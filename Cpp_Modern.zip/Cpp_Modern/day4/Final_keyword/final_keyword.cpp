/*
#include <iostream>

class Demo final
{
private:
    int _id;
    std::string _name;
public:
    explicit Demo(int id): _id {id} {}
    explicit Demo(int id, std::string name = "xyz"): _id {id}, _name {name} {}
    ~Demo() = default;
};

class Fancy_demo : public Demo{    //error because base class is final
    private:

    public:
    Fancy_demo();
    ~Fancy_demo();
};

void Magic(Demo obj){

}

int main(){
   // Magic(10); //implicit type conversion from int to Demo
   // Magic(std::string {"fffff"});
}

class can be locked by using final keyword similarly virtual function will be final can't be override
*/

#include <iostream>

class example
{
private:
    int id;
public:
    example(/* args */) {}
    ~example() {}
    virtual void exaple() final{}
};

class Demo : public example
{
private:
    int _id;
    std::string _name;
public:
    explicit Demo(int id): _id {id} {}
    explicit Demo(int id, std::string name = "xyz"): _id {id}, _name {name} {}
    ~Demo() = default;
    void exaple() override{}  // because of finalk
};

class Fancy_demo : public Demo{    //error because base class is final
    private:

    public:
    Fancy_demo();
    ~Fancy_demo();
    
    
};

void Magic(Demo obj){

}

int main(){
   // Magic(10); //implicit type conversion from int to Demo
   // Magic(std::string {"fffff"});
}


