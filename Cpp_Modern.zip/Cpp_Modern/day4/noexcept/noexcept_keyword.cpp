#include <iostream>

void Fn() noexcept {
    
    int n1 = 10;
    std::cout<< "output is : "<<n1;
}

int main(){}

