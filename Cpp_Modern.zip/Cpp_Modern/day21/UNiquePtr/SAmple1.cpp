#include <memory>

/*
  if a resource should only have one owner in you software at any point and no option of replicating/sharing ownership is expected
  use std::unique_ptr;
*/

void Magic(std::unique_ptr<int[]>& ptr){

}

int main(){
    /*
     a) allocate space for 2 integers on th heap new int[2]
     b) i want to make sure that he raw pointer returned from this allocation is not accessible from next statement
     onwards
     c) Since this is allocation for integer array, unique pointer
        needs to be aware about it, hence <int[]>
     d) Since we don't have to forward any parameters to any constructor, we can skip make unique
    */

    std::unique_ptr<int[]> ptr1(new int[2]);  //

    Magic(ptr1);
}