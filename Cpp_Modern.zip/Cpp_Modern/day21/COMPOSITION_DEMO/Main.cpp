#include <iostream>
#include "Functionalities.h"

int main(){
    // unsigned int n;
    // std::cout<<"Enter 0 for CAB, 1 for BUS, 2 for BIKE"<<std::endl;
    // TouristVehicleType t1 {TouristVehicleType::BUS};
    // std::cin>>n;
    // switch(n){
    // case 0:
    //     t1 = TouristVehicleType::CAB;
    //     break;
    // case 1:
    //     t1 = TouristVehicleType::BUS;
    //     break;
    // case 2:
    //     t1 = TouristVehicleType::BIKE;
    // default:
    //     t1 = TouristVehicleType::BUS;
    // }

    Container data;
    CreateObjects(data);
    float ans = AverageBookingChargeForGivenType(data,TouristVehicleType::BIKE);
    std::cout<<"Average "<<ans<<"\n";

    FindMaxPerHourBookingCharge(data);

    FindFirstNInstances(data,2);

    AreInstancesHaveSamePermitType(data);

    CountCabTypeInstances(data);

     LastNMaxSeatCount(data,2);
}