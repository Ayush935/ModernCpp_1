#ifndef MAPFUNCIONALITIES_H
#define MAPFUNCIONALITIES_H

#include "TouristVehicle.h"
#include "Permit.h"
#include <memory>
#include <algorithm>
#include <numeric>
#include <list>
#include <unordered_map>
#include <functional>

using TouristVehiclePtr = std::shared_ptr<TouristVehicle>;
using MapEntry = std::pair<std::string,TouristVehiclePtr>;
using DataContainer = std::unordered_map<std::string,TouristVehiclePtr>;

void CreateObjects( DataContainer &data);

/*
  Return N instances
*/
std::optional<std::list<TouristVehiclePtr>> FirstNMatchingInstance(const DataContainer& data,unsigned int N);

/*
  Average price for given type
*/
float AverageBookingChargeForGivenType(const DataContainer& data,const TouristVehicleType type);


//id of max charge instance
std::string FindMaxChargeId(const DataContainer& data);


float  FindMaxPerHourBookingCharge(const DataContainer &data);


//return first N instances
std::list<TouristVehiclePtr> FindFirstNInstances(const DataContainer& data,unsigned int N);


//check if all instances have the same permitType
bool AreInstancesHaveSamePermitType(const DataContainer&data);

// return count of instances whose m_vehicle 
std::size_t CountCabTypeInstances(const DataContainer&data);


//return Permit Pointer based on id value
std::optional<PermitPtr> FindPermitBasedOnIdValue(const DataContainer&data,std::string id);

//return maximum seatcount from last N instance TouristPointers
int LastNMaxSeatCount(const DataContainer& data,unsigned int N);


//Calcualte GST on per_hour_booking charge based on a unary operation passed by user for all instances and return a container of results
std::list<float> CalculateGSTValues(const DataContainer&data,std::function<float(const TouristVehiclePtr& ptr)>fn);


#endif // MAPFUNCIONALITIES_H
