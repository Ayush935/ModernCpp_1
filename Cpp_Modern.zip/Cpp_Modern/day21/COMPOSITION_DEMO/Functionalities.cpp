#include "Functionalities.h"

void CreateObjects(Container &data)
{
    data.emplace_back(std::make_shared<TouristVehicle>("123",TouristVehicleType::BIKE,12,120.0f,std::make_shared<Permit>("MH1",PermitType::LEASE,20)));
    data.emplace_back(std::make_shared<TouristVehicle>("124",TouristVehicleType::BUS,22,1120.0f,std::make_shared<Permit>("MH2",PermitType::OWNED,120)));
    data.emplace_back(std::make_shared<TouristVehicle>("125",TouristVehicleType::CAB,32,1220.0f,std::make_shared<Permit>("MH3",PermitType::LEASE,220)));
    data.emplace_back(std::make_shared<TouristVehicle>("126",TouristVehicleType::BIKE,12,1240.0f,std::make_shared<Permit>("MH4",PermitType::OWNED,230)));

}

std::optional<Container> FirstNMatchingInstance(const Container &data, unsigned int N)
{
    if(data.empty()){
        throw std::runtime_error("Data is empty");
    }

    if(N==0 || N>data.size()){
        throw std::runtime_error("N is invalid");
    }
    
    Container matchhing_instances;
    std::copy_if(
        data.begin(),
        data.end(),
        std::inserter(matchhing_instances,matchhing_instances.begin()),
        [](const TouristVehiclePtr& ptr){
            return ptr->seatCount()>=4 && ptr->permit()->permitType()==PermitType::LEASE;
        }
    );
    //matching_instance.resize(N);
    //return matching_instance;
    Container actual_result;

    std::copy_n(
       matchhing_instances.begin(),
       N,
       std::inserter(actual_result,actual_result.begin()) 
       );

       return actual_result;
}

float AverageBookingChargeForGivenType(const Container &data, const TouristVehicleType type)
{
    if(data.empty()){
        throw std::runtime_error("Data is empty");
    }

    float sum = std::accumulate(
        data.begin(),
        data.end(),
        0.0f,
        [](float answer_up_to_current_point,const TouristVehiclePtr& ptr){
            return answer_up_to_current_point + ptr->perHourBookingCharge();
        }
    );

    // float sum = std::accumulate(
    //     data.begin(),
    //     data.end(),
    //     0.0f,
    //     [](float value_upto_current_point,const TouristVehiclePtr& t){
    //         return value_upto_current_point+t->perHourBookingCharge(); 
    //     }
    // );
    
    return sum/data.size();
}

float  FindMaxPerHourBookingCharge(const Container &data)
{
    if(data.empty()){
        throw std::runtime_error("Data is empty");
    }

    auto result = std::max_element(
        data.begin(),
        data.end(),
        [](const TouristVehiclePtr& ptr1, const TouristVehiclePtr& ptr2){
            return ptr1->perHourBookingCharge()<ptr2->perHourBookingCharge();
        }
    );

    return (*result)->perHourBookingCharge();
}

/*
  a) matching condition instances have to be copied
  b) if N or more were instances were copied, we can now return first N instances from this copied collection to the user
  
  obj1 obj2 obj3 obj4 obj15

  2 instances matching condition

  obj1 obj4 obj5 satisfy condition

  return obj1 & obj4
  Sy Brand
*/

Container FindFirstNInstances(const Container &data, unsigned int N)
{
    if(data.empty()){
        throw std::runtime_error("Data is empty");
    }
    
    if(N<=0 || N>data.size()){
        throw std::runtime_error("Invalid Value");
    }
    Container result;

    std::copy_n(
        data.begin(),
        N,
        std::inserter(result,result.begin())
    );
    

    return result;
}


bool AreInstancesHaveSamePermitType(const Container &data)
{
    if(data.empty()){
        throw std::runtime_error("Data is empty");
    }

    PermitType type = data.front()->permit()->permitType();
    
    return std::all_of(
        data.begin(),
        data.end(),
        [&](const TouristVehiclePtr& t){
           return t->permit()->permitType()== type;
        });
}


std::size_t CountCabTypeInstances(const Container &data)
{
    if(data.empty()){
        throw std::runtime_error("Data is empty");
    }

    return std::count_if(
        data.begin(),
        data.end(),
        [](const TouristVehiclePtr& t){
            return t->type()==TouristVehicleType::CAB;
        }
    );
}

std::optional<PermitPtr> FindPermitBasedOnIdValue(const Container &data, std::string id)
{
    if(data.empty()){
        throw std::runtime_error("Data is empty");
    }

    auto itr = std::find_if(
        data.begin(),
        data.end(),
        [&](const TouristVehiclePtr& t){
            return t->number()==id;
        }
    );

    if(itr!=data.end()){
        return std::nullopt;
    }

    return (*itr)->permit();
}

int LastNMaxSeatCount(const Container &data, unsigned int N)
{
    if(data.empty()){
        throw std::runtime_error("Data is empty");
    }

    auto itr = data.begin();

    std::advance(itr,data.size()-N);

    auto result = std::max_element(
        itr,
        data.end(),
        [](const TouristVehiclePtr& ptr1,const TouristVehiclePtr& ptr2){
            return ptr1->seatCount() < ptr2->seatCount();
        }
    );

    return (*result)->seatCount();
}

std::list<float> CalculateGSTValues(const Container &data, std::function<float(const TouristVehiclePtr &ptr)> fn)
{
     if(data.empty()){
        throw std::runtime_error("Data is empty");
    }
   
   std::list<float> result;

   std::transform(
    data.begin(),
    data.end(),
    std::inserter(result,result.begin()),
    fn
   );

   return result;
}
