#include "MapFuncionalities.h"

void CreateObjects( DataContainer &data){

}

/*
  Return N instances
*/
std::optional<std::list<TouristVehiclePtr>> FirstNMatchingInstance(const DataContainer& data,unsigned int N){
    if(data.empty()){
        throw std::runtime_error("Data is empty");
    }

    std::list<TouristVehiclePtr> result;

    /*
       for each pair in input data
       a) extract pair.second
       b) push_back pair.second into the result
    */

   auto fn = [](const MapEntry& p){
    return p.second;
   };

   std::for_each_n(
    data.begin(),
    N,
    [&](const MapEntry& p){
    return result.push_back(p.second);
   }
   );


   return result;
}

/*
  Average price for given type
*/
float AverageBookingChargeForGivenType(const DataContainer& data,const TouristVehicleType type){
    if(data.empty()){
        throw std::runtime_error("Data is empty");
    }

    float sum = std::accumulate(
        data.begin(),
        data.end(),
        0.0f,
        [&](float value_upto_current_point,MapEntry&& val){
            return value_upto_current_point + val.second->perHourBookingCharge();
        }
    );

    return sum/data.size();
}



float  FindMaxPerHourBookingCharge(const DataContainer &data){
    if(data.empty()){
        throw std::runtime_error("Data is empty");
    }


}


//return first N instances
std::list<TouristVehiclePtr> FindFirstNInstances(const DataContainer& data,unsigned int N){
    if(data.empty()){
        throw std::runtime_error("Data Container is empty");
    }

    std::list<TouristVehiclePtr> result;

    std::for_each(
        data.begin(),
        data.end(),
        [&](const MapEntry& p){
            if(p.second->seatCount()>=4 && p.second->permit()->permitType()==PermitType::LEASE){
                result.push_back(p.second);
            }
        }
    );

    return result;
}


//check if all instances have the same permitType
bool AreInstancesHaveSamePermitType(const DataContainer&data);

// return count of instances whose m_vehicle 
std::size_t CountCabTypeInstances(const DataContainer&data){
    if(data.empty()){
        throw std::runtime_error("Data is empty");
    }

    return std::count_if(
        data.begin(),
        data.end(),
        [](MapEntry &&p){
            return p.second->type()==TouristVehicleType::CAB;
        }
    );
}


//return Permit Pointer based on id value
std::optional<PermitPtr> FindPermitBasedOnIdValue(const DataContainer&data,std::string id){
    if(data.empty()){
        throw std::runtime_error("Data is empty");
    }

    auto itr = std::find_if(
        data.begin(),
        data.end(),
        [&]( MapEntry&& p){           //MapEntry&&
             return p.second->number()==id;
        }
    );

    if(itr!=data.end()){
        return std::nullopt;
    }

    return (*itr).second->permit();
}

//return maximum seatcount from last N instance TouristPointers
int LastNMaxSeatCount(const DataContainer& data,unsigned int N){
    if(data.empty()){
        throw std::runtime_error("Data is empty");
    }
    

}


//Calcualte GST on per_hour_booking charge based on a unary operation passed by user for all instances and return a container of results
std::list<float> CalculateGSTValues(const DataContainer&data,std::function<float(const TouristVehiclePtr& ptr)>fn);


/*
   HASHTABLE ENTRIES ARE STD::PAIR<K<V>>

   i.e std::pair cannot be 
  
*/