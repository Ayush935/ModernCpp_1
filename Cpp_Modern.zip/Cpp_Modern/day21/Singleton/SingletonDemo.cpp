#include <iostream>
#include <memory>

class OPeration;
using pointer = std::unique_ptr<OPeration>;

class OPeration

{
private:
    /* data */
    static pointer m_instance;
public:
    OPeration(/* args */) {}
    ~OPeration() {}

    static pointer& GetInstance(){
        if(m_instance){
            return m_instance;
        }
        else{
            m_instance.reset(new OPeration());
            return m_instance;
        }
    };
};

int main(){
    pointer &ptr =  OPeration::GetInstance();
}