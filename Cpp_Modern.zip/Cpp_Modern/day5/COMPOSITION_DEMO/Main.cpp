#include <iostream>
#include "TouristVehicleType.h"

int main(){
    unsigned int n;
    std::cout<<"Enter 0 for CAB, 1 for BUS, 2 for BIKE"<<std::endl;
    TouristVehicleType t1 {TouristVehicleType::BUS};
    std::cin>>n;
    switch(n){
    case 0:
        t1 = TouristVehicleType::CAB;
        break;
    case 1:
        t1 = TouristVehicleType::BUS;
        break;
    case 2:
        t1 = TouristVehicleType::BIKE;
    default:
        t1 = TouristVehicleType::BUS;
    }
}