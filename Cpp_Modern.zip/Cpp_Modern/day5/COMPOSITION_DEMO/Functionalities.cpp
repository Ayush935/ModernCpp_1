#include "Functionalities.h"

void CreateObjects(Container &data)
{
    data.push_back(
        new TouristVehicle(
            "t101",
            TouristVehicleType::CAB, 
            4, 
            500.0f, 
            new Permit(
                "pr101", 
                PermitType::OWNED, 
                4
            )
        )
    );
    data.push_back(
        new TouristVehicle(
            "t102", 
            TouristVehicleType::CAB, 
            5, 
            1000.0f, 
            new Permit(
                "pr102", 
                PermitType::OWNED, 
                4
            )
        )
    );
}

//Return N instances
Container FirstNMatchingInstance(const Container &data,const unsigned int N)
{
    if(data.empty()){
        throw std::runtime_error("");
    }

    if(N<0 || N> data.size()){
        throw std::runtime_error("N is invalid");
    }

    Container result;

    for(TouristVehicle *ptr : data){
        if(ptr && ptr->seatCount() >= 4 && ptr->permit()->permitType() == PermitType::LEASE){
            result.push_back(ptr);
            if(result.size()==N){
                break;
            }
        }
    }

    if(result.empty()){
        throw std::runtime_error("None of the objects satisfy the condition");
    }

    if(result.size() < N){
        throw std::runtime_error("I didn't find N instances may be less than that");
    }

    return Container();
}

float AverageBookingChargeForGivenType(const Container &data, const TouristVehicleType type)
{
    if(data.empty()){
        throw std::runtime_error("Average cannot be calculated");
    }

    float total {0.0f};
    unsigned int count = 0;

    for(TouristVehicle* ptr : data){
        if(ptr && ptr->type()==type ){
            total += ptr->perHourBookingCharge();
            count++;
        }
    }

    if(count == 0){
        throw std::runtime_error("sorry, no instance of give type exists!");
    }

    return total/static_cast<int>(count);
}

std::string FindMaxChargeId(const Container &data)
{
    if(data.empty()){
        throw std::runtime_error("Average cannot be calculated");
    }

    std::string id = data[0]->permit()->serialNumber();
    float max = data[0]->perHourBookingCharge(); //initialize with first item as theoretical max

    for(TouristVehicle* ptr: data){
        if(ptr && ptr->perHourBookingCharge()>max){
            max=ptr->perHourBookingCharge();
            id = ptr->permit()->serialNumber();
        }
    }

    return id;
}

/*
  s1 : [     ]

  s2 : [0x00H  |  0x00H  |  0x00H    ]
*/
void DeleteObjects(Container &data)
{
    if(data.empty()){
        throw std::runtime_error("Nothing in the container");
    }

    for(TouristVehicle* ptr : data){
        if (ptr){
            if(ptr->permit()){
              delete ptr->permit();
            }
        delete ptr;
        }
        
    }
}


/*
   strategic in releasing resource
      - memory
      - file descriptor
      - network conflict
      - etc

    smart pointers can help with this
*/