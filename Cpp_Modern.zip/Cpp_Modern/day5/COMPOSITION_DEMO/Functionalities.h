#ifndef FUNCTIONALITIES_H
#define FUNCTIONALITIES_H

#include <vector>
#include "TouristVehicle.h"
using Container = std::vector<TouristVehicle *>; // use "Container" as an alternate name for std::vector of TouristVehicle pointers

/*
                                    ["p101"| LEASE| 10]
                                    ^ 
                                    |
                                    |
  ["mhttt16"| CAB | 4 | 500 | 0x100H]
*/

//create instance method
void CreateObjects( Container &data, const unsigned int N);
/*
  Return N instances
*/
Container FirstNMatchingInstance(const Container& data);
/*
  Average price for given type
*/
float AverageBookingChargeForGivenType(const Container& data,const TouristVehicleType type);

//id of max charge instance
std::string FindMaxChargeId(const Container& data);

//return first N instances
Container FindFirstInstances(const Container& data);

void DeleteObjects(Container &data);
#endif // FUNCTIONALITIES_H


/*
  [  ] 0x100h
  [  ] 0x101h
  [  ] 0x102h
  [  ] 0x103h
  [  ] 0x104h

  10 20 30 40 50

  std::vector<int> {10,20,30,40,50}
     - Take an initializer_list with {10,20,30,40,50}
       as a parameter to the constructor of vector
       
     - malloc(20bytes)
     - 5 numbers will be stored there
     - size - 5
     - capacity 5
    data.push(60)

  std::vector<int> data;
    data.push_back(10);
    data.push_back(20);    
    data.push_back(30);
    data.push_back(40);
    data.push_back(50);
 
        - size 0;
        - capacity = 0
        - malloc call ( 4 byte) {10}
            - size = 1
            - capacity = 1
        - for 20
*/
