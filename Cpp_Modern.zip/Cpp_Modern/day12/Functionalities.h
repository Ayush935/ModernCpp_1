#ifndef FUNCTIONALITIES_H
#define FUNCTIONALITIES_H

#include <memory>
#include <list>
#include "Employee.h"
//container is a list of EMpSptr where each
//EmpSptr is a share pointer to employee type

using EmpSptr = std::shared_ptr<Employee>;
using Container  = std::list<EmpSptr>;

void CreateObjects(Container &data);
/*
  HEAP
  ----------
  [101   |    761110.0F    |    HARSHIT   |   TRAINER    |   G]
  0X100H
  |
  |                         [102  |  8786  |  Rohan  |  UI DEV   |  G]
  |                         ^
  |                         |
                            |
 [ [0X100H  | 1 | 0]  [  0X200H  |  1    0]]
    shared_ptr             shared_ptr                     1  0  ---->   1 owner for the resource
                                                                        0 weak ptr looking at your 

    <--------------LIST------------------->
  
*/

#endif // FUNCTIONALITIES_H
