#ifndef EMPLOYEE_H
#define EMPLOYEE_H

#include <iostream>
#include <Grade.h>

class Employee
{
private:
    int _id;
    float _salary;
    std::string _name;
    std::string _destination;
    Grade _grade;

public:
    Employee(/* args */) = delete;
    Employee(const Employee &) = delete;
    Employee(Employee &&) = delete;
    Employee &operator=(const Employee &) = delete;
    Employee &operator=(Employee &&) = delete;
    ~Employee() = default;

    // parameterized constructors
    Employee(int id, std::string name) : _id{id},_name{name}{}
    Employee(int id,float salary,std::string name)
         : Employee(id,name){
            _salary = salary; 
         };
    Employee(int id,float salary,std::string name,std::string destination,Grade grade)
         : Employee(id,salary,name){
            _destination = destination;
            _grade = grade;
         };

    float operator+(const Employee& ohter){
         return this->_salary + ohter._salary;
    }

    friend std::ostream &operator<<(std::ostream &os, const Employee &rhs);
};

inline std::ostream &operator<<(std::ostream &os, const Employee &rhs) {
    os << "_id: " << rhs._id
       << " _salary: " << rhs._salary
       << " _name: " << rhs._name
       << " _destination: " << rhs._destination
       << " _grade: " ;

       std::string val{" "};

       if(rhs._grade == Grade::A){
         val =  "A";
       }
       else if(rhs._grade == Grade::B){
         val =  "B";
       }
       if(rhs._grade == Grade::C){
         val =  "C";
       }
       if(rhs._grade == Grade::D){
         val =  "D";
       }
       if(rhs._grade == Grade::E){
         val =  "E";
       }
       if(rhs._grade == Grade::F){
         val =  "F";
       }
       if(rhs._grade == Grade::G){
         val =  "G";
       }
       if(rhs._grade == Grade::H_AND_ABOVE){
         val =  "H_AND_ABOVE";
       }

       
    return os;
}

#endif // EMPLOYEE_H

/*
 Model for storing data of the employees
 For each employee, i would like to store

   -id
   -salar
   -name
   -destination
   -grade(which could A,B,C,D,E,F,G,H and above)

   -EMployee data should be non-copyable and non movable
   - there should be a way to print data of employees on the screen
   - using + operator with 2 employees type operands should add their salaries and return the result
*/