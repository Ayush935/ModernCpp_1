/*
  orignal amount : 1000
  if i do 100 transaction each to withdraw 10 rs
  and 
  100 transaction each to deposit 10 rs

  final transactio : 1000
*/

#include <iostream>
#include <thread>
#include <mutex>

int amount =1000;

std::mutex mt;

void Withdraw(){
    for(int i=0;i<100;i++){
        std::this_thread::sleep_for(std::chrono::milliseconds(2));
        mt.lock();
        amount = amount - 10;   //if exception is thrown then deadlock occurs
        mt.unlock();
    }
}

void Deposit(){
    for(int i=0;i<100;i++){
        std::this_thread::sleep_for(std::chrono::milliseconds(2));
        mt.lock();
        amount = amount + 10;
        mt.unlock();
    }
}

int main(){
    std::thread t1(&Withdraw);
    std::thread t2(&Deposit);
    if(t1.joinable()){
        t1.join();
    }

    if(t2.joinable()){
        t2.join();
    }

    std::cout<<amount<<std::endl;
}


/*
  WITHOUT MUTEX

  MAIN STARTS

  MAIN CREATES WITHDRAW

  MAIN CREATES DEPOSIT

  1000  ----------->  l3 CACHE ----------> l2 CACHE ------------->l1 CACHE  -----------> REDISTER[EAX] --------->ALU[1000 - 10 = 990]
  [RAM]
      <---------------------------------------------------------------------------------------------ANSWER
   DEPOSIT
   [990]
   1000-------------------------------------------------------------------------------------------------------->ALU[1000+10]
   <--------1010


*/