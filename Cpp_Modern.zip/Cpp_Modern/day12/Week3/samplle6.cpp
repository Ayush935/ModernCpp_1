/*
  Create 6 functions

  F1 : Take 5 members as input from the user. Saves it ti an array
  F2 : computes square of 1 integer
  F3 : computes cube of one integer
  f4 : computes 100 times the value of one input integer
  F5 : computes factorial of one input integer
  F6 : computes Nth fibonacci series value where N is the integer as input

  perform functions f[i+2] on data i
  f2(daata[0], f3(data[1]),f4[data3])

  input constraint: all inputs must be between 1 to 10

  e.g : 1 2 3 4 5
  output
  1
  8
  300
  24
  5

*/

#include <array>
#include <iostream>
#include <functional>
#include <thread>
#include <mutex>

std::mutex mt;

using Container = std::array<int, 5>;
using functions = std::function<int(int)>;
using Container2 = std::array<functions,5>;

void Adaptor(Container fn,Container2 fs){
    // for(int i=0;i<5;i++){
    //   (fs[i])(fn[i]);
    // }
    std::thread t1 (std::ref(fs[0]),fn[0]);
    if(t1.joinable()){
      t1.join();
    }
    std::thread t2 (std::ref(fs[1]),fn[1]);
    std::thread t3 (std::ref(fs[2]),fn[2]);
    std::thread t4 (std::ref(fs[3]),fn[3]);
    std::thread t5 (std::ref(fs[4]),fn[4]);

    

    if(t2.joinable()){
      t2.join();
    }
    if(t3.joinable()){
      t3.join();
    }
    if(t4.joinable()){
      t4.join();
    }
    if(t5.joinable()){
      t5.join();
    }

    for(int i=0;i<5;i++){
      std::lock_guard<std::mutex> lk(mt);
      std::cout<<fs[i](fn[i]);
    }


}

int main()
{
  auto f1 = [](int num)
  {  
    return num * num; };

  auto f2 = [](int num)
  {  
    return num * num * num; };

  auto f3 = [](int num)
  {   
     return 100 * num ; };

  auto f4 = [](int num)
  {int fact = 1;
    for(int i=1;i<=num;i++){
        fact = fact*i;
    }
     
    return fact; };

  auto f5 = [](int num) {
      int t1 = 0;
  
      int t2 = 1;

      int temp = 0;
      for(int i=1;i<num;i++){
           temp = t2;
           t2 = t2 + t1;
           t1 = temp;
      }
      return t2;
  };

  Container fn;
  for(int i = 0; i < 5; i++){
    std::cin >> fn[i];
}

   Container2 fs{f1,f2,f3,f4,f5};

  Adaptor(fn,fs);
}
