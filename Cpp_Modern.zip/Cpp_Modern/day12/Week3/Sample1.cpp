/*
  WHY??

  Computer Architecture
  PROCESSOR : SILICON CHIP WHICH CONTAINS REGISTERS, CACHE, ETC
  CORE : PHYSICAL SECTIONS INSIDE THE PROCESSOR
  EACH CORE IS CAPABLE OF HANDLING ONE PROCESS!
  CLOCK SPEED : INSTRUCTION PER CYCLE/SECOND
  THREAD  : Set of instructions that accupy memory and represent one isolated, independently excecutable section of process
*/

/*
  lscpu  | less       --------- 
  top                 ---------  commands



  1 unit of time
  every process gets 1 unit of time before it is switched for a different process

  ./app was a process : it got 1 unit of time
  before 1 unit of the time has passed , there is a delay
  (I/O, CPU delay)

  void f1(){user input square}
  

  void f2(){first 5 natural number cunbe}

  int main(){

  }

  4 cores:
  3 out of 4 cores get mapped to 3 of my threads
  maybe 2 threads got to mapped to 2 cores, 1 is waiting
  maybe 1 thread got mapped to 1 core, 2 threads are waiting!
*/



#include <iostream>
#include <thread>

void Square(int* arr, std::size_t N){
     for(int i=0;i<N;i++){
      int ans = arr[i]*arr[i];
      std::this_thread::sleep_for(std::chrono::seconds(1));
      std::cout<<"Square of"<<arr[i]<<"is "<<ans<<"\n";
     }
}

void Cube(int* arr, std::size_t N){
     for(int i=0;i<N;i++){
      int ans = arr[i]*arr[i]*arr[i];
      std::this_thread::sleep_for(std::chrono::seconds(1));
      std::cout<<"Cube of"<<arr[i]<<"is "<<ans<<"\n";
     }
}

int main(){
  int arr[] = {1,2,3,4,5};
  std::thread t1(Square,arr,5);
  std::thread t2(Cube,arr,5);
  

  //after creation of t2, many scenarios can be encountered
  //scenario 1: t1 is already completed by the time t2 is even started
  //scenario 2 : t1 and t2 are yet to be completed and running in the background
  if(t1.joinable()){
    t1.join();             //main thread should now wait till t1 is finished!  [block till t1 is finished]
  }
  if(t2.joinable()){
    t2.join();             //main thread should now wait till t2 is finished [block till t2 is finished]
  }

  std::cout<<"GoodBye\n" ; //can only execute after t1 and t2 is finished

  //race condition -> buffer access same memory
}                                                     
                                                          
/* 
                                                          
                                                          --------------->\
                                                          |                \
     MAIN STARTS                                          |                 \ 
  START  -------------->  ------------------------------->             ------------>
                       [t1 is created]                  [t2 is created]      /
                       |                                                    /
                       |                                                   /
                       |                                                  /
                        ----------------->cout & sleep ------------------>
                        [t1]

*/

/*
   raise condition and deadlock is different
*/

/*
  buffers -> they are dedicated memory space

  Hello, World-------------->Buffer             SCREEN
  |        |          |          |          [OUTPUT TEXT]

  Every process gets one buffer for stdout

  [   Square| Cube  <<1<<1<<1<<1   ]
*/