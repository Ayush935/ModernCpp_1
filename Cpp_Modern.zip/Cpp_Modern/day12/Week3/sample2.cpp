/*
   
*/

#include <iostream>
#include <thread>
#include <mutex>

std::mutex mt;

void Square(int* arr, std::size_t N){
     for(int i=0;i<N;i++){
      int ans = arr[i]*arr[i];
      std::this_thread::sleep_for(std::chrono::seconds(1));
      mt.lock();
      std::cout<<"Square of"<<arr[i]<<"is "<<ans<<"\n";
      mt.unlock();
     }
}

void Cube(int* arr, std::size_t N){
     for(int i=0;i<N;i++){
      int ans = arr[i]*arr[i]*arr[i];
      std::this_thread::sleep_for(std::chrono::seconds(1));
      mt.lock();
      std::cout<<"Cube of"<<arr[i]<<"is "<<ans<<"\n";
      mt.unlock();
     }
}

int main(){
  int arr[] = {1,2,3,4,5};
  std::thread t1(Square,arr,5);
  std::thread t2(Cube,arr,5);
  

  
  if(t1.joinable()){
    t1.join();            
  }
  if(t2.joinable()){
    t2.join();             
  }

  std::cout<<"GoodBye\n" ; 
}                                                     
                                                          

