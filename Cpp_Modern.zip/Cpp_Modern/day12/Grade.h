#ifndef GRADE_H
#define GRADE_H

enum class Grade{
    A,B,C,D,E,F,G,H_AND_ABOVE
};

#endif // GRADE_H
