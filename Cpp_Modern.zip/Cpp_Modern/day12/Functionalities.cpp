#include "Functionalities.h"

void CreateObjects(Container &data)
{
    data.emplace_back(
        std::make_shared<Employee>(101, 123.0f, "Ayush", "Pune", Grade::A)
    );
    data.emplace_back(
        std::make_shared<Employee>(102, 323.0f, "Bob", "Delhi", Grade::B)
    );
    data.emplace_back(
        std::make_shared<Employee>(103, 153.0f, "Bobby", "Pune", Grade::C)
    );
}

/*
  PRE MORDERN CPP
  PUSH_BACK
  LIST

  STEP1 : Allocate memory to make a new Employee on heap

  [
    Step 2: Initialize the object
    [101, 123.0f, "Ayush", "Pune", Grade::A]
    
    Step 3 : Register this as a new node
    [101, 123.0f, "Ayush", "Pune", Grade::A]
    <---------------Node-------------------->

    step 4: Copy the node into the linked list

    step 5: Now delete the orignal node
  ]


  emplace_back       ------> you are saving the extra copy operation

  STEP1 : Allocate memory to make a new Employee on heap.
          Assign this to memory the linked
          [existing node] -------->
          
          Step 2: Initialize the object
          [101, 123.0f, "Ayush", "Pune", Grade::A]


   emplace_ back can only work with Rvalues
   if i am using rvalues in the push operation then emplace is taking place
                  |----> mov semantics
   push_back have ------> copy semantics
*/