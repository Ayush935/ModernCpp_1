#include "FullTimeEmployee.h"
#include <unordered_map>
#include <algorithm>
#include <numeric>
using FullTimeEmployeePtr = std::shared_ptr<FullTimeEmployee>;
using UMapContainer = std::unordered_map<std::string,FullTimeEmployeePtr>;

void CreateObject(UMapContainer &data);

void Display(UMapContainer &data);

void SalaryAverage(UMapContainer &data);