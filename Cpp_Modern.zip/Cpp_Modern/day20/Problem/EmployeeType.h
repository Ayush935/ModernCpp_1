#ifndef EMPLOYEETYPE_H
#define EMPLOYEETYPE_H

enum class EmployeeType{
    AD,
    AC,
    CD
};

#endif // EMPLOYEETYPE_H
