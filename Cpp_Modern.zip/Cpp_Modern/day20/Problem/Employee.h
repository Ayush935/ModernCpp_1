#ifndef EMPLOYEE_H
#define EMPLOYEE_H

#include <iostream>
#include "EmployeeType.h"

class Employee
{
private:
    EmployeeType _employee_type;
public:
    Employee(/* args */) = default;
    Employee(const Employee &) = delete;
    Employee(Employee &&) = default;
    Employee &operator=(const Employee &) = delete;
    Employee &operator=(Employee &&) = delete;
    ~Employee() = default;
    Employee(EmployeeType employee_type);
    EmployeeType employeeType() const { return _employee_type; }

    friend std::ostream &operator<<(std::ostream &os, const Employee &rhs);
};

#endif // EMPLOYEE_H
