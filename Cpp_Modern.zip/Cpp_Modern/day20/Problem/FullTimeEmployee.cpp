#include "FullTimeEmployee.h"
std::ostream &operator<<(std::ostream &os, const FullTimeEmployee &rhs) {
    os << "_id: " << rhs._id
       << " _name: " << rhs._name
       << " _location: " << rhs._location
       << " _age: " << rhs._age
       << " _salary: " << rhs._salary
       << " _emp_ref: " << rhs._emp_ref.get();
    return os;
}

FullTimeEmployee::FullTimeEmployee(std::string id, std::string name, std::string location, int age, int salary, EmployeeRef emp_ref)
    : _id{id},_name{name},_location{location},_age{age},_salary{salary},_emp_ref{emp_ref}
{
}