#include "Employee.h"
std::ostream &operator<<(std::ostream &os, const Employee &rhs) {
    os << "_employee_type: " << static_cast<int>(rhs._employee_type);
    return os;
}

Employee::Employee(EmployeeType employee_type)
    : _employee_type{employee_type}
{
}