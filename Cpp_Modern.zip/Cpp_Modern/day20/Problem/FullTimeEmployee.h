#ifndef FULLTIMEEMPLOYEE_H
#define FULLTIMEEMPLOYEE_H

#include <iostream>
#include "Employee.h"
#include <functional>
#include <memory>
// using EmployeePtr = std::shared_ptr<Employee>;
using EmployeeRef = std::reference_wrapper<Employee>;

class FullTimeEmployee
{
private:
    std::string _id;
    std::string _name;
    std::string _location;
    int _age;
    int _salary;
    EmployeeRef _emp_ref;

public:
    FullTimeEmployee(/* args */) = default;
    FullTimeEmployee(const FullTimeEmployee &) = delete;
    FullTimeEmployee(FullTimeEmployee &&) = delete;
    FullTimeEmployee &operator=(const FullTimeEmployee &) = delete;
    FullTimeEmployee &operator=(FullTimeEmployee &&) = delete;
    ~FullTimeEmployee() = default;

    FullTimeEmployee(std::string id,
                     std::string name,
                     std::string location,
                     int age,
                     int salary,
                     EmployeeRef emp_ref);

    std::string id() const { return _id; }

    std::string name() const { return _name; }

    std::string location() const { return _location; }

    int age() const { return _age; }

    int salary() const { return _salary; }

    EmployeeRef empRef() const { return _emp_ref; }

    friend std::ostream &operator<<(std::ostream &os, const FullTimeEmployee &rhs);
};

#endif // FULLTIMEEMPLOYEE_H
