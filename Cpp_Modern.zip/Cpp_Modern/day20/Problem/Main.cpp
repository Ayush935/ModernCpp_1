#include "Functionalities.h"

int main(){
    UMapContainer data;
    CreateObject(data);
    Display(data);

    SalaryAverage(data);

}