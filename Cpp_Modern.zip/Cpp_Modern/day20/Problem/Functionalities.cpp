#include "Functionalities.h"

void CreateObject(UMapContainer &data)
{
    Employee A = Employee(EmployeeType::AC);
    
    data.emplace(
        std::pair<std::string,FullTimeEmployeePtr>(
            "101",
            std::make_shared<FullTimeEmployee>("101","Ayush","Pune",21,234554,std::ref(A))
        )
    );
    data.emplace(
        std::pair<std::string,FullTimeEmployeePtr>(
            "102",
            std::make_shared<FullTimeEmployee>("101","Ayush","Pune",21,234554,std::ref(A))
        )
    );
    data.emplace(
        std::pair<std::string,FullTimeEmployeePtr>(
            "103",
            std::make_shared<FullTimeEmployee>("101","Ayush","Pune",21,234554,std::ref(A))
        )
    );

    
}

void Display(UMapContainer &data)
{
    for(auto& [k,v] : data){
        std::cout<<k<<" "<<*v<<"\n";
    }
}

void SalaryAverage(UMapContainer &data)
{
    int sum = std::accumulate(
        data.begin(),
        data.end(),
        0,
        [](int return_value,const std::pair<std::string,FullTimeEmployeePtr>& p){
             return return_value+p.second->salary();
        }
    );

   

    std::cout<<sum<<std::endl;
}
