
/*

#include <iostream>
#include <algorithm>

int main(){
    StackObjects result1;

    auto itr =  std::copy_n(
        data1.begin(),
        2,
        std::inserter(result1,result1.begin())
    );

    if(result1.size()==2){
        std::cout << "Elements copied\n";
    }


    auto itr = std::copy_if(
        data1.begin(),
        data1.end(),
        std::inserter(result1, result1.begin()),
        [](const Employee& emp) { return emp.location()=="Pune";}
    );

    if(result1.size()==0){
        std::cout<<"No Matching elemnt found\n";
    }
}
------>array list vector  -------- reverse ------- rbegin
*/