/*
  to find the position of the first matching data in input container
  e.g Find the employee name for the employee whose ID matches with id provided
  e.g Find the name of the first employee in input whose salary is above 50000

  Position   find_if(input iter, input iter, predicate)

  find_if returns iterator to match found (first match) or end iterator
  for input data if match is not found!

*/

/*
  #include <algorithm>
  #include "Functionalities.h"
  void FetchNameById(std::string id, StackObject&data){
       auto itr = std::find_if(
        data1.begin(),
        data1.en(),
        [&](const Employee& emp){ return emp.eid==id;}
    );
    if(itr==data.end()){std::cerr << "Data with matching is not found\n"}
    else{
        std::cout<<(*itr).name()<<std::endl;
    }
    
  }

  StackObjects::const_iterator FetchNameById(std::string id, StackObject&data){
       auto itr = std::find_if(
        data1.begin(),
        data1.en(),
        [&](const Employee& emp){ return emp.eid==id;}
    );
    return itr;
    
  }


  int main(){

    auto itr = std::find_if(
        data1.begin(),
        data1.en(),
        [&](const Employee& emp){ return emp.eid==id;}
    );

    if(itr==data.end()){std::cerr << "Data with matching is not found\n"}
    else{
        std::cout<<(*itr).name()<<std::endl;
    }

     StackObjects::const_iterator ans = 
  }
*/