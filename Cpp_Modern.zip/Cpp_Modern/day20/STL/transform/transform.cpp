#include <iostream>
#include <algorithm>


// SFINAE : Substitution Failure is not an Error
int main(){
    std::vector<int> data{12,23,45,34,21,23,33};
    std::vector<int>result;
    /*
      Square every element between begin and end of input data 
      and store corresponding output values in the result vector
    */
    std::transform(
        data.begin(),
        data.end(),
        std::inserter(result,result.begin()),
        [](int num ){return num*num;}
    );

    auto itr = std::max_element(
        data.begin(),
        data.end(),
        [](int num1,int num2){
            return num1<num2;
        });
    std::cout<<*itr<<std::endl;

    auto min = std::min_element(
        data.begin(),
        data.end(),
        [](int num1,int num2){
            return num1<num2;
        });
    std::cout<<*min<<std::endl;
   
    for(int& p: result){
        std::cout<<p<<" ";
    }
}

/*
  auto itr = std::max_element(
    data1.begin(),
    data1.end(),
    [](const Employee& emp1,const Employee& emp2){return emp1.salary()>emp2.salary();}
  )
*/