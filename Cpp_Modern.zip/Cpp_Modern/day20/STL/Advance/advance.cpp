#include <iostream>
#include <algorithm>
#include <vector>

int main(){
    std::vector<int> data{11,19,14,17,21,16,20};

    /////////////////

    //first number divisible by 7 amongst the last 3 integers in input!
    
    //objective : move initial iterator to 3rd element
    //process : 
    //size : 7
    //destination 3rd last 4
    //beginning : 11 [0]
     
    auto itr = data.begin();
    std::advance(itr,data.size()-3);
    std::vector<int>::iterator result = std::find_if(
        data.begin(),
        data.end(),
        [](int number){return number%3 == 0 ;}
    );

    if(result!=data.end()){
        std::cout<<"First number divisible by 7 amongst the numbers "<<*result<<std::endl;
    }
    
}