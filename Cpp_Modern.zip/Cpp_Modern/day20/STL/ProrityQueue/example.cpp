/*
  i want to create a software in which each time a new entry of data happens, my data gets internally "rearranged" 
  such that I always find the vehicle with highest price as the very first item from the collection
*/

/*
 0000 0000 0000 0000 0000 0000 00000 0101
  computers : raw data (binary)
                |
            meaningful information
                |
                |
                |
                structure of representation like a primitive data
                |
                |
                convenient mechanism to access int data type in cpp
*/

/*
  Objective : Store employee IDs of 4 employees in a software system (for processiong later)
  Simple Data : 101,102,103,201
  option 1) is size is fixed, array data structure

  101     102     103     104
  0x100H  0x100H  0x100H  0x1cH

  option 2) is size can vary but data has to be stored contiguously, vector

  101    102    103   201
  0x100H 0x104H 0x108 0x1c///////

  adding 5th element 202 may cause data to be shifted

  101    102    103    201   202
  0x200H 0x204H 0x208H 0x2c  ..    ...  ..  ....

  option 3) if size has to vary but storing data continuously is not imported

  0x88H               0x106H          0x200H            0x307H
  nullptr|101|0x100H  0x88H|102|0x209 0x106H|103|0x307H 0x209H|201|nullptr

  option4) if element has to be accessed in quickest possible time, ordered does not matter and data 
  being sequential is not a concern

  hash funciton : mod 4
  i)   101 % 4 = 1
  ii)  102 % 4 = 2;
  iii) 103 % 4 = 3
  iv)  201 % 4 = 1 (collison)

  key               value
  []               [///////]  [0]
  [101]---->[201]  [///////]  [1]
  [102]            [///////]  [2]
  [103]            [///////]  [3]

  option : I want to only access the most recently entered data from my data collection
  
  0x88H               0x106H          0x200H            0x307H
  nullptr|101|0x100H  0x88H|102|0x209 0x106H|103|0x307H 0x209H|201|nullptr
                                                          |
                                                          |
                                                          top_pointer


  option 6 : i want to store data such that i can access the data added the earliest (very first) in sequence 
  and no other item from data

  101    102    103    201
  0x100H 0x104H 0x108H 0x1cH
  ^                     ^
  |                     |
  front[exit]          rear/back [entry
  
  101 : 7 years experience
  102 : 5 years experience
  103 : 9 years experience
  201 : 11 years experience

  objective : I want to assign free/available resources to projects in HIGHEST EXPERIENCE gest FIRST FASHION

  step 1:
     
     101/7 years experience
         | 
         102 | 5 years experience
*/



/*---------------------------------------------------------------------------------------*/

#include <queue>
#include <memory>
#include <iostream>


class Vehicle
{
private:
    /* data */
    std::string _id;
    float _price;
public:
    Vehicle(/* args */) {}
    ~Vehicle() {}
    Vehicle(std::string id,
    float price) : _id{id},_price{price}{}

    float price() const { return _price; }

    friend std::ostream &operator<<(std::ostream &os, const Vehicle &rhs);
};

using Vptr = std::shared_ptr<Vehicle>;

int main(){
    
    auto f1 = [](const Vptr& v1, const Vptr& v2){
        return v1->price() < v2->price();
    };

    std::priority_queue<Vptr,std::vector<Vptr>,decltype(f1)> pq(f1);

    auto v1 = std::make_shared<Vehicle>("v101",89000.0f);
    auto v2 = std::make_shared<Vehicle>("v101",99000.0f);

    pq.emplace(v1);
    pq.emplace(v2);

    std::cout<<*pq.top()<<"\n";
}

inline std::ostream &operator<<(std::ostream &os, const Vehicle &rhs) {
    os << "_id: " << rhs._id
       << " _price: " << rhs._price;
    return os;
}













