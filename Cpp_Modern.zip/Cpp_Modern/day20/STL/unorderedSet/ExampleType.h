#ifndef EXAMPLETYPE_H
#define EXAMPLETYPE_H

enum class ExampleType{
    AD,
    CD,
    DF
};

#endif // EXAMPLETYPE_H
