#include <iostream>
#include <unordered_set>
#include "ExampleType.h"
class example
{
private:
    /* data */
    int _id;
    std::string _name;
    ExampleType _type;

public:
    example(/* args */) = default;
    example(const example&) = default;
    example(example&&) = delete;
    example& operator=(const example&) = delete;
    example& operator=(example&&) = delete;
    ~example() = default;

    example(int id,std::string name,ExampleType type): _id{id},_name{name},_type{type} {}

    int id() const { return _id; }

    std::string name() const { return _name; }
};


int main(){
    example a(101,"Ayush",ExampleType::AD);
    example b(102,"Bob",ExampleType::CD);
    example c(101,"Ayush",ExampleType::CD);

    std::unordered_set<int> data;
    data.insert({a.id(),b.id(),c.id()});

    for(const int& i : data){
         std::cout<<i<<std::endl;
    }
    std::unordered_set<ExampleType> types{ExampleType::AD,ExampleType::CD,ExampleType::DF,ExampleType::CD};
    std::unordered_set<ExampleType> uset { types.begin(),types.end()};
    for(const ExampleType& v: uset) {
        std::cout << static_cast<int>(v)<<std::endl;
    }

}

/*
  i want to create a software in which each time a new entry of data happens, my data gets internally "rearranged" 
  such that I always find the vehicle with highest price as the very first item from the collection
*/