#include <iostream>
#include <algorithm>


int main(){

    std::vector<int> data{11,19,14,17,21,16,20};
    //////////////////////
    std::vector<int>::iterator itr = std::find_if(
        data.begin(),
        data.end(),
        [](int number){return number%3 == 0;}
    );
    
    if(itr!=data.end()){
        std::cout<< std::distance(data.begin(),itr);
    }
    

}

/*
  11 19 14 17 21 16 28
               ^
               |
               itr
  find the first number which is divisible by 3 (expected anser : 21)

  objective : copy all odd numbers into result container and display the square of last element copied!

  result : 11, 19, 17, 21                ]]]]] end
                          ^
                          |
                          copy_if returns this!
*/