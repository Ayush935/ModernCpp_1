#include <iostream>
#include <algorithm>


// SFINAE : Substitution Failure is not an Error
int main(){
    std::vector<int> data{12,23,45,34,21,23,33};
    auto itr = data.begin();
    auto new_itr = std::next(itr,data.size()-3);

    std::vector<int>::iterator result = std::find_if(
        new_itr ,
        data.end(),
        [](int num){return num%3==0;}
    );
    
    std::cout<<*result<<std::endl;

}