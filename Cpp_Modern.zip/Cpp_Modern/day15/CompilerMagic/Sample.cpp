#include <iostream>

class Dummy
{
private:
    int _id;
public:
    explicit Dummy(int id): _id{id}{}
    Dummy(/* args */) =delete;
    Dummy(const Dummy&) = delete;
    Dummy(Dummy&&) = default;
    Dummy& operator=(Dummy&&) = delete;
    Dummy& operator=(const Dummy&) = delete;
    ~Dummy() = default;

    friend std::ostream &operator<<(std::ostream &os, const Dummy &rhs) {
        os << "_id: " << rhs._id;
        return os;
    }
};

// Directive copy guaranteed ellison   
Dummy Magic(){
    Dummy d(101);
    return d;
}

int main(){
    //d1 is of type dummy and will be ASSIGNED WHATEVER is returned from Magic()
    Dummy d1 = Magic(); //Mgic takes 0 arg from user + return address for where d1 is the constructor
    std::cout<<d1<<"\n";
}

/*
  C language
  Magic                  Main
  [101]    ---------->   [101]
  4 bytes                4 bytes
  [0x100H]               [0x99H]

  CPP language
  Magic                  Main
   D     ------------>    d1
  [101]                4bytes[0x99H]
  0x100H

  Modern CPP [Guaranteed with CPP 17]

  Magic     Main
             d1
   101------->[]
             4bytes
             0x99H

             std::cout<<d1;
*/


//void Magic(int n1,char grade);