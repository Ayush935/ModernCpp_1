/*
  Create a class with Producer_Input and Consumer_Operation as a 2 new member function
  - std::mutex
  - std::conditon_variable
  - value(data)
  - malloc allocation using _result int pointer

  How many parameters will constructor take?

  DataOperation();
*/

#ifndef DATAOPERATION_H
#define DATAOPERATION_H

#include <mutex>
#include <iostream>
#include <condition_variable>

/*
  1)  which function is invoked while constructing a new object?
   - a public member function

   *) Make the constuctor private!

   2) if constructor is private, how would be make the first object?
     *) Make a seperate member function that accesses constructor from inside the class and completes the task

    3) My Ojectives is first time we get new object , for all other subsequent times, we need to return
    same object again and again, HOW DO I SAVE SOMETHING AS A COMMON VALUE FOR THE WHOLE CLASS
*/

class DataOperation
{
private:
    int m_value{-1};
    std::mutex m_mt;
    std::condition_variable m_cv;
    bool m_flag{false};
    int *value{nullptr};
    DataOperation(/* args */) =delete;
    DataOperation(const DataOperation&) = delete;
    DataOperation(DataOperation&&) = delete;
    DataOperation& operator=(DataOperation&&) = delete;
    DataOperation& operator=(const DataOperation&) = delete;
    DataOperation(int value) : m_value{value} {}
    static DataOperation* _only_object;
public:
     static DataOperation* GetInstance(int val);
    ~DataOperation() = default;
    void Producer_input();
    void Consumer_Operation();
};

/*
  Program starts 
  ---->  programmar wants first object
        --------> programmer notices no constructor
        --------> programmer also notices Getinstance
        --------> Programmer invokes GetInstances

  -----> GetInstance will check if previously any object was created,
       ------> if not, make a new object , return its address
       ------> else, return the address of the exixting object

*/



#endif // DATAOPERATION_H
