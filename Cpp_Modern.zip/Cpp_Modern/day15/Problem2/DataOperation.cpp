#include "DataOperation.h"

DataOperation* DataOperation:: _only_object(nullptr);

/*
 if _only_object is not null, it means previously, object was created. Its address was saved
 int he _only_object pointer. This means I can directly return the existing object

 otherwise,
 nullptr means, object does not exist. I need to make a new object. Save its address in the _only_object
 in the poiner, then return this pointer
*/

DataOperation *DataOperation::GetInstance(int val)
{
    if (_only_object)
    {
        //already created since it is not null
        return _only_object;
    }
    else{
        _only_object = new DataOperation(val);
        return _only_object;
    }
}

void DataOperation::Producer_input()
{
    std::cin>>m_value;
    //triger a signal after cin is done, to indicate that consumer
    m_flag = true;
    m_cv.notify_one();
}

void DataOperation::Consumer_Operation()
{
    int * m_result_value = (int *)malloc(4);
    /////////////////////////////
    std::unique_lock<std::mutex> ul(m_mt);
    m_cv.wait(ul, [&]()
            { return m_flag; });

    *m_result_value = m_value * m_value;

    std::cout << "Square calculation is completed " << *m_result_value << std::endl;
}
