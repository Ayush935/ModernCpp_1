#include "DataOperation.h"
#include <thread>

int main(){
    DataOperation* ptr = DataOperation::GetInstance(10); //placeholder initial value 

    std::thread t1{&DataOperation::Producer_input, ptr};
    std::thread t2 {&DataOperation::Consumer_Operation, ptr};

    if(t1.joinable()){t1.join();}
    if(t2.joinable()){t2.join();}
}

/*
  whatever line u are writnig before cv.wait it can executed before the signal
*/