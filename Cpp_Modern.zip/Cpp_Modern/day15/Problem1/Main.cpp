#include <thread>
#include <iostream>
#include <condition_variable>

int value{-1};
std::condition_variable cv;
std::mutex mt;
bool flag(false);

void Producer_input()
{
    std::cin >> value;
    // trigger  a signal after cin is done to indicate that consumer
    // can proceed with square calculation
    flag = true;
    cv.notify_one(); // send signal to any one of the consumers
}
void Consumer_Operation()
{
    int *result = (int *)malloc(4);
    /////////////////////////////
    std::unique_lock<std::mutex> ul(mt);
    cv.wait(ul, []()
            { return flag; });

    *result = value * value;

    std::cout << "Square calculation is completed " << *result << std::endl;
}

int main()
{
    std::thread t1(&Producer_input);

    std::thread t2(&Consumer_Operation);

    t1.join();
    t2.join();
}

/*
  Scenario 1
     
     t1 starts first
                                        [ ask for input, NOW T1 is waiting for input]
                                        ^
                                        |
                                        |
     start ----> main starts -----> creates t1 ------> creates t2
                                                          |
                                                          |
                                                          [malloc]  
                                                          a) t2 will apply a lock
                                                          b) check if input is received, yes or no
                                                          c) cv.wait checks a predicate
                                                              |
                                                              |
                                                              ----------if false, release the lock
                                                        
*/