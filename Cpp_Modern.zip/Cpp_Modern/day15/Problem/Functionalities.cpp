#include "Functionalities.h"

void Square(DataContainer &data, ResultContainer &result)
{
    int k = 0;
    for(int val : data){
        result[k++] = val*val;
    }
}

void Cube(DataContainer &data, ResultContainer &result)
{
    int k = 0;
    for(int val : data){
        result[5+k++] = val*val;
    }
}

void Factorial(DataContainer &data, ResultContainer &result)
{
    int k = 0;
    for(int val : data){
        if(val==0 || val == 1){
            result[10 + k++] = 1;
        }

        else{
            int ans =1;
            for(int count=2;count<=val;count++){
                ans*=count;
            }

            result[10+k++] = ans;
        }
    }
}

void MapThreadsToFunctions(ThreadsArray &th,DataContainer &data, ResultContainer &result)
{
//    th[0] = std::thread(&Square,std::ref(data),std::ref(result));
//    th[1] = std::thread(&Cube,std::ref(data),std::ref(result));
//    th[2] = std::thread(&Factorial,std::ref(data),std::ref(result));

    auto itr = th.begin();
    *itr++ = std::thread(&Square,std::ref(data),std::ref(result));
    *itr++ = std::thread(&Cube,std::ref(data),std::ref(result));
    *itr++ = std::thread(&Factorial,std::ref(data),std::ref(result));
}

void JoinThreads(ThreadsArray &th)
{
    for(std::thread &t : th){
        if(t.joinable()){
            t.join();
        }
    }
}

void Display(ResultContainer &result)
{
    for(int val : result){
        std::cout<<val<<"\n";
    }
}

void Input(DataContainer &data)
{
    int count{0};
    int val{-1};
    while (count!=5)
    {
        std::cin>>val;
        if(val<0 || val>10){
            continue;
        }

        data[count++] = val;
    }
    
}


