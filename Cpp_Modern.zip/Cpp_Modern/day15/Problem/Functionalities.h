#ifndef FUNCTIONALITIES_H
#define FUNCTIONALITIES_H

#include <array>
#include <iostream>
#include <thread>
using DataContainer = std::array<int,5>;
using ResultContainer = std::array<int,15>;
using ThreadsArray = std::array<std::thread, 3>;

void Square(DataContainer& data, ResultContainer &result);

void Cube(DataContainer& data, ResultContainer &result);

void Factorial(DataContainer& data, ResultContainer &result);

void MapThreadsToFunctions(ThreadsArray &th,DataContainer &data, ResultContainer &result);

void JoinThreads(ThreadsArray &th);

void Display(ResultContainer& result);

void Input(DataContainer& data);


#endif // FUNCTIONALITIES_H
