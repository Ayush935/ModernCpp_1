#include "Functionalities.h"

int main()
{
    DataContainer data;
    ResultContainer result;
    ThreadsArray th;

    Input(data);
    // Square(data, result);
    // Cube(data, result);
    // Factorial(data, result);

    MapThreadsToFunctions(th,data, result);
    JoinThreads(th);
    Display(result);
}
