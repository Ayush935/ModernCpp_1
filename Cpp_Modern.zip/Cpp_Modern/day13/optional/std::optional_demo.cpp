/*
  Container of employees
      - id,name and salary

  A function that returns a container of all employees with salary above 50000.0f

  - scenario1 : input data is not valid(empty)
    - exception
  - scenario2 : input is valid, at least 1 employee above 50k salary exists,
    - make a result container, puch employees into result and return result
  - scenario3 : input is valid but no employee has salary above 50k
    - we return an empty result container
    - throw an exception for NomatchingInstancesFound
         a) is it really an exception
          
          Container FindAbove50kEmployees(Container& data){
            if(data.empty()){
                throw ;//
            }
            Container result;
            for(employee in data){
                if(employee salary is above 50){
                    push employee to result;
                }
            }

            return result;
          }

          Python : None data type
          Java : optional (Java 10)
          C# : optional returns
          kotlin : elvis operator or Null check
          CPP : std::optional
          Rust : result enum
          scala : Some or None enum

*/

#include "Employee.h"
#include <vector>
#include <memory>
#include <optional>
using Container = std::vector<std::shared_ptr<Employee>>;

void CreateObjects(Container &data){
    data.push_back(std::make_shared<Employee>("Ayush",2132.32f));
    data.push_back(std::make_shared<Employee>("Bob",3132.32f));
    data.push_back(std::make_shared<Employee>("Bobby",2332.32f));
}

std::optional<Container> FindAbove50kEmployees(Container &data){
    if(data.size()==0){
        throw std::runtime_error("Data is empty");
    }

    Container result;

    for(std::shared_ptr<Employee>& emp : data){
        if(emp->salary()>50000.0f){
            result.push_back(emp);
        }
    }
    
    if(result.empty()){
        return std::nullopt;  //nothing to show , nothing to return
    }

    return result;

}

int main(){
    Container data;
    CreateObjects(data);
    
    //user calls the function, may or may not have a value in result
    std::optional<Container> result = FindAbove50kEmployees(data);
    //std::cout << result.size();
    
    //check if result actually has a value inside
    if(result.has_value()){  //boolean

    //if yes, extract the value and perform further operations
        Container actual_value = result.value();  //extract the value
    }
    else{
        //data mot available
        //since no employee has above 50k
    }
}

/*
  A function to return Car type instamnces from variant of Car and Bike

  A function to return average from instances in the data container
*/