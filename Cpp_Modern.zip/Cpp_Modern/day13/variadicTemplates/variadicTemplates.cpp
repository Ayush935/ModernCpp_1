#include <iostream>
#include <vector>

/*
template <typename T>
void Display(std::vector<T>& data){
     for(T val : data){
        std::cout <<val << "\n";
     }
}

int main(){
     std::vector<int>v1{1,2,3,4,5};
     std::vector<std::string>v2 {"as","sd","ew"};
     Display<int>(v1);
     Display<std::string>(v2);
}

*/


/*
  Factorial of 5

  Problem :  a situation which requires a particular "algorithm to find its solution"
  e.g: Searching a number
  
  problem solving techniques
      a) Iterative approach
      b) Divide and Conquer
      c) Recurssion : divide the problem into smaller problems till a well known, fully solved sub_problem apperars,
      then you reverse the chain and solve the whole process

  Factorial(5)
            |
            5 * Factorial(4)
                          |
                          4 * Factorial(3)
                                        |
                                        3 * Factorial(2)
                                                      |
                                                      2 * Factorial(1)
  */

 /*
     minimum value from an array of value
         current min compared with first item from unaccessed array

         [ 10  11  7  19  13]

         current min
         10
 */

template <typename T>

T add(T n1){
     return n1;
}

template<typename T, typename... Remaining>
T add(T n1, Remaining... args){
     return n1 + add(args...);
}

//add<int>(10,20,30,40,50)
/*
  n1 is 10
  T is int
  args is (20,30,40,50)
  Type of args is remaining
*/
/*
  template<typename T,typesname... others>
  add(Tn1 + others... args){
     n1 + add(args....)
  }
*/

/*
  How to create a type agnostic (type independent) logic
  that can apply an operator on 0 or more arguments by using
  recurssion as its problem solving technique ?
  example : add 1 or more numbers
  example : use * operator on 1 or more values
*/

int main(){
     std::cout << add<int>(10,20,30,40,50)<<'\n';
     std::cout << add<float>(10.5f,20.4f,30.4f,40.7f,50.5f)<<"\n";
}
/*
  Finding minimum between values
    - count of values
    - type of values
*/

