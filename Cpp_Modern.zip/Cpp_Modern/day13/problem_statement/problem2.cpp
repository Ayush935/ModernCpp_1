#include <thread>
#include <array>
#include <iostream>

using DataContainer = std::array<int, 12>;
using ThreadContainer = std::array<std::thread, 4>;
using ResultContainer = std::array<int, 12>;

void Square(DataContainer &data, ResultContainer &result, int start, int end)
{
    for (int i = start; i < end; i++)
    {
        result[i] = data[i] * data[i];
    }
}

void MapThreadsToData(DataContainer &data, ThreadContainer &thArr, ResultContainer &result)
{
    int chunkSize = data.size() / thArr.size();
    int start = 0;

    for (std::thread &th : thArr)
    {
        int end = start + chunkSize;
        th = std::thread(&Square, std::ref(data), std::ref(result), start, end);
        start = end;
    }

    for (std::thread &th : thArr)
    {
        if (th.joinable())
        {
            th.join();
        }
    }
}

int main()
{
    DataContainer data{1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12};
    ThreadContainer thArr;
    ResultContainer result;

    MapThreadsToData(data, thArr, result);

    for (int i = 0; i < result.size(); i++)
    {
        std::cout << result[i] << " ";
    }
    
    return 0;
}