/*
  objective:
      12 numbers stored in an array

      calculate the square of each number in the array and store in a result array
      1 2 3 4 5 6 7 8 9 10 11 12

      result 1 4 9 16 25 36 49 64 81 100 121 144

*/

#include <thread>
#include <array>
#include <iostream>

using DataContainer = std::array<int, 11>;
using ThreadContainer = std::array<std::thread, 4>;
using ResultContainer = std::array<int, 11>;

void Display(DataContainer &data)
{
   for (int val : data)
   {
      std::cout << val << "\n";
   }
}

void Square(DataContainer &data, ResultContainer &result, int startingValue, int endingValue)
{
   for (int i = startingValue; i < endingValue; i++)
   {  
      if(i>=data.size()){
         break;
      }
      result[i] = data[i] * data[i];
   }
}

void MapThreadsToData(DataContainer &data, ThreadContainer &thArr, ResultContainer &result)
{
   int size = data.size() / thArr.size();
   int startingValue = 0;
   for (std::thread &th : thArr)
   {
      int endingValue = startingValue + 3;
      th = std::thread(&Square, std::ref(data), std::ref(result),startingValue,endingValue);
      startingValue = endingValue;
      if(startingValue>=data.size()){
         break; //
      }
   }

   for (std::thread &th : thArr)
   {
      if (th.joinable())
      {
         th.join();
      }
   }
}

int main()
{
   DataContainer data{1, 2, 3, 4, 5, 6, 7, 8, 9, 10,11};
   ThreadContainer thArr;
   ResultContainer result;

   MapThreadsToData(data, thArr, result);

   for(int i=0;i<result.size();i++){
      std::cout<<result[i]<<std::endl;
   }
}

/*
  N number of data values
  X numbe rof threads in process

  Scenario 1: N can be equally divided amongs X threads


  Solution1 :
  1) declare the threads array and data array
  2) Create threads by mapping square function on 3 data values each.
  3) Wait for all of these threads to complete
  4) After all the threads are done, call display and print the

  Solution2 :
  1) Create a class with logic for square written somewhere
  (member function, overload for operator())
  2) initialize one object of this class where we have memory for input data and output data
  3) Create a maping funciton to assign 3 values per head
  4) Write for all threads in step 3 to complete
  5) Write logic for display and show output


  writing solutions happens in phases/steps
  a) interpret the problem accurately
  b) Design solutions
     b1) evaluate each of your solutions for feasible
     b2) now do analysis and "try to find" the best solution amongst all
  c) Implement the solution
  d) unit test the solution for all possible corner cases
  e) Document the solution
  f) Use VCS to maintain the code
  g) assist in devlopment
  h) Maintain the code
*/