//c++17

struct  Employee{
    int _id;
    char _grade;
};

union Employee{
    int _id;
    char _grade;
};

int main(){
    union  Employee e1;
    e1._grade = 'A';
    
}

/*
   Employee
   - manager
   - accountant
   - hr
   in future no 4th type will be added

   variant<manager,accountant,hr> = h1;
   if number of objects is fixed , then variant is used. -> supports only in c++17
   if not inheritance can be used
*/
