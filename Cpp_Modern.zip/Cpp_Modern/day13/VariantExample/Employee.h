#ifndef EMPLOYEE_H
#define EMPLOYEE_H

#include <iostream>

class Employee
{
private:
    std::string _name;
    float _salary;

public:
    Employee(/* args */) = default;
    Employee(const Employee &) = delete;
    Employee &operator=(const Employee &) = delete;
    Employee &operator=(Employee &&) = delete;
    Employee(Employee &&) = delete;
    ~Employee() = default;
    
    Employee(std::string name,float salary): _name{name},_salary{salary} {}
    void PayTax()
    {
        if (_salary < 500000.0f)
        {
            std::cout << "No tax for you"
                      << "\n";
        }

        else if (_salary >= 500000.0f && _salary < 1000000.0f)
        {
            std::cout << "20% for you"
                      << "\n";
        }
        else
        {
            std::cout << "30% for you"
                      << "\n";
        }
    }

    std::string name() const { return _name; }

    float salary() const { return _salary; }
};

#endif // EMPLOYEE_H
