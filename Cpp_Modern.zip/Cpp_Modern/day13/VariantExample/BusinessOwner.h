#ifndef BUSINESSOWNER_H
#define BUSINESSOWNER_H

#include <iostream>

class BusineeOwner
{
private:
    std::string _name;
    float _revenue;
    float _expenses;
    float _profits;

public:
    BusineeOwner(/* args */) = delete;
    BusineeOwner(const BusineeOwner &) = delete;
    BusineeOwner &operator=(const BusineeOwner &) = delete;
    BusineeOwner &operator=(BusineeOwner &&) = delete;
    BusineeOwner(BusineeOwner &&) = delete;
    ~BusineeOwner() = default;

    BusineeOwner(std::string name,float revenue,float expenses,float profits): _name{name},_revenue{revenue},_expenses{expenses},_profits{profits} {}

    void PayTax()
    {
        if (_profits < 500000.0f)
        {
            std::cout << "No tax for you"
                      << "\n";
        }

        else if (_profits >= 500000.0f && _profits < 1000000.0f)
        {
            std::cout << "20% for you"
                      << "\n";
        }
        else
        {
            std::cout << "31% for you"
                      << "\n";
        }
    }

    std::string name() const { return _name; }

    float revenue() const { return _revenue; }

    float expenses() const { return _expenses; }

    float profits() const { return _profits; }
};

#endif // BUSINESSOWNER_H
