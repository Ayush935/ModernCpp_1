#include "Employee.h"
#include "BusinessOwner.h"
#include <variant>
#include <array>

using Vtype = std::variant<Employee*,BusineeOwner*>;

void CreateObject(){
    Vtype v =new Employee("Ayush",21300.43f);
}

/*
  Each variant when declared is always initialized with default value of type at first position in the variant declaration

  e.g Vtype was declared for <Employee,BusinessOwner>, Employee is first position type vtype v; //v will be assigned default
  value of type employee which means employee class should have default constructor enabled

*/

void CreateObject(std::array<Vtype,2> &data){
    
    data[0] = new Employee("Ayush",200133.45f);  //variant 0
    data[1] = new BusineeOwner("Bob",2344,42232,4334.44f); //variant 1

    data[0] = new BusineeOwner("Jack",2344,42232,4334.44f); //change variant 0 data, now Ayush employee is erased 
}

void TaxFunctional(std::array<Vtype,2> &data){
    /*
      for each variant that is stred in the array,
      a) "visit" that variant,
      b) OPen the variant wrapper, you should get a pointer inside could be employee
      pointer or BusinessOwner
      c) regardless of type, call the pointer as "val", now use val value to 
      paytax function
    */
   /*
     1) a callable that explains what you want to do with item found inside the variant
     2) you can pass one or more variants (based on operation requirements)
   */

   for(Vtype& v : data){
    std::visit(
        [](auto && val) {val->PayTax();},v
    );
   }
}

int main(){
    std::array<Vtype,2> data;
    CreateObject(data);
    TaxFunctional(data);
}