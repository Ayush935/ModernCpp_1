#include "Employee.h"
#include "BusinessOwner.h"
#include <memory>
#include <list>
#include <variant>

using Emptr = std::shared_ptr<Employee>;
using BusinessPtr = std::shared_ptr<BusineeOwner>;

using Vtype =  std::variant<Emptr,BusinessPtr>;

using Container = std::list<Vtype>;

void CreateObjects(Container& data){

    //a) make_shared returns Emptr (shared pointer to employee)
    //b) compiler tries to assign to the variant in position of o of the list
    // since variant accepts Emptr and BusinessPtr both, assignment is successfull, no errors!
    data.push_back(
        std::make_shared<Employee>("Ayush",1233.43f)
    );
    data.push_back(
        std::make_shared<Employee>("Bob",1233.43f)
    );
    data.push_back(
        std::make_shared<BusineeOwner>("Bobby",1233.3f,2343.43f,4332.3f)
    );

    /*

                                                      ["Bob" | 12333.3f]
                                                        |
                                                        |
                                                     [0x77H | 1  | 0 ]
                                                        |
                                                        |
     nullptr [variant] 0x18H  ----->    0x11H     [variant]  nullptr  --------->   0x22H [variant] nullptr
               |                                                                          |
               [0x877H | 1 | 0]                                                           |
                  Emptr                                                                BusinessOwner
                   |                                                                         |
                   |                                                                         |
                   ["Ayush"  |  242.34f]                                                   ["Bobby" | 1233.3f,2433,43f, 4332.3f]
                   | heap
                
    */
     
}

// A function to print the revenue of all BusinessOwners in the data
/*
  for every Vtype variable command "v" which is present in the data,
   a) check if v holds the alternative of type businessPtr
   - if yes, since BusinessPtr is at position 1 in the declaration of Vtype, get<1> position pointer.
   - use this pointer to fetch revenue getter
*/
void showRevenue(Container &data){
      for(Vtype& v : data){
        if(std::holds_alternative<BusineeOwner>(v)){
            std::cout << std::get<1>(v)->revenue();
        }
      }
}

int main(){
     Container data;
     CreateObjects(data);
}