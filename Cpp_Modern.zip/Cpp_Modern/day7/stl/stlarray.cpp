/*
int arr[3];
java : class Arrsy
STL : class std::array 
*/

#include <iostream>
#include <array>

//according to compiler arr variable in magic scope 
//is an alternate name for arr in main
//Main_arr == Magic_arr
void magic(std::array<int,5>&arr){
    // auto ->    std::array<int,5>iterator
    for(std::array<int,5>::iterator itr = arr.begin();itr!=arr.end();++itr){
        std::cout<<*itr<<"\n";
    }
    for(int val: arr){
        std::cout<<val<<"\n";
    }
    for(std::array<int,5>::reverse_iterator itr =arr.rbegin();itr!=arr.rend();++itr ){
        std::cout<<*itr<<"\n";
    }
    for(std::array<int,5>::const_iterator itr =arr.cbegin();itr!=arr.cend();++itr ){
        std::cout<<*itr<<"\n";
    }
   
}

int main(){
    //int arr[5]
    std::array<int,5>arr{0};
    //arrays are accessed by index

    arr[0] = 100;
    std::cout<<arr.front()<<"\n";
    std::cout<<arr.back()<<"\n";

    std::cout<<arr[0]<<"\n";



    /*
    front() :  access to first item in the container by refernce
    back()  :  access to lasr item in the container by refernce
    begin() :  iterator to first item in the container
    end()   :  iterator to a non-valid location outside of the limits of the container's memory
    cbegin():  iterator to the first item of the container
         This ITERATOR CANNOT BE dereference for write operation
    cend()  :  iterator to a non-valid location outside of the limits of the container's memory
          This ITERATOR CANNOT BE dereference for write operation

    stl -> 3 sections -> container, algorithm, iterator
    */
}