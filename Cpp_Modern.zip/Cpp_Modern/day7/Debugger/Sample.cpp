#include <iostream>

class Customer
{
private:
    std::string _name;
    int _age;
    
public:
    class Address
    {
    private:
        std::string _locate;
        unsigned int _pincode;
        unsigned short _house_number;
        std::string _street_name;
        std::string _state;
   //ineer classes are implicitly friend
    public:
        Address() = default;
        ~Address() = default;
        Address(const Address &) = default;
        Address &operator=(const Address &) = default;
        Address(Address &&) = delete;
        Address &operator=(Address &&) = delete;
        Address(std::string location, unsigned int pincode, unsigned short house_number, std::string street_name, std::string state){
            _locate = location;
            _pincode = pincode;
            _house_number = house_number;
            _street_name = street_name;
            _state = state;
        }
        unsigned int pincode() const { return _pincode; }
        void setPincode(unsigned int pincode) { _pincode = pincode; }
        inline friend std::ostream &operator<<(std::ostream &os, const Address &rhs)
        {
            os << "_locate: " << rhs._locate
               << " _pincode: " << rhs._pincode
               << " _house_number: " << rhs._house_number
               << " _street_name: " << rhs._street_name
               << " _state: " << rhs._state;
            return os;
        }
    };
public:
    Address _customer_address;

public:
    Customer() = default;
    ~Customer() = default;
    Customer(const Customer &) = default;
    Customer &operator=(const Customer &) = default;
    Customer(Customer &&) = delete;
    Customer &operator=(Customer &&) = delete;
    Customer(std::string name,int age,Address customer_address){
        _name= name;
        _age = age;
        _customer_address = customer_address;
    }
    Address customerAddress() const { return _customer_address; }

    void setCustomerAddress(const Address &customer_address) { _customer_address = customer_address; }
};


int main(){
    Customer c1(
        "Ayush",18,
        Customer::Address("Pune",2323,123,"sdf","Maharashtra")
      );

      std::cout<<c1.customerAddress().pincode()<<std::endl;
}


/*
 class Customer{
    public:
       Member functions of customer
       Declaration of Address
                    |
                    ------ public
    -----------------------------Member function 
 }
*/

   
        

    
