// checks if at leat one of your data instances satisfies the given condition

//example 


#include <algorithm>
#include "Functionalities.h"

int main()
{
    StackEmployeeContainer data;
    CreateObjects(data);
    EmployeePointerContainer data1;
    CreateObjects(data1);
    EmployeeSmartPointer data2;
    CreateObjects(data2);

    bool flag = std::any_of(
        data.begin(),
        data.end(),
        [](const Employee &emp)
        { return emp.salary() > 60000.0f; });

    bool flag1 = std::any_of(
        data1.begin(),
        data1.end(),
        [](const Employee *emp)
        { return emp->salary() > 60000.0f; });

    bool flag22 = std::any_of(
        data1.begin(),
        data1.end(),
        [](const EmplSptr &emp)
        { return emp->salary() > 60000.0f; });
}