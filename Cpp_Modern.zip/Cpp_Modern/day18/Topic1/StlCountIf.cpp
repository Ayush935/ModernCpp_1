// STL ----------------------------------

// Counts the number of data instances matching the specified condition

#include <algorithm>
#include "Functionalities.h"

int main()
{
    StackEmployeeContainer data;
    CreateObjects(data);
    EmployeePointerContainer data1;
    CreateObjects(data1);
    EmployeeSmartPointer data2;
    CreateObjects(data2);

    std::size_t count = std::count_if(
        data.begin(),
        data.end(),
        [](const Employee &emp)
        {
            return emp.salary() > 60000.0f;
        });

    std::size_t count1 = std::count_if(
        data1.begin(),
        data1.end(),
        [](const Employee *emp)
        { return emp->salary() > 60000.0f; });

    std::size_t count2 = std::count_if(
        data1.begin(),
        data1.end(),
        [](const EmplSptr &emp)
        { return emp->salary() > 60000.0f; });
}