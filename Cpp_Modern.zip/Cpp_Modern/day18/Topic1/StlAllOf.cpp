// Returns boolean to indicate if all instances satisfy condition or not



#include <algorithm>
#include "Functionalities.h"

int main()
{
    StackEmployeeContainer data;
    CreateObjects(data);
    EmployeePointerContainer data1;
    CreateObjects(data1);
    EmployeeSmartPointer data2;
    CreateObjects(data2);

    bool flag = std::all_of(
        data.begin(),
        data.end(),
        [](const Employee &emp)
        { return emp.salary() > 60000.0f; });

    bool flag1 = std::all_of(
        data1.begin(),
        data1.end(),
        [](const Employee *emp)
        { return emp->salary() > 60000.0f; });

    bool flag2 = std::all_of(
        data2.begin(),
        data2.end(),
        [](const EmplSptr &emp)
        { return emp->salary() > 60000.0f; });
}


