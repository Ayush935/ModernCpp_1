#ifndef FUNCTIONALITIES_H
#define FUNCTIONALITIES_H

#include <vector>
#include "Employee.h"
#include <memory>
using StackEmployeeContainer = std::vector<Employee>;
using EmployeePointerContainer = std::vector<Employee*>;
using EmplSptr = std::shared_ptr<Employee>;
using EmployeeSmartPointer = std::vector<EmplSptr>;

void CreateObjects(StackEmployeeContainer& data);
void CreateObjects(EmployeePointerContainer& data);
void CreateObjects(EmployeeSmartPointer & data);

#endif // FUNCTIONALITIES_H
