#ifndef EMPLOYEE_H
#define EMPLOYEE_H

#include <iostream>

class Employee
{
private:
    std::string m_id;
    std::string m_employee_name;
    float m_salary;
    unsigned int m_age;
    std::string m_locatiob;

public:
    Employee(/* args */) = default;
    Employee(const Employee &) = default;
    Employee(Employee &&) = default;
    Employee &operator=(const Employee &) = default;
    Employee &operator=(Employee &&) = default;
    ~Employee() = default;

    Employee(std::string _id,
             std::string _employee_name,
             float _salary,
             unsigned int _age,
             std::string _locatiob);

    std::string id() const { return m_id; }

    std::string employeeName() const { return m_employee_name; }

    float salary() const { return m_salary; }

    unsigned int age() const { return m_age; }

    std::string locatiob() const { return m_locatiob; }

    float operator+(const Employee& rhs){return m_salary+rhs.m_salary;};   
};

#endif // EMPLOYEE_H
