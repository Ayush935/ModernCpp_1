#include "Functionalities.h"

void CreateObjects(StackEmployeeContainer &data)
{
    data.emplace_back(Employee("Emp01","Ayush",12232.32f,21,"Pune"));
    data.emplace_back(Employee("Emp02","Ayushi",13222.32f,31,"Nagpur"));
    data.emplace_back(Employee("Emp03","Bob",12323.32f,41,"Mumbai"));
    data.emplace_back(Employee("Emp04","Bobby",12342.32f,51,"Pune"));
    data.emplace_back(Employee("Emp05","Jay",1243342.32f,41,"Nashik"));
}

void CreateObjects(EmployeePointerContainer &data)
{
    data.emplace_back(new Employee("Emp01","Ayush",12232.32f,21,"Pune"));
    data.emplace_back(new Employee("Emp02","Ayushi",13222.32f,31,"Nagpur"));
    data.emplace_back(new Employee("Emp03","Bob",12323.32f,41,"Mumbai"));
    data.emplace_back(new Employee("Emp04","Bobby",12342.32f,51,"Pune"));
    data.emplace_back(new Employee("Emp05","Jay",1243342.32f,41,"Nashik"));
}

void CreateObjects(EmployeeSmartPointer &data)
{
    data.emplace_back(std::make_shared<Employee>("Emp01","Ayush",12232.32f,21,"Pune"));
    data.emplace_back(std::make_shared<Employee>("Emp02","Ayushi",13222.32f,31,"Nagpur"));
    data.emplace_back(std::make_shared<Employee>("Emp03","Bob",12323.32f,41,"Mumbai"));
    data.emplace_back(std::make_shared<Employee>("Emp04","Bobby",12342.32f,51,"Pune"));
    data.emplace_back(std::make_shared<Employee>("Emp05","Jay",1243342.32f,41,"Nashik"));
}
