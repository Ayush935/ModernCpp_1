#include "Employee.h"

Employee::Employee(std::string _id, std::string _employee_name, float _salary, unsigned int _age, std::string _locatiob)
    : m_id{_id},m_employee_name{_employee_name},m_salary{_salary},m_age{_age},m_locatiob{_locatiob}
{
}