// Total of Employee salary for all instances in the container

/*
 (total_upto_current_data)
                              itr
 0                     50000  55000 54399 34584 54000
                         |      |
  [total_upto_curr]             |
           50000                |
                   |
                10500
                      |
                       sum
                           |
                             sum

*/

// accumulate performs a successive binary operation on answer upto previous step
// with next value from the data

#include <numeric>
#include "Functionalities.h"

int main()
{
    StackEmployeeContainer data;
    CreateObjects(data);
    EmployeePointerContainer data1;
    CreateObjects(data1);
    EmployeeSmartPointer data2;
    CreateObjects(data2);



    float sum = std::accumulate(
        data.begin(),
        data.end(),
        0.0f,
        [](float answer_upto_current_point, const Employee& emp){
            return answer_upto_current_point+ emp.salary();
        }                               //parameter p1 p2
    );

    auto fns = [](float answer_upto_current_point, const Employee* emp){
            return answer_upto_current_point+ emp->salary();
        } ;

    float sum1 = std::accumulate(
        data1.begin(),
        data1.end(),
        0.0f,
        fns
    );

    float sum2 = std::accumulate(
        data2.begin(),
        data2.end(),
        0.0f,
        [](float answer_upto_current_point, const EmplSptr& emp){
            return answer_upto_current_point+ emp->salary();
        } 
    );
}