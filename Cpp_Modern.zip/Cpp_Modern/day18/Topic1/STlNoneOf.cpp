
// checks if at eat none of your data matches with the condition


#include <algorithm>
#include "Functionalities.h"

int main()
{
    StackEmployeeContainer data;
    CreateObjects(data);
    EmployeePointerContainer data1;
    CreateObjects(data1);
    EmployeeSmartPointer data2;
    CreateObjects(data2);

    bool flag = std::none_of(
        data.begin(),
        data.end(),
        [](const Employee &emp)
        { return emp.salary() > 60000.0f; });

    bool flag1 = std::none_of(
        data1.begin(),
        data1.end(),
        [](const Employee *emp)
        { return emp->salary() > 60000.0f; });

    bool flag22 = std::none_of(
        data1.begin(),
        data1.end(),
        [](const EmplSptr &emp)
        { return emp->salary() > 60000.0f; });
}